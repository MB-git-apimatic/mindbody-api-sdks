
# Mindbody Public Api Common Models Unavailability

## Structure

`MindbodyPublicApiCommonModelsUnavailability`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Optional | Unavailabiltity ID. |
| `start_date_time` | `DateTime` | Optional | Start of the unavailability. |
| `end_date_time` | `DateTime` | Optional | End of the unavailability. |
| `description` | `String` | Optional | Description of the unavailability. |

## Example (as JSON)

```json
{
  "Id": null,
  "StartDateTime": null,
  "EndDateTime": null,
  "Description": null
}
```

