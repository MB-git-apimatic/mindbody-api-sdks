
# Mindbody Public Api Dto Models V6 Sale Controller Payment Processing Failure

Contains information about any payment processing failure.  Specifically for when an SCA challenge is

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerPaymentProcessingFailure`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `type` | `String` | Optional | The type of the failure |
| `message` | `String` | Optional | Descriptive message for the failure |
| `authentication_redirect_url` | `String` | Optional | For SCA aware flows, this is the url provided by the bank where the consumer can authorize the transaction |

## Example (as JSON)

```json
{
  "Type": null,
  "Message": null,
  "AuthenticationRedirectUrl": null
}
```

