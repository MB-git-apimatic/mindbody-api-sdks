
# Mindbody Public Api Dto Models V6 Sale Controller Initialize Credit Card Entry Response

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerInitializeCreditCardEntryResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callback_url` | `String` | Optional | - |

## Example (as JSON)

```json
{
  "CallbackUrl": null
}
```

