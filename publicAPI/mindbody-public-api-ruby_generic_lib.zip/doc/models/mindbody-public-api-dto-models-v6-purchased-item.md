
# Mindbody Public Api Dto Models V6 Purchased Item

## Structure

`MindbodyPublicApiDtoModelsV6PurchasedItem`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sale_detail_id` | `Integer` | Optional | The ID of the sale detail |
| `id` | `Integer` | Optional | The ProductID of the item. |
| `is_service` | `TrueClass\|FalseClass` | Optional | When `true`, indicates that the purchased item was a pricing option for a service. |
| `barcode_id` | `String` | Optional | The BarcodeId of the item.<br>For services, BarcodeId may be null<br>If no barcode id is explicitly set by the business it is the internal id in a string format. |
| `description` | `String` | Optional | Description of the sale transaction/pricing option description |
| `contract_id` | `Integer` | Optional | Contract ID purchased by the client |
| `category_id` | `Integer` | Optional | Revenue Category ID |
| `sub_category_id` | `Integer` | Optional | Revenue Subcategory ID |
| `unit_price` | `Float` | Optional | Per unit price of the item sold |
| `quantity` | `Integer` | Optional | Quantity of the products |
| `discount_percent` | `Float` | Optional | Discount % applied during sale |
| `discount_amount` | `Float` | Optional | Discount Amount |
| `tax_1` | `Float` | Optional | Tax1 applicable for the product |
| `tax_2` | `Float` | Optional | Tax2 applicable for the product |
| `tax_3` | `Float` | Optional | Tax3 applicable for the product |
| `tax_4` | `Float` | Optional | Tax4 applicable for the product |
| `tax_5` | `Float` | Optional | Tax5 applicable for the product |
| `tax_amount` | `Float` | Optional | Tax rate applicable for the product |
| `total_amount` | `Float` | Optional | Charged to the customer for paying |
| `notes` | `String` | Optional | Notes |
| `returned` | `TrueClass\|FalseClass` | Optional | Returned or not |
| `payment_ref_id` | `Integer` | Optional | Payment Reference ID |
| `exp_date` | `DateTime` | Optional | Expiration date of the pricing option purchased |
| `active_date` | `DateTime` | Optional | Activation date of pricing option purchased |

## Example (as JSON)

```json
{
  "SaleDetailId": null,
  "Id": null,
  "IsService": null,
  "BarcodeId": null,
  "Description": null,
  "ContractId": null,
  "CategoryId": null,
  "SubCategoryId": null,
  "UnitPrice": null,
  "Quantity": null,
  "DiscountPercent": null,
  "DiscountAmount": null,
  "Tax1": null,
  "Tax2": null,
  "Tax3": null,
  "Tax4": null,
  "Tax5": null,
  "TaxAmount": null,
  "TotalAmount": null,
  "Notes": null,
  "Returned": null,
  "PaymentRefId": null,
  "ExpDate": null,
  "ActiveDate": null
}
```

