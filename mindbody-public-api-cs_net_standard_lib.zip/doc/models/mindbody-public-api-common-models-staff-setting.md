
# Mindbody Public Api Common Models Staff Setting

## Structure

`MindbodyPublicApiCommonModelsStaffSetting`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `UseStaffNicknames` | `bool?` | Optional | - |
| `ShowStaffLastNamesOnSchedules` | `bool?` | Optional | - |

## Example (as JSON)

```json
{
  "UseStaffNicknames": null,
  "ShowStaffLastNamesOnSchedules": null
}
```

