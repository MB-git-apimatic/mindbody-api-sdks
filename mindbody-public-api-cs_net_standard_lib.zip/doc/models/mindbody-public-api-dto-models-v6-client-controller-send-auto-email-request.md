
# Mindbody Public Api Dto Models V6 Client Controller Send Auto Email Request

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerSendAutoEmailRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ClientId` | `string` | Required | The Unique Id of the client as assigned by the business. |
| `EmailType` | `string` | Required | The type of auto email to send (currently only BusinessWelcomeEmail or ConsumerWelcomeEmail are supported.) |

## Example (as JSON)

```json
{
  "ClientId": "ClientId6",
  "EmailType": "EmailType8"
}
```

