
# Mindbody Public Api Common Models Location

## Structure

`MindbodyPublicApiCommonModelsLocation`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `BusinessId` | `int?` | Optional | - |
| `SiteId` | `int?` | Optional | - |
| `BusinessDescription` | `string` | Optional | - |
| `AdditionalImageURLs` | `List<string>` | Optional | - |
| `FacilitySquareFeet` | `int?` | Optional | - |
| `ProSpaFinderSite` | `bool?` | Optional | - |
| `HasClasses` | `bool?` | Optional | - |
| `PhoneExtension` | `string` | Optional | - |
| `Action` | [`Models.ActionEnum?`](../../doc/models/action-enum.md) | Optional | - |
| `Id` | `int?` | Optional | - |
| `Name` | `string` | Optional | - |
| `Address` | `string` | Optional | - |
| `Address2` | `string` | Optional | - |
| `Tax1` | `double?` | Optional | - |
| `Tax2` | `double?` | Optional | - |
| `Tax3` | `double?` | Optional | - |
| `Tax4` | `double?` | Optional | - |
| `Tax5` | `double?` | Optional | - |
| `Phone` | `string` | Optional | - |
| `City` | `string` | Optional | - |
| `StateProvCode` | `string` | Optional | - |
| `PostalCode` | `string` | Optional | - |
| `Latitude` | `double?` | Optional | - |
| `Longitude` | `double?` | Optional | - |
| `DistanceInMiles` | `double?` | Optional | - |
| `ImageURL` | `string` | Optional | - |
| `Description` | `string` | Optional | - |
| `HasSite` | `bool?` | Optional | - |
| `CanBook` | `bool?` | Optional | - |
| `NumberTreatmentRooms` | `int?` | Optional | - |
| `Active` | `bool?` | Optional | - |
| `InvActive` | `bool?` | Optional | - |
| `WsShow` | `bool?` | Optional | - |
| `Email` | `string` | Optional | - |
| `ContactName` | `string` | Optional | - |
| `ShipAddress` | `string` | Optional | - |
| `ShipState` | `string` | Optional | - |
| `ShipPostal` | `string` | Optional | - |
| `ShipPhone` | `string` | Optional | - |
| `ShipPOC` | `string` | Optional | - |
| `TaxGrouping` | `bool?` | Optional | - |
| `LabelTax1` | `string` | Optional | - |
| `LabelTax2` | `string` | Optional | - |
| `LabelTax3` | `string` | Optional | - |
| `LabelTax4` | `string` | Optional | - |
| `LabelTax5` | `string` | Optional | - |
| `WAC` | `bool?` | Optional | - |
| `ShipAddress2` | `string` | Optional | - |
| `MasterLocId` | `int?` | Optional | - |
| `StreetAddress` | `string` | Optional | - |
| `Country` | `string` | Optional | - |
| `Ext` | `string` | Optional | - |
| `Amenities` | [`List<Models.MindbodyPublicApiCommonModelsAmenity>`](../../doc/models/mindbody-public-api-common-models-amenity.md) | Optional | - |
| `TotalNumberOfDeals` | `long?` | Optional | - |
| `TotalNumberOfRatings` | `int?` | Optional | - |
| `AverageRating` | `double?` | Optional | - |

## Example (as JSON)

```json
{
  "BusinessId": null,
  "SiteId": null,
  "BusinessDescription": null,
  "AdditionalImageURLs": null,
  "FacilitySquareFeet": null,
  "ProSpaFinderSite": null,
  "HasClasses": null,
  "PhoneExtension": null,
  "Action": null,
  "Id": null,
  "Name": null,
  "Address": null,
  "Address2": null,
  "Tax1": null,
  "Tax2": null,
  "Tax3": null,
  "Tax4": null,
  "Tax5": null,
  "Phone": null,
  "City": null,
  "StateProvCode": null,
  "PostalCode": null,
  "Latitude": null,
  "Longitude": null,
  "DistanceInMiles": null,
  "ImageURL": null,
  "Description": null,
  "HasSite": null,
  "CanBook": null,
  "NumberTreatmentRooms": null,
  "Active": null,
  "InvActive": null,
  "WsShow": null,
  "Email": null,
  "ContactName": null,
  "ShipAddress": null,
  "ShipState": null,
  "ShipPostal": null,
  "ShipPhone": null,
  "ShipPOC": null,
  "TaxGrouping": null,
  "LabelTax1": null,
  "LabelTax2": null,
  "LabelTax3": null,
  "LabelTax4": null,
  "LabelTax5": null,
  "WAC": null,
  "ShipAddress2": null,
  "MasterLocId": null,
  "StreetAddress": null,
  "Country": null,
  "Ext": null,
  "Amenities": null,
  "TotalNumberOfDeals": null,
  "TotalNumberOfRatings": null,
  "AverageRating": null
}
```

