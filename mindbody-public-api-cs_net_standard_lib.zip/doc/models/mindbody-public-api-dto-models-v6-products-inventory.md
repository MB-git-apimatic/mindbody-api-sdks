
# Mindbody Public Api Dto Models V6 Products Inventory

## Structure

`MindbodyPublicApiDtoModelsV6ProductsInventory`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ProductId` | `int?` | Optional | A ProductId of the product. |
| `BarcodeId` | `string` | Optional | The Id is barcode Id of the product. |
| `LocationId` | `int?` | Optional | The LocationId of the product. |
| `UnitsLogged` | `int?` | Optional | UnitsLogged of the product. |
| `UnitsSold` | `int?` | Optional | UnitsSold of the product. |
| `UnitsInStock` | `int?` | Optional | The units in stock of the product |
| `ReorderLevel` | `int?` | Optional | ReorderLevel of the product. |
| `MaxLevel` | `int?` | Optional | MaxLevel of the product. |
| `CreatedDateTimeUTC` | `DateTime?` | Optional | CreatedDateTimeUTC of the product. |
| `ModifiedDateTimeUTC` | `DateTime?` | Optional | ModifiedDateTimeUTC of the product. |

## Example (as JSON)

```json
{
  "ProductId": null,
  "BarcodeId": null,
  "LocationId": null,
  "UnitsLogged": null,
  "UnitsSold": null,
  "UnitsInStock": null,
  "ReorderLevel": null,
  "MaxLevel": null,
  "CreatedDateTimeUTC": null,
  "ModifiedDateTimeUTC": null
}
```

