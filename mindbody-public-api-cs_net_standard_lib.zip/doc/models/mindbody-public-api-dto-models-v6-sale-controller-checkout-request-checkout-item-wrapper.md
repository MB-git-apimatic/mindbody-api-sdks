
# Mindbody Public Api Dto Models V6 Sale Controller Checkout Request Checkout Item Wrapper

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerCheckoutRequestCheckoutItemWrapper`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Item` | [`Models.MindbodyPublicApiDtoModelsV6SaleControllerCheckoutRequestItemsCheckoutItem`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-checkout-request-items-checkout-item.md) | Optional | - |
| `DiscountAmount` | `double?` | Optional | The amount the item is discounted. This parameter is ignored for packages. |
| `AppointmentBookingRequests` | [`List<Models.MindbodyPublicApiDtoModelsV6SaleControllerCheckoutRequestCheckoutAppointmentBookingRequest>`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-checkout-request-checkout-appointment-booking-request.md) | Optional | A list of appointments to be booked then paid for by this item. This parameter applies only to pricing option items. |
| `EnrollmentIds` | `List<int>` | Optional | A list of enrollment IDs that this item is to pay for. This parameter applies only to pricing option items. |
| `ClassIds` | `List<int>` | Optional | A list of class IDs that this item is to pay for. This parameter applies only to pricing option items. |
| `CourseIds` | `List<long>` | Optional | A list of course IDs that this item is to pay for. This parameter applies only to pricing option items. |
| `VisitIds` | `List<long>` | Optional | A list of visit IDs that this item is to pay for. This parameter applies only to pricing option items. |
| `AppointmentIds` | `List<long>` | Optional | A list of appointment IDs that this item is to reconcile. |
| `Id` | `int?` | Optional | The item’s unique ID within the cart. |
| `Quantity` | `int?` | Optional | The number of this item to be purchased. |

## Example (as JSON)

```json
{
  "Item": null,
  "DiscountAmount": null,
  "AppointmentBookingRequests": null,
  "EnrollmentIds": null,
  "ClassIds": null,
  "CourseIds": null,
  "VisitIds": null,
  "AppointmentIds": null,
  "Id": null,
  "Quantity": null
}
```

