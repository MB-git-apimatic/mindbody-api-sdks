
# Mindbody Public Api Dto Models V6 Client Controller Get Active Client Memberships Response

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerGetActiveClientMembershipsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | Contains information about the pagination to use. |
| `ClientMemberships` | [`List<Models.MindbodyPublicApiDtoModelsV6ClientMembership>`](../../doc/models/mindbody-public-api-dto-models-v6-client-membership.md) | Optional | Details about the requested memberships. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "ClientMemberships": null
}
```

