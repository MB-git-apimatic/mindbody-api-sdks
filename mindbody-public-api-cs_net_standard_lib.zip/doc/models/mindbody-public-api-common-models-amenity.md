
# Mindbody Public Api Common Models Amenity

A specific amenity at a location

## Structure

`MindbodyPublicApiCommonModelsAmenity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | The identifying ID of the amenity. |
| `Name` | `string` | Optional | The name of the amenity (e.g. "Lockers" or "Food/Drink"). |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null
}
```

