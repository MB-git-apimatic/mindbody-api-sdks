
# Mindbody Public Api Dto Models V6 Package

## Structure

`MindbodyPublicApiDtoModelsV6Package`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | The ID of the package. |
| `Name` | `string` | Optional | The name of the package. |
| `DiscountPercentage` | `double?` | Optional | The discount percentage applied to the package. |
| `SellOnline` | `bool?` | Optional | When `true`, only products that can be sold online are returned.<br /><br>When `false`, all products are returned. |
| `Services` | [`List<Models.MindbodyPublicApiDtoModelsV6Service>`](../../doc/models/mindbody-public-api-dto-models-v6-service.md) | Optional | Information about the services in the packages. |
| `Products` | [`List<Models.MindbodyPublicApiDtoModelsV6Product>`](../../doc/models/mindbody-public-api-dto-models-v6-product.md) | Optional | Information about the products in the packages. |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null,
  "DiscountPercentage": null,
  "SellOnline": null,
  "Services": null,
  "Products": null
}
```

