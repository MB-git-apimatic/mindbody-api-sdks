// <copyright file="AppointmentController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Authentication;
    using MINDBODYPublicAPI.Standard.Http.Client;
    using MINDBODYPublicAPI.Standard.Http.Request;
    using MINDBODYPublicAPI.Standard.Http.Request.Configuration;
    using MINDBODYPublicAPI.Standard.Http.Response;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// AppointmentController.
    /// </summary>
    public class AppointmentController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AppointmentController"/> class.
        /// </summary>
        /// <param name="config"> config instance. </param>
        /// <param name="httpClient"> httpClient. </param>
        /// <param name="authManagers"> authManager. </param>
        internal AppointmentController(IConfiguration config, IHttpClient httpClient, IDictionary<string, IAuthManager> authManagers)
            : base(config, httpClient, authManagers)
        {
        }

        /// <summary>
        /// A user token is required for this endpoint. To book an appointment, you must use a location ID, staff ID, client ID, session type ID, and the StartDateTime of the appointment. You can get most of this information using GET BookableItems.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentResponse AppointmentAddAppointment(
                string version,
                Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentRequest request,
                string siteId,
                string authorization = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentResponse> t = this.AppointmentAddAppointmentAsync(version, request, siteId, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// A user token is required for this endpoint. To book an appointment, you must use a location ID, staff ID, client ID, session type ID, and the StartDateTime of the appointment. You can get most of this information using GET BookableItems.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentResponse> AppointmentAddAppointmentAsync(
                string version,
                Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/appointment/addappointment");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "Content-Type", "application/json" },
                { "authorization", authorization },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(request);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentResponse>(response.Body);
        }

        /// <summary>
        /// To update the information for a specific appointment, you must have a staff user token with the proper permissions. Note that you can only update the appointment’s `StartDateTime`, `EndDateTime`, `StaffId`, `Notes`, and `SessionTypeId`.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAppointmentResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAppointmentResponse AppointmentUpdateAppointment(
                string version,
                Models.MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAppointmentRequest request,
                string siteId,
                string authorization = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAppointmentResponse> t = this.AppointmentUpdateAppointmentAsync(version, request, siteId, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// To update the information for a specific appointment, you must have a staff user token with the proper permissions. Note that you can only update the appointment’s `StartDateTime`, `EndDateTime`, `StaffId`, `Notes`, and `SessionTypeId`.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAppointmentResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAppointmentResponse> AppointmentUpdateAppointmentAsync(
                string version,
                Models.MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAppointmentRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/appointment/updateappointment");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "Content-Type", "application/json" },
                { "authorization", authorization },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(request);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAppointmentResponse>(response.Body);
        }

        /// <summary>
        /// Returns a list of dates to narrow down staff availability when booking. Dates are those which staff are scheduled to work and do not guarantee booking availabilities. After this call is made, use GET BookableItems to retrieve availabilities for specific dates before booking.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestSessionTypeId">Required parameter: required requested session type ID..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestEndDate">Optional parameter: The end date of the requested date range.   <br />Default: **StartDate**.</param>
        /// <param name="requestLocationId">Optional parameter: optional requested location ID..</param>
        /// <param name="requestStaffId">Optional parameter: optional requested staff ID..</param>
        /// <param name="requestStartDate">Optional parameter: The start date of the requested date range. If omitted, the default is used.  <br />Default: **today’s date**.</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetAvailableDatesResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetAvailableDatesResponse AppointmentGetAvailableDates(
                string version,
                int requestSessionTypeId,
                string siteId,
                string authorization = null,
                DateTime? requestEndDate = null,
                int? requestLocationId = null,
                long? requestStaffId = null,
                DateTime? requestStartDate = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetAvailableDatesResponse> t = this.AppointmentGetAvailableDatesAsync(version, requestSessionTypeId, siteId, authorization, requestEndDate, requestLocationId, requestStaffId, requestStartDate);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Returns a list of dates to narrow down staff availability when booking. Dates are those which staff are scheduled to work and do not guarantee booking availabilities. After this call is made, use GET BookableItems to retrieve availabilities for specific dates before booking.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestSessionTypeId">Required parameter: required requested session type ID..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestEndDate">Optional parameter: The end date of the requested date range.   <br />Default: **StartDate**.</param>
        /// <param name="requestLocationId">Optional parameter: optional requested location ID..</param>
        /// <param name="requestStaffId">Optional parameter: optional requested staff ID..</param>
        /// <param name="requestStartDate">Optional parameter: The start date of the requested date range. If omitted, the default is used.  <br />Default: **today’s date**.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetAvailableDatesResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetAvailableDatesResponse> AppointmentGetAvailableDatesAsync(
                string version,
                int requestSessionTypeId,
                string siteId,
                string authorization = null,
                DateTime? requestEndDate = null,
                int? requestLocationId = null,
                long? requestStaffId = null,
                DateTime? requestStartDate = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/appointment/availabledates");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "request.sessionTypeId", requestSessionTypeId },
                { "request.endDate", requestEndDate.HasValue ? requestEndDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null },
                { "request.locationId", requestLocationId },
                { "request.staffId", requestStaffId },
                { "request.startDate", requestStartDate.HasValue ? requestStartDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetAvailableDatesResponse>(response.Body);
        }

        /// <summary>
        /// Returns a list of availabilities with the information needed to book appointments. Availabilities include information such as the location and its amenities, staff members, programs, and session types. Recommended to use with ActiveSessionTimes to see which increments each business allows for booking appointments.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestSessionTypeIds">Required parameter: A list of the requested session type IDs..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestAppointmentId">Optional parameter: If provided, filters out the appointment with this ID..</param>
        /// <param name="requestEndDate">Optional parameter: The end date of the requested date range.   <br />Default: **StartDate**.</param>
        /// <param name="requestIgnoreDefaultSessionLength">Optional parameter: When `true`, availabilities that are non-default return, for example, a 30-minute availability with a 60-minute default session length.<br />  When `false`, only availabilities that have the default session length return..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationIds">Optional parameter: A list of the requested location IDs..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestStaffIds">Optional parameter: A list of the requested staff IDs. Omit parameter to return all staff availabilities..</param>
        /// <param name="requestStartDate">Optional parameter: The start date of the requested date range.   <br />Default: **today’s date**.</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetBookableItemsResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetBookableItemsResponse AppointmentGetBookableItems(
                string version,
                List<int> requestSessionTypeIds,
                string siteId,
                string authorization = null,
                long? requestAppointmentId = null,
                DateTime? requestEndDate = null,
                bool? requestIgnoreDefaultSessionLength = null,
                int? requestLimit = null,
                List<int> requestLocationIds = null,
                int? requestOffset = null,
                List<long> requestStaffIds = null,
                DateTime? requestStartDate = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetBookableItemsResponse> t = this.AppointmentGetBookableItemsAsync(version, requestSessionTypeIds, siteId, authorization, requestAppointmentId, requestEndDate, requestIgnoreDefaultSessionLength, requestLimit, requestLocationIds, requestOffset, requestStaffIds, requestStartDate);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Returns a list of availabilities with the information needed to book appointments. Availabilities include information such as the location and its amenities, staff members, programs, and session types. Recommended to use with ActiveSessionTimes to see which increments each business allows for booking appointments.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestSessionTypeIds">Required parameter: A list of the requested session type IDs..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestAppointmentId">Optional parameter: If provided, filters out the appointment with this ID..</param>
        /// <param name="requestEndDate">Optional parameter: The end date of the requested date range.   <br />Default: **StartDate**.</param>
        /// <param name="requestIgnoreDefaultSessionLength">Optional parameter: When `true`, availabilities that are non-default return, for example, a 30-minute availability with a 60-minute default session length.<br />  When `false`, only availabilities that have the default session length return..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationIds">Optional parameter: A list of the requested location IDs..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestStaffIds">Optional parameter: A list of the requested staff IDs. Omit parameter to return all staff availabilities..</param>
        /// <param name="requestStartDate">Optional parameter: The start date of the requested date range.   <br />Default: **today’s date**.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetBookableItemsResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetBookableItemsResponse> AppointmentGetBookableItemsAsync(
                string version,
                List<int> requestSessionTypeIds,
                string siteId,
                string authorization = null,
                long? requestAppointmentId = null,
                DateTime? requestEndDate = null,
                bool? requestIgnoreDefaultSessionLength = null,
                int? requestLimit = null,
                List<int> requestLocationIds = null,
                int? requestOffset = null,
                List<long> requestStaffIds = null,
                DateTime? requestStartDate = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/appointment/bookableitems");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "request.sessionTypeIds", requestSessionTypeIds },
                { "request.appointmentId", requestAppointmentId },
                { "request.endDate", requestEndDate.HasValue ? requestEndDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null },
                { "request.ignoreDefaultSessionLength", requestIgnoreDefaultSessionLength },
                { "request.limit", requestLimit },
                { "request.locationIds", requestLocationIds },
                { "request.offset", requestOffset },
                { "request.staffIds", requestStaffIds },
                { "request.startDate", requestStartDate.HasValue ? requestStartDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetBookableItemsResponse>(response.Body);
        }

        /// <summary>
        /// This is not appointment availability but rather the active business hours for studios and which increments services can be booked at. See BookableItems for appointment availability.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestEndTime">Optional parameter: Filters results to times that end on or before this time on the current date. Any date provided is ignored..  <br />Default: **23:59:59**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestScheduleType">Optional parameter: Filters on the provided the schedule type. Either `SessionTypeIds` or `ScheduleType` must be provided..</param>
        /// <param name="requestSessionTypeIds">Optional parameter: Filters on the provided session type IDs. Either `SessionTypeIds` or `ScheduleType` must be provided..</param>
        /// <param name="requestStartTime">Optional parameter: Filters results to times that start on or after this time on the current date. Any date provided is ignored.  <br />Default: **00:00:00**.</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetActiveSessionTimesResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetActiveSessionTimesResponse AppointmentGetActiveSessionTimes(
                string version,
                string siteId,
                string authorization = null,
                DateTime? requestEndTime = null,
                int? requestLimit = null,
                int? requestOffset = null,
                Models.RequestScheduleTypeEnum? requestScheduleType = null,
                List<int> requestSessionTypeIds = null,
                DateTime? requestStartTime = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetActiveSessionTimesResponse> t = this.AppointmentGetActiveSessionTimesAsync(version, siteId, authorization, requestEndTime, requestLimit, requestOffset, requestScheduleType, requestSessionTypeIds, requestStartTime);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// This is not appointment availability but rather the active business hours for studios and which increments services can be booked at. See BookableItems for appointment availability.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestEndTime">Optional parameter: Filters results to times that end on or before this time on the current date. Any date provided is ignored..  <br />Default: **23:59:59**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestScheduleType">Optional parameter: Filters on the provided the schedule type. Either `SessionTypeIds` or `ScheduleType` must be provided..</param>
        /// <param name="requestSessionTypeIds">Optional parameter: Filters on the provided session type IDs. Either `SessionTypeIds` or `ScheduleType` must be provided..</param>
        /// <param name="requestStartTime">Optional parameter: Filters results to times that start on or after this time on the current date. Any date provided is ignored.  <br />Default: **00:00:00**.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetActiveSessionTimesResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetActiveSessionTimesResponse> AppointmentGetActiveSessionTimesAsync(
                string version,
                string siteId,
                string authorization = null,
                DateTime? requestEndTime = null,
                int? requestLimit = null,
                int? requestOffset = null,
                Models.RequestScheduleTypeEnum? requestScheduleType = null,
                List<int> requestSessionTypeIds = null,
                DateTime? requestStartTime = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/appointment/activesessiontimes");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "request.endTime", requestEndTime.HasValue ? requestEndTime.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null },
                { "request.limit", requestLimit },
                { "request.offset", requestOffset },
                { "request.scheduleType", (requestScheduleType.HasValue) ? ApiHelper.JsonSerialize(requestScheduleType.Value).Trim('\"') : null },
                { "request.sessionTypeIds", requestSessionTypeIds },
                { "request.startTime", requestStartTime.HasValue ? requestStartTime.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetActiveSessionTimesResponse>(response.Body);
        }

        /// <summary>
        /// Returns a list of schedule items, including appointments, availabilities, and unavailabilities. Unavailabilities are the times at which appointments cannot be booked, for example, on holidays or after hours when the business is closed.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestEndDate">Optional parameter: The end date of the requested date range.   <br />Default: **today’s date**.</param>
        /// <param name="requestIgnorePrepFinishTimes">Optional parameter: When `true`, appointment preparation and finish unavailabilities are not returned.   <br />Default: **false**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationIds">Optional parameter: A list of requested location IDs..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestStaffIds">Optional parameter: A list of requested staff IDs..</param>
        /// <param name="requestStartDate">Optional parameter: The start date of the requested date range.   <br />Default: **today’s date**.</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetScheduleItemsResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetScheduleItemsResponse AppointmentGetScheduleItems(
                string version,
                string siteId,
                string authorization = null,
                DateTime? requestEndDate = null,
                bool? requestIgnorePrepFinishTimes = null,
                int? requestLimit = null,
                List<int> requestLocationIds = null,
                int? requestOffset = null,
                List<long> requestStaffIds = null,
                DateTime? requestStartDate = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetScheduleItemsResponse> t = this.AppointmentGetScheduleItemsAsync(version, siteId, authorization, requestEndDate, requestIgnorePrepFinishTimes, requestLimit, requestLocationIds, requestOffset, requestStaffIds, requestStartDate);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Returns a list of schedule items, including appointments, availabilities, and unavailabilities. Unavailabilities are the times at which appointments cannot be booked, for example, on holidays or after hours when the business is closed.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestEndDate">Optional parameter: The end date of the requested date range.   <br />Default: **today’s date**.</param>
        /// <param name="requestIgnorePrepFinishTimes">Optional parameter: When `true`, appointment preparation and finish unavailabilities are not returned.   <br />Default: **false**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationIds">Optional parameter: A list of requested location IDs..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestStaffIds">Optional parameter: A list of requested staff IDs..</param>
        /// <param name="requestStartDate">Optional parameter: The start date of the requested date range.   <br />Default: **today’s date**.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetScheduleItemsResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetScheduleItemsResponse> AppointmentGetScheduleItemsAsync(
                string version,
                string siteId,
                string authorization = null,
                DateTime? requestEndDate = null,
                bool? requestIgnorePrepFinishTimes = null,
                int? requestLimit = null,
                List<int> requestLocationIds = null,
                int? requestOffset = null,
                List<long> requestStaffIds = null,
                DateTime? requestStartDate = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/appointment/scheduleitems");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "request.endDate", requestEndDate.HasValue ? requestEndDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null },
                { "request.ignorePrepFinishTimes", requestIgnorePrepFinishTimes },
                { "request.limit", requestLimit },
                { "request.locationIds", requestLocationIds },
                { "request.offset", requestOffset },
                { "request.staffIds", requestStaffIds },
                { "request.startDate", requestStartDate.HasValue ? requestStartDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetScheduleItemsResponse>(response.Body);
        }

        /// <summary>
        /// This endpoint has no query parameters.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetAppointmentOptionsResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetAppointmentOptionsResponse AppointmentGetAppointmentOptions(
                string version,
                string siteId,
                string authorization = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetAppointmentOptionsResponse> t = this.AppointmentGetAppointmentOptionsAsync(version, siteId, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// This endpoint has no query parameters.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetAppointmentOptionsResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetAppointmentOptionsResponse> AppointmentGetAppointmentOptionsAsync(
                string version,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/appointment/appointmentoptions");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetAppointmentOptionsResponse>(response.Body);
        }

        /// <summary>
        /// Returns a list of appointments by staff member.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestAppointmentIds">Optional parameter: A list of the requested appointment IDs..</param>
        /// <param name="requestClientId">Optional parameter: The client ID to be returned..</param>
        /// <param name="requestEndDate">Optional parameter: The end date of the requested date range.   <br />Default: **StartDate**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationIds">Optional parameter: A list of the requested location IDs..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestStaffIds">Optional parameter: List of staff IDs to be returned. Use a value of zero to return all staff appointments..</param>
        /// <param name="requestStartDate">Optional parameter: The start date of the requested date range. If omitted, the default is used.   <br />Default: **today’s date**.</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetStaffAppointmentsResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetStaffAppointmentsResponse AppointmentGetStaffAppointments(
                string version,
                string siteId,
                string authorization = null,
                List<int> requestAppointmentIds = null,
                string requestClientId = null,
                DateTime? requestEndDate = null,
                int? requestLimit = null,
                List<int> requestLocationIds = null,
                int? requestOffset = null,
                List<long> requestStaffIds = null,
                DateTime? requestStartDate = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetStaffAppointmentsResponse> t = this.AppointmentGetStaffAppointmentsAsync(version, siteId, authorization, requestAppointmentIds, requestClientId, requestEndDate, requestLimit, requestLocationIds, requestOffset, requestStaffIds, requestStartDate);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Returns a list of appointments by staff member.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestAppointmentIds">Optional parameter: A list of the requested appointment IDs..</param>
        /// <param name="requestClientId">Optional parameter: The client ID to be returned..</param>
        /// <param name="requestEndDate">Optional parameter: The end date of the requested date range.   <br />Default: **StartDate**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationIds">Optional parameter: A list of the requested location IDs..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestStaffIds">Optional parameter: List of staff IDs to be returned. Use a value of zero to return all staff appointments..</param>
        /// <param name="requestStartDate">Optional parameter: The start date of the requested date range. If omitted, the default is used.   <br />Default: **today’s date**.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetStaffAppointmentsResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetStaffAppointmentsResponse> AppointmentGetStaffAppointmentsAsync(
                string version,
                string siteId,
                string authorization = null,
                List<int> requestAppointmentIds = null,
                string requestClientId = null,
                DateTime? requestEndDate = null,
                int? requestLimit = null,
                List<int> requestLocationIds = null,
                int? requestOffset = null,
                List<long> requestStaffIds = null,
                DateTime? requestStartDate = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/appointment/staffappointments");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "request.appointmentIds", requestAppointmentIds },
                { "request.clientId", requestClientId },
                { "request.endDate", requestEndDate.HasValue ? requestEndDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null },
                { "request.limit", requestLimit },
                { "request.locationIds", requestLocationIds },
                { "request.offset", requestOffset },
                { "request.staffIds", requestStaffIds },
                { "request.startDate", requestStartDate.HasValue ? requestStartDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetStaffAppointmentsResponse>(response.Body);
        }

        /// <summary>
        /// Get active appointment add-ons.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestStaffId">Optional parameter: Filter to add-ons only performed by this staff member..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetAddOnsResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetAddOnsResponse AppointmentGetAddOns(
                string version,
                string siteId,
                string authorization = null,
                int? requestLimit = null,
                int? requestOffset = null,
                int? requestStaffId = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetAddOnsResponse> t = this.AppointmentGetAddOnsAsync(version, siteId, authorization, requestLimit, requestOffset, requestStaffId);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Get active appointment add-ons.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestStaffId">Optional parameter: Filter to add-ons only performed by this staff member..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetAddOnsResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetAddOnsResponse> AppointmentGetAddOnsAsync(
                string version,
                string siteId,
                string authorization = null,
                int? requestLimit = null,
                int? requestOffset = null,
                int? requestStaffId = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/appointment/addons");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "request.limit", requestLimit },
                { "request.offset", requestOffset },
                { "request.staffId", requestStaffId },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetAddOnsResponse>(response.Body);
        }

        /// <summary>
        /// This endpoint books an add-on on top of an existing, regular appointment. To book an add-on, you must use an existing appointment ID and session type ID. You can get a session type ID using `GET AppointmentAddOns`.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentAddOnResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentAddOnResponse AppointmentAddAppointmentAddOn(
                string version,
                Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentAddOnRequest request,
                string siteId,
                string authorization = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentAddOnResponse> t = this.AppointmentAddAppointmentAddOnAsync(version, request, siteId, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// This endpoint books an add-on on top of an existing, regular appointment. To book an add-on, you must use an existing appointment ID and session type ID. You can get a session type ID using `GET AppointmentAddOns`.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentAddOnResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentAddOnResponse> AppointmentAddAppointmentAddOnAsync(
                string version,
                Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentAddOnRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/appointment/addappointmentaddon");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "Content-Type", "application/json" },
                { "authorization", authorization },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(request);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentAddOnResponse>(response.Body);
        }

        /// <summary>
        /// This endpoint can be used to early-cancel a booked appointment add-on.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="id">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        public void AppointmentDeleteAppointmentAddOn(
                string version,
                long id,
                string siteId,
                string authorization = null)
        {
            Task t = this.AppointmentDeleteAppointmentAddOnAsync(version, id, siteId, authorization);
            ApiHelper.RunTaskSynchronously(t);
        }

        /// <summary>
        /// This endpoint can be used to early-cancel a booked appointment add-on.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="id">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task AppointmentDeleteAppointmentAddOnAsync(
                string version,
                long id,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/appointment/deleteappointmentaddon");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "id", id },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Delete(queryBuilder.ToString(), headers, null, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);
        }

        /// <summary>
        /// Remove an appointment from waitlist.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestWaitlistEntryIds">Required parameter: A list of `WaitlistEntryIds` to remove from the waiting list..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the object response from the API call.</returns>
        public object AppointmentRemoveFromWaitlist(
                string version,
                List<int> requestWaitlistEntryIds,
                string siteId,
                string authorization = null)
        {
            Task<object> t = this.AppointmentRemoveFromWaitlistAsync(version, requestWaitlistEntryIds, siteId, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Remove an appointment from waitlist.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestWaitlistEntryIds">Required parameter: A list of `WaitlistEntryIds` to remove from the waiting list..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the object response from the API call.</returns>
        public async Task<object> AppointmentRemoveFromWaitlistAsync(
                string version,
                List<int> requestWaitlistEntryIds,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/appointment/appointmentfromwaitlist");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "request.waitlistEntryIds", requestWaitlistEntryIds },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Delete(queryBuilder.ToString(), headers, null, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return response.Body;
        }

        /// <summary>
        /// To update the information for a specific availability or unavailability of the staff.<br />.
        /// Note: You must have a staff user token with the required permissions.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="updateAvailabilityRequest">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAvailabilityResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAvailabilityResponse AppointmentUpdateAvailability(
                string version,
                string siteId,
                Models.MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAvailabilityRequest updateAvailabilityRequest,
                string authorization = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAvailabilityResponse> t = this.AppointmentUpdateAvailabilityAsync(version, siteId, updateAvailabilityRequest, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// To update the information for a specific availability or unavailability of the staff.<br />.
        /// Note: You must have a staff user token with the required permissions.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="updateAvailabilityRequest">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAvailabilityResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAvailabilityResponse> AppointmentUpdateAvailabilityAsync(
                string version,
                string siteId,
                Models.MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAvailabilityRequest updateAvailabilityRequest,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/appointment/availabilities");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "Content-Type", "application/json" },
                { "authorization", authorization },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(updateAvailabilityRequest);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PutBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAvailabilityResponse>(response.Body);
        }

        /// <summary>
        /// Add availabilities and unavailabilities for a staff member.<br />.
        /// Note: You must have a staff user token with the required permissions.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAvailabilitiesResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAvailabilitiesResponse AppointmentAddAvailabilities(
                string version,
                Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAvailabilitiesRequest request,
                string siteId,
                string authorization = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAvailabilitiesResponse> t = this.AppointmentAddAvailabilitiesAsync(version, request, siteId, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Add availabilities and unavailabilities for a staff member.<br />.
        /// Note: You must have a staff user token with the required permissions.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAvailabilitiesResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAvailabilitiesResponse> AppointmentAddAvailabilitiesAsync(
                string version,
                Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAvailabilitiesRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/appointment/availabilities");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "Content-Type", "application/json" },
                { "authorization", authorization },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(request);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAvailabilitiesResponse>(response.Body);
        }

        /// <summary>
        /// This endpoint deletes the availability or unavailability.
        /// Note: You must have a staff user token with the required permissions.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="deleteAvailabilityRequestAvailabilityId">Optional parameter: The ID of the availability or unavailability..</param>
        /// <param name="deleteAvailabilityRequestTest">Optional parameter: When `true`, indicates that this is a test request and no data is deleted from the subscriber’s database.  When `false`, the record will be deleted.  Default: **false**.</param>
        public void AppointmentDeleteAvailability(
                string version,
                string siteId,
                string authorization = null,
                int? deleteAvailabilityRequestAvailabilityId = null,
                bool? deleteAvailabilityRequestTest = null)
        {
            Task t = this.AppointmentDeleteAvailabilityAsync(version, siteId, authorization, deleteAvailabilityRequestAvailabilityId, deleteAvailabilityRequestTest);
            ApiHelper.RunTaskSynchronously(t);
        }

        /// <summary>
        /// This endpoint deletes the availability or unavailability.
        /// Note: You must have a staff user token with the required permissions.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="deleteAvailabilityRequestAvailabilityId">Optional parameter: The ID of the availability or unavailability..</param>
        /// <param name="deleteAvailabilityRequestTest">Optional parameter: When `true`, indicates that this is a test request and no data is deleted from the subscriber’s database.  When `false`, the record will be deleted.  Default: **false**.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task AppointmentDeleteAvailabilityAsync(
                string version,
                string siteId,
                string authorization = null,
                int? deleteAvailabilityRequestAvailabilityId = null,
                bool? deleteAvailabilityRequestTest = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/appointment/availability");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "deleteAvailabilityRequest.availabilityId", deleteAvailabilityRequestAvailabilityId },
                { "deleteAvailabilityRequest.test", deleteAvailabilityRequestTest },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Delete(queryBuilder.ToString(), headers, null, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);
        }

        /// <summary>
        /// Returns a list of unavailabilities. Unavailabilities are the times at which appointments cannot be booked, for example, on holidays or after hours when the business is closed.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestEndDate">Optional parameter: The end date of the requested date range.   <br />Default: **today’s date**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestStaffIds">Optional parameter: A list of requested staff IDs..</param>
        /// <param name="requestStartDate">Optional parameter: The start date of the requested date range.   <br />Default: **today’s date**.</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetUnavailabilitiesResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetUnavailabilitiesResponse AppointmentGetUnavailabilities(
                string version,
                string siteId,
                string authorization = null,
                DateTime? requestEndDate = null,
                int? requestLimit = null,
                int? requestOffset = null,
                List<long> requestStaffIds = null,
                DateTime? requestStartDate = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetUnavailabilitiesResponse> t = this.AppointmentGetUnavailabilitiesAsync(version, siteId, authorization, requestEndDate, requestLimit, requestOffset, requestStaffIds, requestStartDate);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Returns a list of unavailabilities. Unavailabilities are the times at which appointments cannot be booked, for example, on holidays or after hours when the business is closed.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestEndDate">Optional parameter: The end date of the requested date range.   <br />Default: **today’s date**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestStaffIds">Optional parameter: A list of requested staff IDs..</param>
        /// <param name="requestStartDate">Optional parameter: The start date of the requested date range.   <br />Default: **today’s date**.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetUnavailabilitiesResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetUnavailabilitiesResponse> AppointmentGetUnavailabilitiesAsync(
                string version,
                string siteId,
                string authorization = null,
                DateTime? requestEndDate = null,
                int? requestLimit = null,
                int? requestOffset = null,
                List<long> requestStaffIds = null,
                DateTime? requestStartDate = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/appointment/unavailabilities");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "request.endDate", requestEndDate.HasValue ? requestEndDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null },
                { "request.limit", requestLimit },
                { "request.offset", requestOffset },
                { "request.staffIds", requestStaffIds },
                { "request.startDate", requestStartDate.HasValue ? requestStartDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetUnavailabilitiesResponse>(response.Body);
        }
    }
}