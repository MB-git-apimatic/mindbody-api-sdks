// <copyright file="ClientController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Authentication;
    using MINDBODYPublicAPI.Standard.Http.Client;
    using MINDBODYPublicAPI.Standard.Http.Request;
    using MINDBODYPublicAPI.Standard.Http.Request.Configuration;
    using MINDBODYPublicAPI.Standard.Http.Response;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// ClientController.
    /// </summary>
    public class ClientController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ClientController"/> class.
        /// </summary>
        /// <param name="config"> config instance. </param>
        /// <param name="httpClient"> httpClient. </param>
        /// <param name="authManagers"> authManager. </param>
        internal ClientController(IConfiguration config, IHttpClient httpClient, IDictionary<string, IAuthManager> authManagers)
            : base(config, httpClient, authManagers)
        {
        }

        /// <summary>
        /// This endpoint requires staff user credentials. This endpoint supports pagination. See Pagination for a description of the Pagination information.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClientIDs">Optional parameter: The requested client IDs.  Default: **all IDs** that the authenticated user’s access level allows.<br />  Note: You can fetch information for maximum 20 clients at once..</param>
        /// <param name="requestIncludeInactive">Optional parameter: When `true`, indicates the results to include active and inactive clients.<br />  When `false`, indicates that only those clients who are marked as active should be returned.  Default: **false**.</param>
        /// <param name="requestIsProspect">Optional parameter: When `true`, filters the results to include only those clients marked as prospects for the business.<br />  When `false`, indicates that only those clients who are not marked prospects should be returned..</param>
        /// <param name="requestLastModifiedDate">Optional parameter: Filters the results to include only the clients that have been modified on or after this date..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestSearchText">Optional parameter: Text to use in the search. Can include FirstName, LastName, and Email. Note that user credentials must be provided..</param>
        /// <param name="requestUniqueIds">Optional parameter: Filters results to clients with these `UniqueIDs`. This parameter cannot be used with `ClientIDs` or `SearchText`.  Default: **all UniqueIDs** that the authenticated user’s access level allows..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientsResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientsResponse ClientGetClients(
                string version,
                string siteId,
                string authorization = null,
                List<string> requestClientIDs = null,
                bool? requestIncludeInactive = null,
                bool? requestIsProspect = null,
                DateTime? requestLastModifiedDate = null,
                int? requestLimit = null,
                int? requestOffset = null,
                string requestSearchText = null,
                List<long> requestUniqueIds = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientsResponse> t = this.ClientGetClientsAsync(version, siteId, authorization, requestClientIDs, requestIncludeInactive, requestIsProspect, requestLastModifiedDate, requestLimit, requestOffset, requestSearchText, requestUniqueIds);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// This endpoint requires staff user credentials. This endpoint supports pagination. See Pagination for a description of the Pagination information.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClientIDs">Optional parameter: The requested client IDs.  Default: **all IDs** that the authenticated user’s access level allows.<br />  Note: You can fetch information for maximum 20 clients at once..</param>
        /// <param name="requestIncludeInactive">Optional parameter: When `true`, indicates the results to include active and inactive clients.<br />  When `false`, indicates that only those clients who are marked as active should be returned.  Default: **false**.</param>
        /// <param name="requestIsProspect">Optional parameter: When `true`, filters the results to include only those clients marked as prospects for the business.<br />  When `false`, indicates that only those clients who are not marked prospects should be returned..</param>
        /// <param name="requestLastModifiedDate">Optional parameter: Filters the results to include only the clients that have been modified on or after this date..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestSearchText">Optional parameter: Text to use in the search. Can include FirstName, LastName, and Email. Note that user credentials must be provided..</param>
        /// <param name="requestUniqueIds">Optional parameter: Filters results to clients with these `UniqueIDs`. This parameter cannot be used with `ClientIDs` or `SearchText`.  Default: **all UniqueIDs** that the authenticated user’s access level allows..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientsResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientsResponse> ClientGetClientsAsync(
                string version,
                string siteId,
                string authorization = null,
                List<string> requestClientIDs = null,
                bool? requestIncludeInactive = null,
                bool? requestIsProspect = null,
                DateTime? requestLastModifiedDate = null,
                int? requestLimit = null,
                int? requestOffset = null,
                string requestSearchText = null,
                List<long> requestUniqueIds = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/client/clients");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "request.clientIDs", requestClientIDs },
                { "request.includeInactive", requestIncludeInactive },
                { "request.isProspect", requestIsProspect },
                { "request.lastModifiedDate", requestLastModifiedDate.HasValue ? requestLastModifiedDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null },
                { "request.limit", requestLimit },
                { "request.offset", requestOffset },
                { "request.searchText", requestSearchText },
                { "request.uniqueIds", requestUniqueIds },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientsResponse>(response.Body);
        }

        /// <summary>
        /// This endpoint gets client records that would be considered duplicates based on case-insensitive matching of the client’s first name, last name, and email. For there to be results, all three parameters must match a client record. This endpoint requires staff user credentials.
        ///             .
        /// An empty `ClientDuplicates` object in the response from this endpoint indicates that there were no client records found that match the first name, last name, and email fields passed in.
        ///             .
        /// If one client record is returned, it is not a duplicate itself, but no other client record can be created or updated that would match this client’s first name, last name, and email combination.
        ///             .
        /// If more than one client record is returned, these clients are duplicates of each other.We recommend discussing with the business how they would like to resolve duplicate records in the event the response contains more than one client record.Businesses can use the Merge Duplicate Clients tool in the Core Business Mode software to resolve the duplicate client records.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestEmail">Optional parameter: The client email to match on when searching for duplicates..</param>
        /// <param name="requestFirstName">Optional parameter: The client first name to match on when searching for duplicates..</param>
        /// <param name="requestLastName">Optional parameter: The client last name to match on when searching for duplicates..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientDuplicatesResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientDuplicatesResponse ClientGetClientDuplicates(
                string version,
                string siteId,
                string authorization = null,
                string requestEmail = null,
                string requestFirstName = null,
                string requestLastName = null,
                int? requestLimit = null,
                int? requestOffset = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientDuplicatesResponse> t = this.ClientGetClientDuplicatesAsync(version, siteId, authorization, requestEmail, requestFirstName, requestLastName, requestLimit, requestOffset);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// This endpoint gets client records that would be considered duplicates based on case-insensitive matching of the client’s first name, last name, and email. For there to be results, all three parameters must match a client record. This endpoint requires staff user credentials.
        ///             .
        /// An empty `ClientDuplicates` object in the response from this endpoint indicates that there were no client records found that match the first name, last name, and email fields passed in.
        ///             .
        /// If one client record is returned, it is not a duplicate itself, but no other client record can be created or updated that would match this client’s first name, last name, and email combination.
        ///             .
        /// If more than one client record is returned, these clients are duplicates of each other.We recommend discussing with the business how they would like to resolve duplicate records in the event the response contains more than one client record.Businesses can use the Merge Duplicate Clients tool in the Core Business Mode software to resolve the duplicate client records.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestEmail">Optional parameter: The client email to match on when searching for duplicates..</param>
        /// <param name="requestFirstName">Optional parameter: The client first name to match on when searching for duplicates..</param>
        /// <param name="requestLastName">Optional parameter: The client last name to match on when searching for duplicates..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientDuplicatesResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientDuplicatesResponse> ClientGetClientDuplicatesAsync(
                string version,
                string siteId,
                string authorization = null,
                string requestEmail = null,
                string requestFirstName = null,
                string requestLastName = null,
                int? requestLimit = null,
                int? requestOffset = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/client/clientduplicates");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "request.email", requestEmail },
                { "request.firstName", requestFirstName },
                { "request.lastName", requestLastName },
                { "request.limit", requestLimit },
                { "request.offset", requestOffset },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientDuplicatesResponse>(response.Body);
        }

        /// <summary>
        /// ***QueryParams***: Enables to retrieve cross regional formula notes for a client, or for a specific appointment. The two parameters are optional, however at least one must be provided. This endpoint supports pagination.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestAppointmentId">Optional parameter: The appointment ID of an appointment in the studio specified in the header of the request..</param>
        /// <param name="requestClientId">Optional parameter: The client ID of the client whose formula notes are being requested..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientFormulaNotesResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientFormulaNotesResponse ClientGetClientFormulaNotes(
                string version,
                string siteId,
                string authorization = null,
                long? requestAppointmentId = null,
                string requestClientId = null,
                int? requestLimit = null,
                int? requestOffset = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientFormulaNotesResponse> t = this.ClientGetClientFormulaNotesAsync(version, siteId, authorization, requestAppointmentId, requestClientId, requestLimit, requestOffset);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// ***QueryParams***: Enables to retrieve cross regional formula notes for a client, or for a specific appointment. The two parameters are optional, however at least one must be provided. This endpoint supports pagination.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestAppointmentId">Optional parameter: The appointment ID of an appointment in the studio specified in the header of the request..</param>
        /// <param name="requestClientId">Optional parameter: The client ID of the client whose formula notes are being requested..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientFormulaNotesResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientFormulaNotesResponse> ClientGetClientFormulaNotesAsync(
                string version,
                string siteId,
                string authorization = null,
                long? requestAppointmentId = null,
                string requestClientId = null,
                int? requestLimit = null,
                int? requestOffset = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/client/clientformulanotes");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "request.appointmentId", requestAppointmentId },
                { "request.clientId", requestClientId },
                { "request.limit", requestLimit },
                { "request.offset", requestOffset },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientFormulaNotesResponse>(response.Body);
        }

        /// <summary>
        /// This endpoint deletes an existing formula note. A staff user token must be included with staff assigned permission to view client profile or have both ViewAppointmentDetails and ModifyAppointment permissions.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestClientId">Required parameter: The client ID of the client whose formula note needs to be deleted..</param>
        /// <param name="requestFormulaNoteId">Required parameter: The formula note ID for the note to be deleted..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        public void ClientDeleteClientFormulaNote(
                string version,
                string requestClientId,
                long requestFormulaNoteId,
                string siteId,
                string authorization = null,
                int? requestLimit = null,
                int? requestOffset = null)
        {
            Task t = this.ClientDeleteClientFormulaNoteAsync(version, requestClientId, requestFormulaNoteId, siteId, authorization, requestLimit, requestOffset);
            ApiHelper.RunTaskSynchronously(t);
        }

        /// <summary>
        /// This endpoint deletes an existing formula note. A staff user token must be included with staff assigned permission to view client profile or have both ViewAppointmentDetails and ModifyAppointment permissions.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestClientId">Required parameter: The client ID of the client whose formula note needs to be deleted..</param>
        /// <param name="requestFormulaNoteId">Required parameter: The formula note ID for the note to be deleted..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task ClientDeleteClientFormulaNoteAsync(
                string version,
                string requestClientId,
                long requestFormulaNoteId,
                string siteId,
                string authorization = null,
                int? requestLimit = null,
                int? requestOffset = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/client/clientformulanote");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "request.clientId", requestClientId },
                { "request.formulaNoteId", requestFormulaNoteId },
                { "request.limit", requestLimit },
                { "request.offset", requestOffset },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Delete(queryBuilder.ToString(), headers, null, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);
        }

        /// <summary>
        /// This endpoint adds a formula note for a specified client or specified client appointment. A staff user token must be included with staff assigned permission to view client profile or have both ViewAppointmentDetails and ModifyAppointment permissions.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerFormulaNoteResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6ClientControllerFormulaNoteResponse ClientAddFormulaNote(
                string version,
                Models.MindbodyPublicApiDtoModelsV6ClientControllerAddFormulaNoteRequest request,
                string siteId,
                string authorization = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerFormulaNoteResponse> t = this.ClientAddFormulaNoteAsync(version, request, siteId, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// This endpoint adds a formula note for a specified client or specified client appointment. A staff user token must be included with staff assigned permission to view client profile or have both ViewAppointmentDetails and ModifyAppointment permissions.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerFormulaNoteResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerFormulaNoteResponse> ClientAddFormulaNoteAsync(
                string version,
                Models.MindbodyPublicApiDtoModelsV6ClientControllerAddFormulaNoteRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/client/addclientformulanote");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "Content-Type", "application/json" },
                { "authorization", authorization },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(request);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6ClientControllerFormulaNoteResponse>(response.Body);
        }

        /// <summary>
        /// Uploads a document file for a specific client. Returns a string representation of the image byte array. The maximum size file that can be uploaded is **4MB**.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerUploadClientDocumentResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6ClientControllerUploadClientDocumentResponse ClientUploadClientDocument(
                string version,
                Models.MindbodyPublicApiDtoModelsV6ClientControllerUploadClientDocumentRequest request,
                string siteId,
                string authorization = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerUploadClientDocumentResponse> t = this.ClientUploadClientDocumentAsync(version, request, siteId, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Uploads a document file for a specific client. Returns a string representation of the image byte array. The maximum size file that can be uploaded is **4MB**.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerUploadClientDocumentResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerUploadClientDocumentResponse> ClientUploadClientDocumentAsync(
                string version,
                Models.MindbodyPublicApiDtoModelsV6ClientControllerUploadClientDocumentRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/client/uploadclientdocument");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "Content-Type", "application/json" },
                { "authorization", authorization },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(request);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6ClientControllerUploadClientDocumentResponse>(response.Body);
        }

        /// <summary>
        /// Uploads a client’s profile photo. The maximum file size is 4 MB and acceptable file types are:.
        /// * bmp.
        /// * jpeg.
        /// * gif.
        /// * tiff.
        /// * png.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerUploadClientPhotoResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6ClientControllerUploadClientPhotoResponse ClientUploadClientPhoto(
                string version,
                Models.MindbodyPublicApiDtoModelsV6ClientControllerUploadClientPhotoRequest request,
                string siteId,
                string authorization = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerUploadClientPhotoResponse> t = this.ClientUploadClientPhotoAsync(version, request, siteId, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Uploads a client’s profile photo. The maximum file size is 4 MB and acceptable file types are:.
        /// * bmp.
        /// * jpeg.
        /// * gif.
        /// * tiff.
        /// * png.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerUploadClientPhotoResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerUploadClientPhotoResponse> ClientUploadClientPhotoAsync(
                string version,
                Models.MindbodyPublicApiDtoModelsV6ClientControllerUploadClientPhotoRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/client/uploadclientphoto");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "Content-Type", "application/json" },
                { "authorization", authorization },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(request);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6ClientControllerUploadClientPhotoResponse>(response.Body);
        }

        /// <summary>
        /// Get contracts that a client has purchased.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestClientId">Required parameter: The ID of the client..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClientAssociatedSitesOffset">Optional parameter: Determines how many sites are skipped over when retrieving a client’s cross regional contracts. Used when a client ID is linked to more than ten sites in an organization. Only a maximum of ten site databases are queried when this call is made and `CrossRegionalLookup` is set to `true`. To change which sites are queried, change this offset value.  Default: **0**.</param>
        /// <param name="requestCrossRegionalLookup">Optional parameter: When `true`, indicates that the requesting client’s cross regional contracts are returned, if any.<br />  When `false`, indicates that cross regional contracts are not returned..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientContractsResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientContractsResponse ClientGetClientContracts(
                string version,
                string requestClientId,
                string siteId,
                string authorization = null,
                int? requestClientAssociatedSitesOffset = null,
                bool? requestCrossRegionalLookup = null,
                int? requestLimit = null,
                int? requestOffset = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientContractsResponse> t = this.ClientGetClientContractsAsync(version, requestClientId, siteId, authorization, requestClientAssociatedSitesOffset, requestCrossRegionalLookup, requestLimit, requestOffset);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Get contracts that a client has purchased.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestClientId">Required parameter: The ID of the client..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClientAssociatedSitesOffset">Optional parameter: Determines how many sites are skipped over when retrieving a client’s cross regional contracts. Used when a client ID is linked to more than ten sites in an organization. Only a maximum of ten site databases are queried when this call is made and `CrossRegionalLookup` is set to `true`. To change which sites are queried, change this offset value.  Default: **0**.</param>
        /// <param name="requestCrossRegionalLookup">Optional parameter: When `true`, indicates that the requesting client’s cross regional contracts are returned, if any.<br />  When `false`, indicates that cross regional contracts are not returned..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientContractsResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientContractsResponse> ClientGetClientContractsAsync(
                string version,
                string requestClientId,
                string siteId,
                string authorization = null,
                int? requestClientAssociatedSitesOffset = null,
                bool? requestCrossRegionalLookup = null,
                int? requestLimit = null,
                int? requestOffset = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/client/clientcontracts");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "request.clientId", requestClientId },
                { "request.clientAssociatedSitesOffset", requestClientAssociatedSitesOffset },
                { "request.crossRegionalLookup", requestCrossRegionalLookup },
                { "request.limit", requestLimit },
                { "request.offset", requestOffset },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientContractsResponse>(response.Body);
        }

        /// <summary>
        /// Get pricing options that a client has purchased.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestClientId">Required parameter: The ID of the client to query. The results are a list of pricing options that the client has purchased. Note that “service” and “pricing option” are synonymous in this section of the documentation..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClassId">Optional parameter: Filters results to only those pricing options that can be used to pay for this class..</param>
        /// <param name="requestClientAssociatedSitesOffset">Optional parameter: Used to retrieve a client’s pricing options from multiple sites within an organization when the client is associated with more than ten sites. To change which ten sites are searched, change this offset value. A value of 0 means that no sites are skipped and the first ten sites are returned. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that you must always have `CrossRegionalLookup` set to `true` to use this parameter.<br />  Default: **0**    For example, if a client is associated with 25 sites, you need to call `GetClientServices` three times, as follows:  * Use `GET CrossRegionalClientAssociations` to determine how many sites a client is associated with, which tells you how many additional calls you need to make.  * Either omit `ClientAssociatedSitesOffset` or set it to 0 to return the client’s services (pricing options) from sites 1-10.  * Set `ClientAssociatedSitesOffset` to 10 to return the client pricing options from sites 11-20  * Set `ClientAssociatedSitesOffset` to 20 to return the client pricing options from sites 21-25.</param>
        /// <param name="requestCrossRegionalLookup">Optional parameter: Used to retrieve a client’s pricing options from multiple sites within an organization. When included and set to `true`, it searches a maximum of ten sites with which this client is associated. When a client is associated with more than ten sites, use `ClientAssociatedSitesOffset` as many times as needed to search the additional sites with which the client is associated. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that a `SiteID` is returned and populated in the `ClientServices` response when `CrossRegionalLookup` is set to `true`.  Default: **false**.</param>
        /// <param name="requestEndDate">Optional parameter: Filters results to pricing options that are valid on or before this date.  Default: **today’s date**.</param>
        /// <param name="requestIgnoreCrossRegionalSiteLimit">Optional parameter: Used to specify if the number of cross regional sites used to search for client’s pricing options should be ignored.   Default: **false**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationIds">Optional parameter: Filters results to pricing options that can be used at the listed location IDs..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestProgramIds">Optional parameter: Filters results to pricing options that belong to one of the given program IDs..</param>
        /// <param name="requestSessionTypeId">Optional parameter: Filters results to pricing options that will pay for the given session type ID. Use this to find pricing options that will pay for a specific appointment type..</param>
        /// <param name="requestShowActiveOnly">Optional parameter: When `true`, includes active services only.  Default: **false**.</param>
        /// <param name="requestStartDate">Optional parameter: Filters results to pricing options that are valid on or after this date.  Default: **today’s date**.</param>
        /// <param name="requestVisitCount">Optional parameter: A filter on the minimum number of visits a service can pay for..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientServicesResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientServicesResponse ClientGetClientServices(
                string version,
                string requestClientId,
                string siteId,
                string authorization = null,
                int? requestClassId = null,
                int? requestClientAssociatedSitesOffset = null,
                bool? requestCrossRegionalLookup = null,
                DateTime? requestEndDate = null,
                bool? requestIgnoreCrossRegionalSiteLimit = null,
                int? requestLimit = null,
                List<int> requestLocationIds = null,
                int? requestOffset = null,
                List<int> requestProgramIds = null,
                int? requestSessionTypeId = null,
                bool? requestShowActiveOnly = null,
                DateTime? requestStartDate = null,
                int? requestVisitCount = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientServicesResponse> t = this.ClientGetClientServicesAsync(version, requestClientId, siteId, authorization, requestClassId, requestClientAssociatedSitesOffset, requestCrossRegionalLookup, requestEndDate, requestIgnoreCrossRegionalSiteLimit, requestLimit, requestLocationIds, requestOffset, requestProgramIds, requestSessionTypeId, requestShowActiveOnly, requestStartDate, requestVisitCount);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Get pricing options that a client has purchased.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestClientId">Required parameter: The ID of the client to query. The results are a list of pricing options that the client has purchased. Note that “service” and “pricing option” are synonymous in this section of the documentation..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClassId">Optional parameter: Filters results to only those pricing options that can be used to pay for this class..</param>
        /// <param name="requestClientAssociatedSitesOffset">Optional parameter: Used to retrieve a client’s pricing options from multiple sites within an organization when the client is associated with more than ten sites. To change which ten sites are searched, change this offset value. A value of 0 means that no sites are skipped and the first ten sites are returned. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that you must always have `CrossRegionalLookup` set to `true` to use this parameter.<br />  Default: **0**    For example, if a client is associated with 25 sites, you need to call `GetClientServices` three times, as follows:  * Use `GET CrossRegionalClientAssociations` to determine how many sites a client is associated with, which tells you how many additional calls you need to make.  * Either omit `ClientAssociatedSitesOffset` or set it to 0 to return the client’s services (pricing options) from sites 1-10.  * Set `ClientAssociatedSitesOffset` to 10 to return the client pricing options from sites 11-20  * Set `ClientAssociatedSitesOffset` to 20 to return the client pricing options from sites 21-25.</param>
        /// <param name="requestCrossRegionalLookup">Optional parameter: Used to retrieve a client’s pricing options from multiple sites within an organization. When included and set to `true`, it searches a maximum of ten sites with which this client is associated. When a client is associated with more than ten sites, use `ClientAssociatedSitesOffset` as many times as needed to search the additional sites with which the client is associated. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that a `SiteID` is returned and populated in the `ClientServices` response when `CrossRegionalLookup` is set to `true`.  Default: **false**.</param>
        /// <param name="requestEndDate">Optional parameter: Filters results to pricing options that are valid on or before this date.  Default: **today’s date**.</param>
        /// <param name="requestIgnoreCrossRegionalSiteLimit">Optional parameter: Used to specify if the number of cross regional sites used to search for client’s pricing options should be ignored.   Default: **false**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationIds">Optional parameter: Filters results to pricing options that can be used at the listed location IDs..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestProgramIds">Optional parameter: Filters results to pricing options that belong to one of the given program IDs..</param>
        /// <param name="requestSessionTypeId">Optional parameter: Filters results to pricing options that will pay for the given session type ID. Use this to find pricing options that will pay for a specific appointment type..</param>
        /// <param name="requestShowActiveOnly">Optional parameter: When `true`, includes active services only.  Default: **false**.</param>
        /// <param name="requestStartDate">Optional parameter: Filters results to pricing options that are valid on or after this date.  Default: **today’s date**.</param>
        /// <param name="requestVisitCount">Optional parameter: A filter on the minimum number of visits a service can pay for..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientServicesResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientServicesResponse> ClientGetClientServicesAsync(
                string version,
                string requestClientId,
                string siteId,
                string authorization = null,
                int? requestClassId = null,
                int? requestClientAssociatedSitesOffset = null,
                bool? requestCrossRegionalLookup = null,
                DateTime? requestEndDate = null,
                bool? requestIgnoreCrossRegionalSiteLimit = null,
                int? requestLimit = null,
                List<int> requestLocationIds = null,
                int? requestOffset = null,
                List<int> requestProgramIds = null,
                int? requestSessionTypeId = null,
                bool? requestShowActiveOnly = null,
                DateTime? requestStartDate = null,
                int? requestVisitCount = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/client/clientservices");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "request.clientId", requestClientId },
                { "request.classId", requestClassId },
                { "request.clientAssociatedSitesOffset", requestClientAssociatedSitesOffset },
                { "request.crossRegionalLookup", requestCrossRegionalLookup },
                { "request.endDate", requestEndDate.HasValue ? requestEndDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null },
                { "request.ignoreCrossRegionalSiteLimit", requestIgnoreCrossRegionalSiteLimit },
                { "request.limit", requestLimit },
                { "request.locationIds", requestLocationIds },
                { "request.offset", requestOffset },
                { "request.programIds", requestProgramIds },
                { "request.sessionTypeId", requestSessionTypeId },
                { "request.showActiveOnly", requestShowActiveOnly },
                { "request.startDate", requestStartDate.HasValue ? requestStartDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null },
                { "request.visitCount", requestVisitCount },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientServicesResponse>(response.Body);
        }

        /// <summary>
        /// Gets the Client Visits for a specific client.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestClientId">Required parameter: The ID of the requested client..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClientAssociatedSitesOffset">Optional parameter: The number of sites to skip when returning the site associated with a client..</param>
        /// <param name="requestCrossRegionalLookup">Optional parameter: When `true`, indicates that past and scheduled client visits across all sites in the region are returned.<br />  When `false`, indicates that only visits at the current site are returned..</param>
        /// <param name="requestEndDate">Optional parameter: The date past which class visits are not returned.  Default: **today’s date**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestStartDate">Optional parameter: The date before which class visits are not returned.  Default: **the end date**.</param>
        /// <param name="requestUnpaidsOnly">Optional parameter: When `true`, indicates that only visits that have not been paid for are returned.<br />  When `false`, indicates that all visits are returned, regardless of whether they have been paid for.<br />  Default: **false**.</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientVisitsResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientVisitsResponse ClientGetClientVisits(
                string version,
                string requestClientId,
                string siteId,
                string authorization = null,
                int? requestClientAssociatedSitesOffset = null,
                bool? requestCrossRegionalLookup = null,
                DateTime? requestEndDate = null,
                int? requestLimit = null,
                int? requestOffset = null,
                DateTime? requestStartDate = null,
                bool? requestUnpaidsOnly = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientVisitsResponse> t = this.ClientGetClientVisitsAsync(version, requestClientId, siteId, authorization, requestClientAssociatedSitesOffset, requestCrossRegionalLookup, requestEndDate, requestLimit, requestOffset, requestStartDate, requestUnpaidsOnly);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Gets the Client Visits for a specific client.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestClientId">Required parameter: The ID of the requested client..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClientAssociatedSitesOffset">Optional parameter: The number of sites to skip when returning the site associated with a client..</param>
        /// <param name="requestCrossRegionalLookup">Optional parameter: When `true`, indicates that past and scheduled client visits across all sites in the region are returned.<br />  When `false`, indicates that only visits at the current site are returned..</param>
        /// <param name="requestEndDate">Optional parameter: The date past which class visits are not returned.  Default: **today’s date**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestStartDate">Optional parameter: The date before which class visits are not returned.  Default: **the end date**.</param>
        /// <param name="requestUnpaidsOnly">Optional parameter: When `true`, indicates that only visits that have not been paid for are returned.<br />  When `false`, indicates that all visits are returned, regardless of whether they have been paid for.<br />  Default: **false**.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientVisitsResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientVisitsResponse> ClientGetClientVisitsAsync(
                string version,
                string requestClientId,
                string siteId,
                string authorization = null,
                int? requestClientAssociatedSitesOffset = null,
                bool? requestCrossRegionalLookup = null,
                DateTime? requestEndDate = null,
                int? requestLimit = null,
                int? requestOffset = null,
                DateTime? requestStartDate = null,
                bool? requestUnpaidsOnly = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/client/clientvisits");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "request.clientId", requestClientId },
                { "request.clientAssociatedSitesOffset", requestClientAssociatedSitesOffset },
                { "request.crossRegionalLookup", requestCrossRegionalLookup },
                { "request.endDate", requestEndDate.HasValue ? requestEndDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null },
                { "request.limit", requestLimit },
                { "request.offset", requestOffset },
                { "request.startDate", requestStartDate.HasValue ? requestStartDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null },
                { "request.unpaidsOnly", requestUnpaidsOnly },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientVisitsResponse>(response.Body);
        }

        /// <summary>
        /// This endpoint can be utilized to retrieve scheduled visits which is associated with the requested client.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestClientId">Required parameter: The ID of the requested client..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClientAssociatedSitesOffset">Optional parameter: The number of sites to skip when returning the site associated with a client..</param>
        /// <param name="requestCrossRegionalLookup">Optional parameter: When `true`, indicates that past and scheduled client visits across all sites in the region are returned.  When `false`, indicates that only visits at the current site are returned..</param>
        /// <param name="requestEndDate">Optional parameter: The date past which class visits are not returned.  Default is today’s date.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestStartDate">Optional parameter: The date before which class visits are not returned.  Default is the end date.</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientScheduleResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientScheduleResponse ClientGetClientSchedule(
                string version,
                string requestClientId,
                string siteId,
                string authorization = null,
                int? requestClientAssociatedSitesOffset = null,
                bool? requestCrossRegionalLookup = null,
                DateTime? requestEndDate = null,
                int? requestLimit = null,
                int? requestOffset = null,
                DateTime? requestStartDate = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientScheduleResponse> t = this.ClientGetClientScheduleAsync(version, requestClientId, siteId, authorization, requestClientAssociatedSitesOffset, requestCrossRegionalLookup, requestEndDate, requestLimit, requestOffset, requestStartDate);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// This endpoint can be utilized to retrieve scheduled visits which is associated with the requested client.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestClientId">Required parameter: The ID of the requested client..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClientAssociatedSitesOffset">Optional parameter: The number of sites to skip when returning the site associated with a client..</param>
        /// <param name="requestCrossRegionalLookup">Optional parameter: When `true`, indicates that past and scheduled client visits across all sites in the region are returned.  When `false`, indicates that only visits at the current site are returned..</param>
        /// <param name="requestEndDate">Optional parameter: The date past which class visits are not returned.  Default is today’s date.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestStartDate">Optional parameter: The date before which class visits are not returned.  Default is the end date.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientScheduleResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientScheduleResponse> ClientGetClientScheduleAsync(
                string version,
                string requestClientId,
                string siteId,
                string authorization = null,
                int? requestClientAssociatedSitesOffset = null,
                bool? requestCrossRegionalLookup = null,
                DateTime? requestEndDate = null,
                int? requestLimit = null,
                int? requestOffset = null,
                DateTime? requestStartDate = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/client/clientschedule");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "request.clientId", requestClientId },
                { "request.clientAssociatedSitesOffset", requestClientAssociatedSitesOffset },
                { "request.crossRegionalLookup", requestCrossRegionalLookup },
                { "request.endDate", requestEndDate.HasValue ? requestEndDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null },
                { "request.limit", requestLimit },
                { "request.offset", requestOffset },
                { "request.startDate", requestStartDate.HasValue ? requestStartDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientScheduleResponse>(response.Body);
        }

        /// <summary>
        /// Please note that client memberships with location restrictions can only be used to pay for scheduled services at the site to which they belong. Memberships with location restrictions can not be used to pay for scheduled services at other sites within an organization.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestClientId">Required parameter: The ID of the client for whom memberships are returned..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClientAssociatedSitesOffset">Optional parameter: Used to retrieve a client’s memberships from multiple sites within an organization when the client is associated with more than ten sites. To change which ten sites are searched, change this offset value. A value of 0 means that no sites are skipped and the first ten sites are returned. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that you must always have `CrossRegionalLookup` set to `true` to use this parameter.<br />  Default: **0**    For example, if a client is associated with 25 sites, you need to call `GetClientServices` three times, as follows:  * Use `GET CrossRegionalClientAssociations` to determine how many sites a client is associated with, which tells you how many additional calls you need to make.  * Either omit `ClientAssociatedSitesOffset` or set it to 0 to return the client’s services (pricing options) from sites 1-10.  * Set `ClientAssociatedSitesOffset` to 10 to return the client pricing options from sites 11-20  * Set `ClientAssociatedSitesOffset` to 20 to return the client pricing options from sites 21-25.</param>
        /// <param name="requestCrossRegionalLookup">Optional parameter: Used to retrieve a client’s memberships from multiple sites within an organization. When included and set to `true`, it searches a maximum of ten sites with which this client is associated. When a client is associated with more than ten sites, use `ClientAssociatedSitesOffset` as many times as needed to search the additional sites with which the client is associated. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that a `SiteID` is returned and populated in the `ClientServices` response when `CrossRegionalLookup` is set to `true`.  Default: **false**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationId">Optional parameter: Filters results to memberships that can be used to pay for scheduled services at that location. This parameter can not be passed when `CrossRegionalLookup` is `true`..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerGetActiveClientMembershipsResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6ClientControllerGetActiveClientMembershipsResponse ClientGetActiveClientMemberships(
                string version,
                string requestClientId,
                string siteId,
                string authorization = null,
                int? requestClientAssociatedSitesOffset = null,
                bool? requestCrossRegionalLookup = null,
                int? requestLimit = null,
                int? requestLocationId = null,
                int? requestOffset = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetActiveClientMembershipsResponse> t = this.ClientGetActiveClientMembershipsAsync(version, requestClientId, siteId, authorization, requestClientAssociatedSitesOffset, requestCrossRegionalLookup, requestLimit, requestLocationId, requestOffset);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Please note that client memberships with location restrictions can only be used to pay for scheduled services at the site to which they belong. Memberships with location restrictions can not be used to pay for scheduled services at other sites within an organization.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestClientId">Required parameter: The ID of the client for whom memberships are returned..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClientAssociatedSitesOffset">Optional parameter: Used to retrieve a client’s memberships from multiple sites within an organization when the client is associated with more than ten sites. To change which ten sites are searched, change this offset value. A value of 0 means that no sites are skipped and the first ten sites are returned. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that you must always have `CrossRegionalLookup` set to `true` to use this parameter.<br />  Default: **0**    For example, if a client is associated with 25 sites, you need to call `GetClientServices` three times, as follows:  * Use `GET CrossRegionalClientAssociations` to determine how many sites a client is associated with, which tells you how many additional calls you need to make.  * Either omit `ClientAssociatedSitesOffset` or set it to 0 to return the client’s services (pricing options) from sites 1-10.  * Set `ClientAssociatedSitesOffset` to 10 to return the client pricing options from sites 11-20  * Set `ClientAssociatedSitesOffset` to 20 to return the client pricing options from sites 21-25.</param>
        /// <param name="requestCrossRegionalLookup">Optional parameter: Used to retrieve a client’s memberships from multiple sites within an organization. When included and set to `true`, it searches a maximum of ten sites with which this client is associated. When a client is associated with more than ten sites, use `ClientAssociatedSitesOffset` as many times as needed to search the additional sites with which the client is associated. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that a `SiteID` is returned and populated in the `ClientServices` response when `CrossRegionalLookup` is set to `true`.  Default: **false**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationId">Optional parameter: Filters results to memberships that can be used to pay for scheduled services at that location. This parameter can not be passed when `CrossRegionalLookup` is `true`..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerGetActiveClientMembershipsResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetActiveClientMembershipsResponse> ClientGetActiveClientMembershipsAsync(
                string version,
                string requestClientId,
                string siteId,
                string authorization = null,
                int? requestClientAssociatedSitesOffset = null,
                bool? requestCrossRegionalLookup = null,
                int? requestLimit = null,
                int? requestLocationId = null,
                int? requestOffset = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/client/activeclientmemberships");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "request.clientId", requestClientId },
                { "request.clientAssociatedSitesOffset", requestClientAssociatedSitesOffset },
                { "request.crossRegionalLookup", requestCrossRegionalLookup },
                { "request.limit", requestLimit },
                { "request.locationId", requestLocationId },
                { "request.offset", requestOffset },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetActiveClientMembershipsResponse>(response.Body);
        }

        /// <summary>
        /// Gets the list of fields that a new client has to fill out in business mode, specifically for the sign-up process. `AddClient` and `UpdateClient` validate against these fields.
        /// This endpoint has no query parameters.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerGetRequiredClientFieldsResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6ClientControllerGetRequiredClientFieldsResponse ClientGetRequiredClientFields(
                string version,
                string siteId,
                string authorization = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetRequiredClientFieldsResponse> t = this.ClientGetRequiredClientFieldsAsync(version, siteId, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Gets the list of fields that a new client has to fill out in business mode, specifically for the sign-up process. `AddClient` and `UpdateClient` validate against these fields.
        /// This endpoint has no query parameters.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerGetRequiredClientFieldsResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetRequiredClientFieldsResponse> ClientGetRequiredClientFieldsAsync(
                string version,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/client/requiredclientfields");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetRequiredClientFieldsResponse>(response.Body);
        }

        /// <summary>
        /// Gets a list of referral types. Referral types are options that new clients can choose to identify how they learned about the business. Referral types are typically used for the sign-up process.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestIncludeInactive">Optional parameter: When `true`, filters the results to include subtypes and inactive referral types.<br />  When `false`, includes no subtypes and only active types.  Default:**false**.</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientReferralTypesResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientReferralTypesResponse ClientGetClientReferralTypes(
                string version,
                string siteId,
                string authorization = null,
                bool? requestIncludeInactive = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientReferralTypesResponse> t = this.ClientGetClientReferralTypesAsync(version, siteId, authorization, requestIncludeInactive);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Gets a list of referral types. Referral types are options that new clients can choose to identify how they learned about the business. Referral types are typically used for the sign-up process.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestIncludeInactive">Optional parameter: When `true`, filters the results to include subtypes and inactive referral types.<br />  When `false`, includes no subtypes and only active types.  Default:**false**.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientReferralTypesResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientReferralTypesResponse> ClientGetClientReferralTypesAsync(
                string version,
                string siteId,
                string authorization = null,
                bool? requestIncludeInactive = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/client/clientreferraltypes");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "request.includeInactive", requestIncludeInactive },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientReferralTypesResponse>(response.Body);
        }

        /// <summary>
        /// Get account balance information for one or more client(s).
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestClientIds">Required parameter: The list of clients IDs for which you want account balances..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestBalanceDate">Optional parameter: The date you want a balance relative to.   Default: **the current date**.</param>
        /// <param name="requestClassId">Optional parameter: The class ID of the event for which you want a balance..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientAccountBalancesResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientAccountBalancesResponse ClientGetClientAccountBalances(
                string version,
                List<string> requestClientIds,
                string siteId,
                string authorization = null,
                DateTime? requestBalanceDate = null,
                int? requestClassId = null,
                int? requestLimit = null,
                int? requestOffset = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientAccountBalancesResponse> t = this.ClientGetClientAccountBalancesAsync(version, requestClientIds, siteId, authorization, requestBalanceDate, requestClassId, requestLimit, requestOffset);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Get account balance information for one or more client(s).
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestClientIds">Required parameter: The list of clients IDs for which you want account balances..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestBalanceDate">Optional parameter: The date you want a balance relative to.   Default: **the current date**.</param>
        /// <param name="requestClassId">Optional parameter: The class ID of the event for which you want a balance..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientAccountBalancesResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientAccountBalancesResponse> ClientGetClientAccountBalancesAsync(
                string version,
                List<string> requestClientIds,
                string siteId,
                string authorization = null,
                DateTime? requestBalanceDate = null,
                int? requestClassId = null,
                int? requestLimit = null,
                int? requestOffset = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/client/clientaccountbalances");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "request.clientIds", requestClientIds },
                { "request.balanceDate", requestBalanceDate.HasValue ? requestBalanceDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null },
                { "request.classId", requestClassId },
                { "request.limit", requestLimit },
                { "request.offset", requestOffset },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientAccountBalancesResponse>(response.Body);
        }

        /// <summary>
        /// Gets a list of purchases made by a specific client.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestClientId">Required parameter: The ID of the client you are querying for purchases..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestEndDate">Optional parameter: Filters results to purchases made before this timestamp.<br />  Default: **end of today**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestSaleId">Optional parameter: Filters results to the single record associated with this ID..</param>
        /// <param name="requestStartDate">Optional parameter: Filters results to purchases made on or after this timestamp.<br />  Default: **now**.</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientPurchasesResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientPurchasesResponse ClientGetClientPurchases(
                string version,
                string requestClientId,
                string siteId,
                string authorization = null,
                DateTime? requestEndDate = null,
                int? requestLimit = null,
                int? requestOffset = null,
                int? requestSaleId = null,
                DateTime? requestStartDate = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientPurchasesResponse> t = this.ClientGetClientPurchasesAsync(version, requestClientId, siteId, authorization, requestEndDate, requestLimit, requestOffset, requestSaleId, requestStartDate);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Gets a list of purchases made by a specific client.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestClientId">Required parameter: The ID of the client you are querying for purchases..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestEndDate">Optional parameter: Filters results to purchases made before this timestamp.<br />  Default: **end of today**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestSaleId">Optional parameter: Filters results to the single record associated with this ID..</param>
        /// <param name="requestStartDate">Optional parameter: Filters results to purchases made on or after this timestamp.<br />  Default: **now**.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientPurchasesResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientPurchasesResponse> ClientGetClientPurchasesAsync(
                string version,
                string requestClientId,
                string siteId,
                string authorization = null,
                DateTime? requestEndDate = null,
                int? requestLimit = null,
                int? requestOffset = null,
                int? requestSaleId = null,
                DateTime? requestStartDate = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/client/clientpurchases");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "request.clientId", requestClientId },
                { "request.endDate", requestEndDate.HasValue ? requestEndDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null },
                { "request.limit", requestLimit },
                { "request.offset", requestOffset },
                { "request.saleId", requestSaleId },
                { "request.startDate", requestStartDate.HasValue ? requestStartDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientPurchasesResponse>(response.Body);
        }

        /// <summary>
        /// Client indexes are used to analyze client demographics. A business owner can set up different categories with sets of values which they can assign to each client. Client indexes are used in client searches, for tagging clients so that the owner can send mass emails to similar groups, and for many reports.
        /// For more information, see Client Indexes and [Client Index Values (video tutorial)](https://support.mindbodyonline.com/s/article/203261653-Client-indexes-and-client-index-values-video-tutorial?language=en_USclient).
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestRequiredOnly">Optional parameter: When `true`, filters the results to only indexes that are required on creation.<br />  When `false` or omitted, returns all of the client indexes..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientIndexesResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientIndexesResponse ClientGetClientIndexes(
                string version,
                string siteId,
                string authorization = null,
                bool? requestRequiredOnly = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientIndexesResponse> t = this.ClientGetClientIndexesAsync(version, siteId, authorization, requestRequiredOnly);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Client indexes are used to analyze client demographics. A business owner can set up different categories with sets of values which they can assign to each client. Client indexes are used in client searches, for tagging clients so that the owner can send mass emails to similar groups, and for many reports.
        /// For more information, see Client Indexes and [Client Index Values (video tutorial)](https://support.mindbodyonline.com/s/article/203261653-Client-indexes-and-client-index-values-video-tutorial?language=en_USclient).
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestRequiredOnly">Optional parameter: When `true`, filters the results to only indexes that are required on creation.<br />  When `false` or omitted, returns all of the client indexes..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientIndexesResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientIndexesResponse> ClientGetClientIndexesAsync(
                string version,
                string siteId,
                string authorization = null,
                bool? requestRequiredOnly = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/client/clientindexes");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "request.requiredOnly", requestRequiredOnly },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientIndexesResponse>(response.Body);
        }

        /// <summary>
        /// Get a site's configured custom client fields.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerGetCustomClientFieldsResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6ClientControllerGetCustomClientFieldsResponse ClientGetCustomClientFields(
                string version,
                string siteId,
                string authorization = null,
                int? requestLimit = null,
                int? requestOffset = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetCustomClientFieldsResponse> t = this.ClientGetCustomClientFieldsAsync(version, siteId, authorization, requestLimit, requestOffset);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Get a site's configured custom client fields.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerGetCustomClientFieldsResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetCustomClientFieldsResponse> ClientGetCustomClientFieldsAsync(
                string version,
                string siteId,
                string authorization = null,
                int? requestLimit = null,
                int? requestOffset = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/client/customclientfields");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "request.limit", requestLimit },
                { "request.offset", requestOffset },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetCustomClientFieldsResponse>(response.Body);
        }

        /// <summary>
        /// Add a contact log to a client's account.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ContactLog response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6ContactLog ClientAddContactLog(
                string version,
                Models.MindbodyPublicApiDtoModelsV6ClientControllerAddContactLogRequest request,
                string siteId,
                string authorization = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6ContactLog> t = this.ClientAddContactLogAsync(version, request, siteId, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Add a contact log to a client's account.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ContactLog response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6ContactLog> ClientAddContactLogAsync(
                string version,
                Models.MindbodyPublicApiDtoModelsV6ClientControllerAddContactLogRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/client/addcontactlog");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "Content-Type", "application/json" },
                { "authorization", authorization },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(request);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6ContactLog>(response.Body);
        }

        /// <summary>
        /// Update a contact log on a client's account.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ContactLog response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6ContactLog ClientUpdateContactLog(
                string version,
                Models.MindbodyPublicApiDtoModelsV6ClientControllerUpdateContactLogRequest request,
                string siteId,
                string authorization = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6ContactLog> t = this.ClientUpdateContactLogAsync(version, request, siteId, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Update a contact log on a client's account.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ContactLog response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6ContactLog> ClientUpdateContactLogAsync(
                string version,
                Models.MindbodyPublicApiDtoModelsV6ClientControllerUpdateContactLogRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/client/updatecontactlog");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "Content-Type", "application/json" },
                { "authorization", authorization },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(request);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6ContactLog>(response.Body);
        }

        /// <summary>
        /// Returns a list of sites that a particular client ID (also referred to as an RSSID) or a client email address is associated with in a cross-regional organization. Either the `ClientID` or `Email` parameter is required. If both are provided, the `ClientID` is used.
        /// Use this endpoint to retrieve information for other Public API endpoints, about the same client at multiple sites within an organization. To use this endpoint, your developer account must have been granted permission to the site’s entire organization.
        /// Note that this endpoint does not work on the Developer Sandbox site, as it is not set up for cross-regional use cases.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClientId">Optional parameter: Looks up the cross regional associations by the client’s ID. Either `ClientId` or `Email` must be provided. If both are provided, the `ClientId` is used by default..</param>
        /// <param name="requestEmail">Optional parameter: Looks up the cross regional associations by the client’s email address. Either `ClientId` or `Email` must be provided. If both are provided, the `ClientId` is used by default..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerGetCrossRegionalClientAssociationsResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6ClientControllerGetCrossRegionalClientAssociationsResponse ClientGetCrossRegionalClientAssociations(
                string version,
                string siteId,
                string authorization = null,
                string requestClientId = null,
                string requestEmail = null,
                int? requestLimit = null,
                int? requestOffset = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetCrossRegionalClientAssociationsResponse> t = this.ClientGetCrossRegionalClientAssociationsAsync(version, siteId, authorization, requestClientId, requestEmail, requestLimit, requestOffset);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Returns a list of sites that a particular client ID (also referred to as an RSSID) or a client email address is associated with in a cross-regional organization. Either the `ClientID` or `Email` parameter is required. If both are provided, the `ClientID` is used.
        /// Use this endpoint to retrieve information for other Public API endpoints, about the same client at multiple sites within an organization. To use this endpoint, your developer account must have been granted permission to the site’s entire organization.
        /// Note that this endpoint does not work on the Developer Sandbox site, as it is not set up for cross-regional use cases.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClientId">Optional parameter: Looks up the cross regional associations by the client’s ID. Either `ClientId` or `Email` must be provided. If both are provided, the `ClientId` is used by default..</param>
        /// <param name="requestEmail">Optional parameter: Looks up the cross regional associations by the client’s email address. Either `ClientId` or `Email` must be provided. If both are provided, the `ClientId` is used by default..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerGetCrossRegionalClientAssociationsResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetCrossRegionalClientAssociationsResponse> ClientGetCrossRegionalClientAssociationsAsync(
                string version,
                string siteId,
                string authorization = null,
                string requestClientId = null,
                string requestEmail = null,
                int? requestLimit = null,
                int? requestOffset = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/client/crossregionalclientassociations");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "request.clientId", requestClientId },
                { "request.email", requestEmail },
                { "request.limit", requestLimit },
                { "request.offset", requestOffset },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetCrossRegionalClientAssociationsResponse>(response.Body);
        }

        /// <summary>
        /// Starting the week of May 11th, 2020 all versions of the Public API will no longer allow duplicate clients to be created. This applies to both adding a client and updating a client record. A duplicate client is created when two profiles have the same first name, last name and email.<br />.
        /// Creates a new client record at the specified business.Passing a User Token as Authorization will create a client and respect Business Mode required fields.Omitting the token will create a client and respect Consumer Mode required fi elds. To make sure you are collecting all required pieces of information, first run GetRequired ClientFields.<br />.
        /// If you have purchased an Ultimate tier then this endpoint will automatically start showing new opportunity on Sales Pipeline.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: The `FirstName` and `LastName` parameters are always required in this request.               All other parameters are optional, but note that any of the optional parameters could be required by a particular business,              depending on how the business has configured the site settings. If `GetRequiredClientFields` returns `EmergContact` in the list of required fields,              then all emergency contact parameters are required, which includes `EmergencyContactInfoEmail`, `EmergencyContactInfoName`, `EmergencyContactInfoPhone`, and `EmergencyContactInfoRelationship`..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerAddClientResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6ClientControllerAddClientResponse ClientAddClient(
                string version,
                Models.MindbodyPublicApiDtoModelsV6ClientControllerAddClientRequest request,
                string siteId,
                string authorization = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerAddClientResponse> t = this.ClientAddClientAsync(version, request, siteId, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Starting the week of May 11th, 2020 all versions of the Public API will no longer allow duplicate clients to be created. This applies to both adding a client and updating a client record. A duplicate client is created when two profiles have the same first name, last name and email.<br />.
        /// Creates a new client record at the specified business.Passing a User Token as Authorization will create a client and respect Business Mode required fields.Omitting the token will create a client and respect Consumer Mode required fi elds. To make sure you are collecting all required pieces of information, first run GetRequired ClientFields.<br />.
        /// If you have purchased an Ultimate tier then this endpoint will automatically start showing new opportunity on Sales Pipeline.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: The `FirstName` and `LastName` parameters are always required in this request.               All other parameters are optional, but note that any of the optional parameters could be required by a particular business,              depending on how the business has configured the site settings. If `GetRequiredClientFields` returns `EmergContact` in the list of required fields,              then all emergency contact parameters are required, which includes `EmergencyContactInfoEmail`, `EmergencyContactInfoName`, `EmergencyContactInfoPhone`, and `EmergencyContactInfoRelationship`..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerAddClientResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerAddClientResponse> ClientAddClientAsync(
                string version,
                Models.MindbodyPublicApiDtoModelsV6ClientControllerAddClientRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/client/addclient");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "Content-Type", "application/json" },
                { "authorization", authorization },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(request);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6ClientControllerAddClientResponse>(response.Body);
        }

        /// <summary>
        /// Starting the week of May 11th, 2020 all versions of the Public API will no longer allow duplicate clients to be created. This applies to both adding a client and updating a client record. A duplicate client is created when two profiles have the same first name, last name and email.<br />.
        /// Updates an existing client for a specific subscriber.Passing a User Token as Authorization respects Business Mode required fields.Omitting the token respects Consumer Mode required fields.To make sure you are collecting all required pieces of information, first run GetRequiredClientFields..Use this endpoint as follows:.
        /// * If you need to update the `ReferredBy` parameter, use this endpoint after calling `GET ClientReferralTypes`.
        /// * When updating a client’s home location, use after calling `GET Locations`.
        /// * If you are updating a client’s stored credit card, use after calling `GET AcceptedCardTypes` so that you can make sure the card is a type that is accepted at the subscriber.<br />.
        /// If this endpoint is used on a cross-regional site, passing in a client’s RSSID and email address creates a cross-regional link. This means that the client is created in cross-regional sites where the client does not exist and `GET CrossRegionalClientAssociations` returns all appropriate cross-regional sites. When `CrossRegionalUpdate` is omitted or set to `true`, the client’s updated information is propagated to all of the region’s sites. If `CrossRegionalUpdate` is set to `false`, only the local client is updated.
        /// Note that the following items cannot be updated for a cross-regional client:.
        /// * `ClientIndexes`.
        /// * `ClientRelationships`.
        /// * `CustomClientFields`.
        /// * `SalesReps`.
        /// * `SendAccountEmails`.
        /// * `SendAccountTexts`.
        /// * `SendPromotionalEmails`.
        /// * `SendPromotionalTexts`.
        /// * `SendScheduleEmails`.
        /// * `SendScheduleTexts`.
        /// * `Gender` (for site custom values).
        /// Custom client Gender options can only be created with non-cross-regional requests.
        ///             .
        /// If you have purchased an Ultimate tier then this endpoint will automatically start showing a new opportunity on Sales Pipeline.It will create a new opportunity if the current request modify the contact as follows::.
        /// * You need to update the `IsProspect` parameter, to `true`.<br />.
        /// * You need to update the `ProspectStage`.`Description parameter`, to `New Lead`.<br />.
        ///  .
        /// Updates made to any inactive clients will automatically reactivate the client unless the `Acive` property is explicitly set to `false` in the request body.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientResponse ClientUpdateClient(
                string version,
                Models.MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientRequest request,
                string siteId,
                string authorization = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientResponse> t = this.ClientUpdateClientAsync(version, request, siteId, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Starting the week of May 11th, 2020 all versions of the Public API will no longer allow duplicate clients to be created. This applies to both adding a client and updating a client record. A duplicate client is created when two profiles have the same first name, last name and email.<br />.
        /// Updates an existing client for a specific subscriber.Passing a User Token as Authorization respects Business Mode required fields.Omitting the token respects Consumer Mode required fields.To make sure you are collecting all required pieces of information, first run GetRequiredClientFields..Use this endpoint as follows:.
        /// * If you need to update the `ReferredBy` parameter, use this endpoint after calling `GET ClientReferralTypes`.
        /// * When updating a client’s home location, use after calling `GET Locations`.
        /// * If you are updating a client’s stored credit card, use after calling `GET AcceptedCardTypes` so that you can make sure the card is a type that is accepted at the subscriber.<br />.
        /// If this endpoint is used on a cross-regional site, passing in a client’s RSSID and email address creates a cross-regional link. This means that the client is created in cross-regional sites where the client does not exist and `GET CrossRegionalClientAssociations` returns all appropriate cross-regional sites. When `CrossRegionalUpdate` is omitted or set to `true`, the client’s updated information is propagated to all of the region’s sites. If `CrossRegionalUpdate` is set to `false`, only the local client is updated.
        /// Note that the following items cannot be updated for a cross-regional client:.
        /// * `ClientIndexes`.
        /// * `ClientRelationships`.
        /// * `CustomClientFields`.
        /// * `SalesReps`.
        /// * `SendAccountEmails`.
        /// * `SendAccountTexts`.
        /// * `SendPromotionalEmails`.
        /// * `SendPromotionalTexts`.
        /// * `SendScheduleEmails`.
        /// * `SendScheduleTexts`.
        /// * `Gender` (for site custom values).
        /// Custom client Gender options can only be created with non-cross-regional requests.
        ///             .
        /// If you have purchased an Ultimate tier then this endpoint will automatically start showing a new opportunity on Sales Pipeline.It will create a new opportunity if the current request modify the contact as follows::.
        /// * You need to update the `IsProspect` parameter, to `true`.<br />.
        /// * You need to update the `ProspectStage`.`Description parameter`, to `New Lead`.<br />.
        ///  .
        /// Updates made to any inactive clients will automatically reactivate the client unless the `Acive` property is explicitly set to `false` in the request body.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientResponse> ClientUpdateClientAsync(
                string version,
                Models.MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/client/updateclient");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "Content-Type", "application/json" },
                { "authorization", authorization },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(request);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientResponse>(response.Body);
        }

        /// <summary>
        /// Updates the status of the specified visit.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientVisitResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientVisitResponse ClientUpdateClientVisit(
                string version,
                Models.MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientVisitRequest request,
                string siteId,
                string authorization = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientVisitResponse> t = this.ClientUpdateClientVisitAsync(version, request, siteId, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Updates the status of the specified visit.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientVisitResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientVisitResponse> ClientUpdateClientVisitAsync(
                string version,
                Models.MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientVisitRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/client/updateclientvisit");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "Content-Type", "application/json" },
                { "authorization", authorization },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(request);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientVisitResponse>(response.Body);
        }

        /// <summary>
        /// Marks a client as arrived for a specified location. A staff user token must be included with staff assigned the LaunchSignInScreen permission.
        ///             .
        /// When used on a site that is part of a region, the following additional logic will apply:.
        ///             .
        /// * When a client exists within the region but not at the studio where the arrival is being logged, a local client record will be automatically created.
        /// * If the local client does not have an applicable local membership or pricing option, a membership or pricing option will be automatically used if it exists elsewhere within the region.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerAddArrivalResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6ClientControllerAddArrivalResponse ClientAddArrival(
                string version,
                Models.MindbodyPublicApiDtoModelsV6ClientControllerAddArrivalRequest request,
                string siteId,
                string authorization = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerAddArrivalResponse> t = this.ClientAddArrivalAsync(version, request, siteId, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Marks a client as arrived for a specified location. A staff user token must be included with staff assigned the LaunchSignInScreen permission.
        ///             .
        /// When used on a site that is part of a region, the following additional logic will apply:.
        ///             .
        /// * When a client exists within the region but not at the studio where the arrival is being logged, a local client record will be automatically created.
        /// * If the local client does not have an applicable local membership or pricing option, a membership or pricing option will be automatically used if it exists elsewhere within the region.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerAddArrivalResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerAddArrivalResponse> ClientAddArrivalAsync(
                string version,
                Models.MindbodyPublicApiDtoModelsV6ClientControllerAddArrivalRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/client/addarrival");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "Content-Type", "application/json" },
                { "authorization", authorization },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(request);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6ClientControllerAddArrivalResponse>(response.Body);
        }

        /// <summary>
        /// Send a password reset email to a client.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the object response from the API call.</returns>
        public object ClientSendPasswordResetEmail(
                string version,
                Models.MindbodyPublicApiDtoModelsV6ClientControllerSendPasswordResetEmailRequest request,
                string siteId,
                string authorization = null)
        {
            Task<object> t = this.ClientSendPasswordResetEmailAsync(version, request, siteId, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Send a password reset email to a client.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the object response from the API call.</returns>
        public async Task<object> ClientSendPasswordResetEmailAsync(
                string version,
                Models.MindbodyPublicApiDtoModelsV6ClientControllerSendPasswordResetEmailRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/client/sendpasswordresetemail");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "Content-Type", "application/json" },
                { "authorization", authorization },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(request);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return response.Body;
        }

        /// <summary>
        /// This endpoint contains a variety of filters that can return not just all contact logs, but also system-generated contact logs, contact logs assigned to specific staff members, and contact logs of specific types or subtypes.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestClientId">Required parameter: The ID of the client whose contact logs are being requested..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestEndDate">Optional parameter: Filters the results to contact logs created before this date.<br />  Default: **the start date**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestShowSystemGenerated">Optional parameter: When `true`, system-generated contact logs are returned in the results.<br />  Default: **false**.</param>
        /// <param name="requestStaffIds">Optional parameter: Filters the results to return contact logs assigned to one or more staff IDs..</param>
        /// <param name="requestStartDate">Optional parameter: Filters the results to contact logs created on or after this date.<br />  Default: **the current date**.</param>
        /// <param name="requestSubtypeIds">Optional parameter: Filters the results to contact logs assigned one or more of these subtype IDs..</param>
        /// <param name="requestTypeIds">Optional parameter: Filters the results to contact logs assigned one or more of these type IDs..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerGetContactLogsResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6ClientControllerGetContactLogsResponse ClientGetContactLogs(
                string version,
                string requestClientId,
                string siteId,
                string authorization = null,
                DateTime? requestEndDate = null,
                int? requestLimit = null,
                int? requestOffset = null,
                bool? requestShowSystemGenerated = null,
                List<long> requestStaffIds = null,
                DateTime? requestStartDate = null,
                List<int> requestSubtypeIds = null,
                List<int> requestTypeIds = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetContactLogsResponse> t = this.ClientGetContactLogsAsync(version, requestClientId, siteId, authorization, requestEndDate, requestLimit, requestOffset, requestShowSystemGenerated, requestStaffIds, requestStartDate, requestSubtypeIds, requestTypeIds);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// This endpoint contains a variety of filters that can return not just all contact logs, but also system-generated contact logs, contact logs assigned to specific staff members, and contact logs of specific types or subtypes.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestClientId">Required parameter: The ID of the client whose contact logs are being requested..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestEndDate">Optional parameter: Filters the results to contact logs created before this date.<br />  Default: **the start date**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestShowSystemGenerated">Optional parameter: When `true`, system-generated contact logs are returned in the results.<br />  Default: **false**.</param>
        /// <param name="requestStaffIds">Optional parameter: Filters the results to return contact logs assigned to one or more staff IDs..</param>
        /// <param name="requestStartDate">Optional parameter: Filters the results to contact logs created on or after this date.<br />  Default: **the current date**.</param>
        /// <param name="requestSubtypeIds">Optional parameter: Filters the results to contact logs assigned one or more of these subtype IDs..</param>
        /// <param name="requestTypeIds">Optional parameter: Filters the results to contact logs assigned one or more of these type IDs..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerGetContactLogsResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetContactLogsResponse> ClientGetContactLogsAsync(
                string version,
                string requestClientId,
                string siteId,
                string authorization = null,
                DateTime? requestEndDate = null,
                int? requestLimit = null,
                int? requestOffset = null,
                bool? requestShowSystemGenerated = null,
                List<long> requestStaffIds = null,
                DateTime? requestStartDate = null,
                List<int> requestSubtypeIds = null,
                List<int> requestTypeIds = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/client/contactlogs");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "request.clientId", requestClientId },
                { "request.endDate", requestEndDate.HasValue ? requestEndDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null },
                { "request.limit", requestLimit },
                { "request.offset", requestOffset },
                { "request.showSystemGenerated", requestShowSystemGenerated },
                { "request.staffIds", requestStaffIds },
                { "request.startDate", requestStartDate.HasValue ? requestStartDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null },
                { "request.subtypeIds", requestSubtypeIds },
                { "request.typeIds", requestTypeIds },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetContactLogsResponse>(response.Body);
        }

        /// <summary>
        /// Updates the active date and/or expiration date of a client pricing option. This request requires staff user credentials. If the active date is modified, the expiration date is also modified accordingly. If the expiration date is modified, the active date is unchanged.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientServiceResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientServiceResponse ClientUpdateClientService(
                string version,
                Models.MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientServiceRequest request,
                string siteId,
                string authorization = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientServiceResponse> t = this.ClientUpdateClientServiceAsync(version, request, siteId, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Updates the active date and/or expiration date of a client pricing option. This request requires staff user credentials. If the active date is modified, the expiration date is also modified accordingly. If the expiration date is modified, the active date is unchanged.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientServiceResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientServiceResponse> ClientUpdateClientServiceAsync(
                string version,
                Models.MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientServiceRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/client/updateclientservice");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "Content-Type", "application/json" },
                { "authorization", authorization },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(request);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientServiceResponse>(response.Body);
        }

        /// <summary>
        /// This endpoint returns direct debit info stored on a client's account. This endpoint requires staff user credentials.
        ///             .
        /// A null response from this endpoint indicates that the client has no usable direct debit information on their account.Use the POST AddClientDirectDebitInfo endpoint to add direct debit information to a client’s account.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="clientId">Optional parameter: The ID of the client..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6DirectDebitInfo response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6DirectDebitInfo ClientGetDirectDebitInfo(
                string version,
                string siteId,
                string authorization = null,
                string clientId = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6DirectDebitInfo> t = this.ClientGetDirectDebitInfoAsync(version, siteId, authorization, clientId);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// This endpoint returns direct debit info stored on a client's account. This endpoint requires staff user credentials.
        ///             .
        /// A null response from this endpoint indicates that the client has no usable direct debit information on their account.Use the POST AddClientDirectDebitInfo endpoint to add direct debit information to a client’s account.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="clientId">Optional parameter: The ID of the client..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6DirectDebitInfo response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6DirectDebitInfo> ClientGetDirectDebitInfoAsync(
                string version,
                string siteId,
                string authorization = null,
                string clientId = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/client/clientdirectdebitinfo");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "clientId", clientId },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6DirectDebitInfo>(response.Body);
        }

        /// <summary>
        /// This endpoint deletes direct debit info from a client’s account. This endpoint requires staff user credentials.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="clientId">Optional parameter: The ID of the client..</param>
        /// <returns>Returns the object response from the API call.</returns>
        public object ClientDeleteDirectDebitInfo(
                string version,
                string siteId,
                string authorization = null,
                string clientId = null)
        {
            Task<object> t = this.ClientDeleteDirectDebitInfoAsync(version, siteId, authorization, clientId);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// This endpoint deletes direct debit info from a client’s account. This endpoint requires staff user credentials.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="clientId">Optional parameter: The ID of the client..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the object response from the API call.</returns>
        public async Task<object> ClientDeleteDirectDebitInfoAsync(
                string version,
                string siteId,
                string authorization = null,
                string clientId = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/client/clientdirectdebitinfo");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "clientId", clientId },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Delete(queryBuilder.ToString(), headers, null, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return response.Body;
        }

        /// <summary>
        /// This endpoint adds direct debit info to a client’s account. This endpoint requires staff user credentials.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerAddClientDirectDebitInfoResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6ClientControllerAddClientDirectDebitInfoResponse ClientAddClientDirectDebitInfo(
                string version,
                Models.MindbodyPublicApiDtoModelsV6ClientControllerAddClientDirectDebitInfoRequest request,
                string siteId,
                string authorization = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerAddClientDirectDebitInfoResponse> t = this.ClientAddClientDirectDebitInfoAsync(version, request, siteId, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// This endpoint adds direct debit info to a client’s account. This endpoint requires staff user credentials.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerAddClientDirectDebitInfoResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerAddClientDirectDebitInfoResponse> ClientAddClientDirectDebitInfoAsync(
                string version,
                Models.MindbodyPublicApiDtoModelsV6ClientControllerAddClientDirectDebitInfoRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/client/addclientdirectdebitinfo");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "Content-Type", "application/json" },
                { "authorization", authorization },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(request);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6ClientControllerAddClientDirectDebitInfoResponse>(response.Body);
        }

        /// <summary>
        /// Gets the client rewards.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestClientId">Required parameter: The ID of the client..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestEndDate">Optional parameter: The end date of transaction.  Default: **StartDate**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestStartDate">Optional parameter: The start date of transaction.  Default: **today**.</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientRewardsResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientRewardsResponse ClientGetClientRewards(
                string version,
                string requestClientId,
                string siteId,
                string authorization = null,
                DateTime? requestEndDate = null,
                int? requestLimit = null,
                int? requestOffset = null,
                DateTime? requestStartDate = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientRewardsResponse> t = this.ClientGetClientRewardsAsync(version, requestClientId, siteId, authorization, requestEndDate, requestLimit, requestOffset, requestStartDate);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Gets the client rewards.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestClientId">Required parameter: The ID of the client..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestEndDate">Optional parameter: The end date of transaction.  Default: **StartDate**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestStartDate">Optional parameter: The start date of transaction.  Default: **today**.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientRewardsResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientRewardsResponse> ClientGetClientRewardsAsync(
                string version,
                string requestClientId,
                string siteId,
                string authorization = null,
                DateTime? requestEndDate = null,
                int? requestLimit = null,
                int? requestOffset = null,
                DateTime? requestStartDate = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/client/clientrewards");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "request.clientId", requestClientId },
                { "request.endDate", requestEndDate.HasValue ? requestEndDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null },
                { "request.limit", requestLimit },
                { "request.offset", requestOffset },
                { "request.startDate", requestStartDate.HasValue ? requestStartDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientRewardsResponse>(response.Body);
        }

        /// <summary>
        /// Earns or redeems rewards points for a given client, based on site settings. Cross regional rewards are not supported at this time.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientRewardsResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientRewardsResponse ClientUpdateClientRewards(
                string version,
                Models.MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientRewardsRequest request,
                string siteId,
                string authorization = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientRewardsResponse> t = this.ClientUpdateClientRewardsAsync(version, request, siteId, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Earns or redeems rewards points for a given client, based on site settings. Cross regional rewards are not supported at this time.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientRewardsResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientRewardsResponse> ClientUpdateClientRewardsAsync(
                string version,
                Models.MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientRewardsRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/client/clientrewards");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "Content-Type", "application/json" },
                { "authorization", authorization },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(request);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientRewardsResponse>(response.Body);
        }

        /// <summary>
        /// This endpoint returns complete client information along with list of purchased services, contract details, membership details and arrival programs for a specific client.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestClientId">Required parameter: Filters results to client with these ID..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClientAssociatedSitesOffset">Optional parameter: Used to retrieve a client’s pricing options from multiple sites within an organization when the client is associated with more than ten sites. To change which ten sites are searched, change this offset value. A value of 0 means that no sites are skipped and the first ten sites are returned. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that you must always have `CrossRegionalLookup` set to `true` to use this parameter.<br />  Default: **0**    For example, if a client is associated with 25 sites, you need to call `GetClientServices` three times, as follows:  * Use `GET CrossRegionalClientAssociations` to determine how many sites a client is associated with, which tells you how many additional calls you need to make.  * Either omit `ClientAssociatedSitesOffset` or set it to 0 to return the client’s services (pricing options) from sites 1-10.  * Set `ClientAssociatedSitesOffset` to 10 to return the client pricing options from sites 11-20  * Set `ClientAssociatedSitesOffset` to 20 to return the client pricing options from sites 21-25.</param>
        /// <param name="requestCrossRegionalLookup">Optional parameter: Used to retrieve a clients pricing options from multiple sites within an organization.When included and set to `true`,  it searches a maximum of ten sites with which this client is associated.When a client is associated with more than ten sites, use `ClientAssociatedSitesOffset` as many times as needed to search the additional sites with which the client is associated.  You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with.   Note that a `SiteID` is returned and populated in the `ClientServices` response when `CrossRegionalLookup` is set to `true`.   Default: **false**.</param>
        /// <param name="requestEndDate">Optional parameter: Filters results to pricing options that are valid on or before this date..</param>
        /// <param name="requestRequiredClientData">Optional parameter: Used to retrieve list of purchased services, contract details, membership details and arrival programs for a specific client.   Default `ClientServices`, `ClientContracts`, `ClientMemberships` and `ClientArrivals` will be returned when `RequiredClientDatais` not set.   When `RequiredClientData` is set to `Contracts` then only `ClientContracts` will be returned in the response.   When `RequiredClientData` is set to Services then only `ClientServices` will be returned in the response.  When `RequiredClientData` is set to `Memberships` then only `ClientMemberships` will be returned in the response.   When `RequiredClientData` is set to `ArrivalPrograms` then only `ClientArrivals` will be returned in the response..</param>
        /// <param name="requestStartDate">Optional parameter: Filters results to pricing options that are valid on or after this date..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientCompleteInfoResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientCompleteInfoResponse ClientGetClientCompleteInfo(
                string version,
                string requestClientId,
                string siteId,
                string authorization = null,
                int? requestClientAssociatedSitesOffset = null,
                bool? requestCrossRegionalLookup = null,
                DateTime? requestEndDate = null,
                List<string> requestRequiredClientData = null,
                DateTime? requestStartDate = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientCompleteInfoResponse> t = this.ClientGetClientCompleteInfoAsync(version, requestClientId, siteId, authorization, requestClientAssociatedSitesOffset, requestCrossRegionalLookup, requestEndDate, requestRequiredClientData, requestStartDate);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// This endpoint returns complete client information along with list of purchased services, contract details, membership details and arrival programs for a specific client.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestClientId">Required parameter: Filters results to client with these ID..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClientAssociatedSitesOffset">Optional parameter: Used to retrieve a client’s pricing options from multiple sites within an organization when the client is associated with more than ten sites. To change which ten sites are searched, change this offset value. A value of 0 means that no sites are skipped and the first ten sites are returned. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that you must always have `CrossRegionalLookup` set to `true` to use this parameter.<br />  Default: **0**    For example, if a client is associated with 25 sites, you need to call `GetClientServices` three times, as follows:  * Use `GET CrossRegionalClientAssociations` to determine how many sites a client is associated with, which tells you how many additional calls you need to make.  * Either omit `ClientAssociatedSitesOffset` or set it to 0 to return the client’s services (pricing options) from sites 1-10.  * Set `ClientAssociatedSitesOffset` to 10 to return the client pricing options from sites 11-20  * Set `ClientAssociatedSitesOffset` to 20 to return the client pricing options from sites 21-25.</param>
        /// <param name="requestCrossRegionalLookup">Optional parameter: Used to retrieve a clients pricing options from multiple sites within an organization.When included and set to `true`,  it searches a maximum of ten sites with which this client is associated.When a client is associated with more than ten sites, use `ClientAssociatedSitesOffset` as many times as needed to search the additional sites with which the client is associated.  You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with.   Note that a `SiteID` is returned and populated in the `ClientServices` response when `CrossRegionalLookup` is set to `true`.   Default: **false**.</param>
        /// <param name="requestEndDate">Optional parameter: Filters results to pricing options that are valid on or before this date..</param>
        /// <param name="requestRequiredClientData">Optional parameter: Used to retrieve list of purchased services, contract details, membership details and arrival programs for a specific client.   Default `ClientServices`, `ClientContracts`, `ClientMemberships` and `ClientArrivals` will be returned when `RequiredClientDatais` not set.   When `RequiredClientData` is set to `Contracts` then only `ClientContracts` will be returned in the response.   When `RequiredClientData` is set to Services then only `ClientServices` will be returned in the response.  When `RequiredClientData` is set to `Memberships` then only `ClientMemberships` will be returned in the response.   When `RequiredClientData` is set to `ArrivalPrograms` then only `ClientArrivals` will be returned in the response..</param>
        /// <param name="requestStartDate">Optional parameter: Filters results to pricing options that are valid on or after this date..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientCompleteInfoResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientCompleteInfoResponse> ClientGetClientCompleteInfoAsync(
                string version,
                string requestClientId,
                string siteId,
                string authorization = null,
                int? requestClientAssociatedSitesOffset = null,
                bool? requestCrossRegionalLookup = null,
                DateTime? requestEndDate = null,
                List<string> requestRequiredClientData = null,
                DateTime? requestStartDate = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/client/clientcompleteinfo");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "request.clientId", requestClientId },
                { "request.clientAssociatedSitesOffset", requestClientAssociatedSitesOffset },
                { "request.crossRegionalLookup", requestCrossRegionalLookup },
                { "request.endDate", requestEndDate.HasValue ? requestEndDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null },
                { "request.requiredClientData", requestRequiredClientData },
                { "request.startDate", requestStartDate.HasValue ? requestStartDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientCompleteInfoResponse>(response.Body);
        }

        /// <summary>
        /// This endpoint contains a variety of filters that can return not just all contact logs, but also system-generated contact logs, contact logs assigned to specific staff members, and contact logs of specific types or subtypes.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestContactLogTypeId">Optional parameter: The requested ContactLogType ID.  Default: **all** IDs that the authenticated user’s access level allows..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerGetContactLogTypesResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6ClientControllerGetContactLogTypesResponse ClientGetContactLogTypes(
                string version,
                string siteId,
                string authorization = null,
                int? requestContactLogTypeId = null,
                int? requestLimit = null,
                int? requestOffset = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetContactLogTypesResponse> t = this.ClientGetContactLogTypesAsync(version, siteId, authorization, requestContactLogTypeId, requestLimit, requestOffset);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// This endpoint contains a variety of filters that can return not just all contact logs, but also system-generated contact logs, contact logs assigned to specific staff members, and contact logs of specific types or subtypes.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestContactLogTypeId">Optional parameter: The requested ContactLogType ID.  Default: **all** IDs that the authenticated user’s access level allows..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerGetContactLogTypesResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetContactLogTypesResponse> ClientGetContactLogTypesAsync(
                string version,
                string siteId,
                string authorization = null,
                int? requestContactLogTypeId = null,
                int? requestLimit = null,
                int? requestOffset = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/client/contactlogtypes");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "request.contactLogTypeId", requestContactLogTypeId },
                { "request.limit", requestLimit },
                { "request.offset", requestOffset },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetContactLogTypesResponse>(response.Body);
        }

        /// <summary>
        /// This endpoint deletes contactlog of client. This endpoint requires staff user credentials.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestClientId">Required parameter: The client ID of the client whose Contact Log is being deleted..</param>
        /// <param name="requestContactLogId">Required parameter: The Contact Log ID..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestTest">Optional parameter: When `true`, indicates that this is a test request and no data is inserted into the subscriber’s database.  When `false`, the database is updated..</param>
        /// <returns>Returns the object response from the API call.</returns>
        public object ClientDeleteContactLog(
                string version,
                string requestClientId,
                long requestContactLogId,
                string siteId,
                string authorization = null,
                bool? requestTest = null)
        {
            Task<object> t = this.ClientDeleteContactLogAsync(version, requestClientId, requestContactLogId, siteId, authorization, requestTest);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// This endpoint deletes contactlog of client. This endpoint requires staff user credentials.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestClientId">Required parameter: The client ID of the client whose Contact Log is being deleted..</param>
        /// <param name="requestContactLogId">Required parameter: The Contact Log ID..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestTest">Optional parameter: When `true`, indicates that this is a test request and no data is inserted into the subscriber’s database.  When `false`, the database is updated..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the object response from the API call.</returns>
        public async Task<object> ClientDeleteContactLogAsync(
                string version,
                string requestClientId,
                long requestContactLogId,
                string siteId,
                string authorization = null,
                bool? requestTest = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/client/deletecontactlog");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "request.clientId", requestClientId },
                { "request.contactLogId", requestContactLogId },
                { "request.test", requestTest },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Delete(queryBuilder.ToString(), headers, null, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return response.Body;
        }

        /// <summary>
        /// This endpoint requires staff user credentials.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the object response from the API call.</returns>
        public object ClientSendAutoEmail(
                string version,
                Models.MindbodyPublicApiDtoModelsV6ClientControllerSendAutoEmailRequest request,
                string siteId,
                string authorization = null)
        {
            Task<object> t = this.ClientSendAutoEmailAsync(version, request, siteId, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// This endpoint requires staff user credentials.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the object response from the API call.</returns>
        public async Task<object> ClientSendAutoEmailAsync(
                string version,
                Models.MindbodyPublicApiDtoModelsV6ClientControllerSendAutoEmailRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/client/sendautoemail");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "Content-Type", "application/json" },
                { "authorization", authorization },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(request);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return response.Body;
        }

        /// <summary>
        /// The endpoint returns a list of memberships for multiple clients we pass in query parameter. Please note that clients memberships with location restrictions can only be used to pay for scheduled services at the site to which they belong. Memberships with location restrictions can not be used to pay for scheduled services at other sites within an organization.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestClientIds">Required parameter: The ID of the client for whom memberships are returned. Maximum allowed : 200..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClientAssociatedSitesOffset">Optional parameter: Used to retrieve a client’s memberships from multiple sites within an organization when the client is associated with more than ten sites. To change which ten sites are searched, change this offset value. A value of 0 means that no sites are skipped and the first ten sites are returned. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that you must always have `CrossRegionalLookup` set to `true` to use this parameter.<br />  Default: **0**    For example, if a client is associated with 25 sites, you need to call `GetClientServices` three times, as follows:  * Use `GET CrossRegionalClientAssociations` to determine how many sites a client is associated with, which tells you how many additional calls you need to make.  * Either omit `ClientAssociatedSitesOffset` or set it to 0 to return the client’s services (pricing options) from sites 1-10.  * Set `ClientAssociatedSitesOffset` to 10 to return the client pricing options from sites 11-20  * Set `ClientAssociatedSitesOffset` to 20 to return the client pricing options from sites 21-25.</param>
        /// <param name="requestCrossRegionalLookup">Optional parameter: Used to retrieve a client’s memberships from multiple sites within an organization. When included and set to `true`, it searches a maximum of ten sites with which this client is associated. When a client is associated with more than ten sites, use `ClientAssociatedSitesOffset` as many times as needed to search the additional sites with which the client is associated. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that a `SiteID` is returned and populated in the `ClientServices` response when `CrossRegionalLookup` is set to `true`.  Default: **false**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationId">Optional parameter: Filters results to memberships that can be used to pay for scheduled services at that location. This parameter can not be passed when `CrossRegionalLookup` is `true`..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerGetActiveClientsMembershipsResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6ClientControllerGetActiveClientsMembershipsResponse ClientGetActiveClientsMemberships(
                string version,
                List<string> requestClientIds,
                string siteId,
                string authorization = null,
                int? requestClientAssociatedSitesOffset = null,
                bool? requestCrossRegionalLookup = null,
                int? requestLimit = null,
                int? requestLocationId = null,
                int? requestOffset = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetActiveClientsMembershipsResponse> t = this.ClientGetActiveClientsMembershipsAsync(version, requestClientIds, siteId, authorization, requestClientAssociatedSitesOffset, requestCrossRegionalLookup, requestLimit, requestLocationId, requestOffset);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// The endpoint returns a list of memberships for multiple clients we pass in query parameter. Please note that clients memberships with location restrictions can only be used to pay for scheduled services at the site to which they belong. Memberships with location restrictions can not be used to pay for scheduled services at other sites within an organization.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestClientIds">Required parameter: The ID of the client for whom memberships are returned. Maximum allowed : 200..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClientAssociatedSitesOffset">Optional parameter: Used to retrieve a client’s memberships from multiple sites within an organization when the client is associated with more than ten sites. To change which ten sites are searched, change this offset value. A value of 0 means that no sites are skipped and the first ten sites are returned. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that you must always have `CrossRegionalLookup` set to `true` to use this parameter.<br />  Default: **0**    For example, if a client is associated with 25 sites, you need to call `GetClientServices` three times, as follows:  * Use `GET CrossRegionalClientAssociations` to determine how many sites a client is associated with, which tells you how many additional calls you need to make.  * Either omit `ClientAssociatedSitesOffset` or set it to 0 to return the client’s services (pricing options) from sites 1-10.  * Set `ClientAssociatedSitesOffset` to 10 to return the client pricing options from sites 11-20  * Set `ClientAssociatedSitesOffset` to 20 to return the client pricing options from sites 21-25.</param>
        /// <param name="requestCrossRegionalLookup">Optional parameter: Used to retrieve a client’s memberships from multiple sites within an organization. When included and set to `true`, it searches a maximum of ten sites with which this client is associated. When a client is associated with more than ten sites, use `ClientAssociatedSitesOffset` as many times as needed to search the additional sites with which the client is associated. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that a `SiteID` is returned and populated in the `ClientServices` response when `CrossRegionalLookup` is set to `true`.  Default: **false**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationId">Optional parameter: Filters results to memberships that can be used to pay for scheduled services at that location. This parameter can not be passed when `CrossRegionalLookup` is `true`..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerGetActiveClientsMembershipsResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetActiveClientsMembershipsResponse> ClientGetActiveClientsMembershipsAsync(
                string version,
                List<string> requestClientIds,
                string siteId,
                string authorization = null,
                int? requestClientAssociatedSitesOffset = null,
                bool? requestCrossRegionalLookup = null,
                int? requestLimit = null,
                int? requestLocationId = null,
                int? requestOffset = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/client/activeclientsmemberships");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "request.clientIds", requestClientIds },
                { "request.clientAssociatedSitesOffset", requestClientAssociatedSitesOffset },
                { "request.crossRegionalLookup", requestCrossRegionalLookup },
                { "request.limit", requestLimit },
                { "request.locationId", requestLocationId },
                { "request.offset", requestOffset },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetActiveClientsMembershipsResponse>(response.Body);
        }

        /// <summary>
        /// This endpoint terminates a client contract. This endpoint requires staff user credentials with TerminateClientContract permission.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerTerminateContractResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6ClientControllerTerminateContractResponse ClientTerminateContract(
                string version,
                Models.MindbodyPublicApiDtoModelsV6ClientControllerTerminateContractRequest request,
                string siteId,
                string authorization = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerTerminateContractResponse> t = this.ClientTerminateContractAsync(version, request, siteId, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// This endpoint terminates a client contract. This endpoint requires staff user credentials with TerminateClientContract permission.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerTerminateContractResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerTerminateContractResponse> ClientTerminateContractAsync(
                string version,
                Models.MindbodyPublicApiDtoModelsV6ClientControllerTerminateContractRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/client/terminatecontract");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "Content-Type", "application/json" },
                { "authorization", authorization },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(request);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6ClientControllerTerminateContractResponse>(response.Body);
        }

        /// <summary>
        /// Client_UpdateClientContractAutopays EndPoint.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6Contract response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6Contract ClientUpdateClientContractAutopays(
                string version,
                Models.MindbodyPublicApiDtoModelsV6SaleControllerUpdateClientContractAutopaysRequest request,
                string siteId,
                string authorization = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6Contract> t = this.ClientUpdateClientContractAutopaysAsync(version, request, siteId, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Client_UpdateClientContractAutopays EndPoint.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6Contract response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6Contract> ClientUpdateClientContractAutopaysAsync(
                string version,
                Models.MindbodyPublicApiDtoModelsV6SaleControllerUpdateClientContractAutopaysRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/client/updateclientcontractautopays");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "Content-Type", "application/json" },
                { "authorization", authorization },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(request);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6Contract>(response.Body);
        }

        /// <summary>
        /// Suspend client contract.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerSuspendContractResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6ClientControllerSuspendContractResponse ClientSuspendContract(
                string version,
                Models.MindbodyPublicApiDtoModelsV6ClientControllerSuspendContractRequest request,
                string siteId,
                string authorization = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerSuspendContractResponse> t = this.ClientSuspendContractAsync(version, request, siteId, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Suspend client contract.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerSuspendContractResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerSuspendContractResponse> ClientSuspendContractAsync(
                string version,
                Models.MindbodyPublicApiDtoModelsV6ClientControllerSuspendContractRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/client/suspendcontract");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "Content-Type", "application/json" },
                { "authorization", authorization },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(request);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6ClientControllerSuspendContractResponse>(response.Body);
        }

        /// <summary>
        /// Client_MergeClient EndPoint.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the object response from the API call.</returns>
        public object ClientMergeClient(
                string version,
                Models.MindbodyPublicApiDtoModelsV6ClientControllerMergeClientsRequest request,
                string siteId,
                string authorization = null)
        {
            Task<object> t = this.ClientMergeClientAsync(version, request, siteId, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Client_MergeClient EndPoint.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the object response from the API call.</returns>
        public async Task<object> ClientMergeClientAsync(
                string version,
                Models.MindbodyPublicApiDtoModelsV6ClientControllerMergeClientsRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/client/mergeclients");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "Content-Type", "application/json" },
                { "authorization", authorization },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(request);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return response.Body;
        }
    }
}