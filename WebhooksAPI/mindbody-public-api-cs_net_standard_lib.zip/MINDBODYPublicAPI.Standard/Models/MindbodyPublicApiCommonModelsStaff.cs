// <copyright file="MindbodyPublicApiCommonModelsStaff.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiCommonModelsStaff.
    /// </summary>
    public class MindbodyPublicApiCommonModelsStaff
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiCommonModelsStaff"/> class.
        /// </summary>
        public MindbodyPublicApiCommonModelsStaff()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiCommonModelsStaff"/> class.
        /// </summary>
        /// <param name="id">Id.</param>
        /// <param name="firstName">FirstName.</param>
        /// <param name="lastName">LastName.</param>
        /// <param name="displayName">DisplayName.</param>
        /// <param name="email">Email.</param>
        /// <param name="bio">Bio.</param>
        /// <param name="address">Address.</param>
        /// <param name="address2">Address2.</param>
        /// <param name="city">City.</param>
        /// <param name="state">State.</param>
        /// <param name="postalCode">PostalCode.</param>
        /// <param name="foreignZip">ForeignZip.</param>
        /// <param name="country">Country.</param>
        /// <param name="workPhone">WorkPhone.</param>
        /// <param name="homePhone">HomePhone.</param>
        /// <param name="cellPhone">CellPhone.</param>
        /// <param name="active">Active.</param>
        /// <param name="isSystem">IsSystem.</param>
        /// <param name="smodeId">SmodeId.</param>
        /// <param name="appointmentTrn">AppointmentTrn.</param>
        /// <param name="alwaysAllowDoubleBooking">AlwaysAllowDoubleBooking.</param>
        /// <param name="independentContractor">IndependentContractor.</param>
        /// <param name="imageUrl">ImageUrl.</param>
        /// <param name="isMale">IsMale.</param>
        /// <param name="reservationTrn">ReservationTrn.</param>
        /// <param name="sortOrder">SortOrder.</param>
        /// <param name="multiLocationPermission">MultiLocationPermission.</param>
        /// <param name="name">Name.</param>
        /// <param name="providerIDs">ProviderIDs.</param>
        /// <param name="staffSettings">StaffSettings.</param>
        /// <param name="rep">Rep.</param>
        /// <param name="rep2">Rep2.</param>
        /// <param name="rep3">Rep3.</param>
        /// <param name="rep4">Rep4.</param>
        /// <param name="rep5">Rep5.</param>
        /// <param name="rep6">Rep6.</param>
        /// <param name="assistant">Assistant.</param>
        /// <param name="assistant2">Assistant2.</param>
        /// <param name="employmentStart">EmploymentStart.</param>
        /// <param name="employmentEnd">EmploymentEnd.</param>
        /// <param name="empID">EmpID.</param>
        /// <param name="appointments">Appointments.</param>
        /// <param name="unavailabilities">Unavailabilities.</param>
        /// <param name="availabilities">Availabilities.</param>
        /// <param name="loginLocations">LoginLocations.</param>
        public MindbodyPublicApiCommonModelsStaff(
            long? id = null,
            string firstName = null,
            string lastName = null,
            string displayName = null,
            string email = null,
            string bio = null,
            string address = null,
            string address2 = null,
            string city = null,
            string state = null,
            string postalCode = null,
            string foreignZip = null,
            string country = null,
            string workPhone = null,
            string homePhone = null,
            string cellPhone = null,
            bool? active = null,
            bool? isSystem = null,
            int? smodeId = null,
            bool? appointmentTrn = null,
            bool? alwaysAllowDoubleBooking = null,
            bool? independentContractor = null,
            string imageUrl = null,
            bool? isMale = null,
            bool? reservationTrn = null,
            int? sortOrder = null,
            bool? multiLocationPermission = null,
            string name = null,
            List<string> providerIDs = null,
            Models.MindbodyPublicApiCommonModelsStaffSetting staffSettings = null,
            bool? rep = null,
            bool? rep2 = null,
            bool? rep3 = null,
            bool? rep4 = null,
            bool? rep5 = null,
            bool? rep6 = null,
            bool? assistant = null,
            bool? assistant2 = null,
            DateTime? employmentStart = null,
            DateTime? employmentEnd = null,
            string empID = null,
            List<Models.MindbodyPublicApiCommonModelsAppointment> appointments = null,
            List<Models.MindbodyPublicApiCommonModelsUnavailability> unavailabilities = null,
            List<Models.MindbodyPublicApiCommonModelsAvailability> availabilities = null,
            List<Models.MindbodyPublicApiCommonModelsLocation> loginLocations = null)
        {
            this.Id = id;
            this.FirstName = firstName;
            this.LastName = lastName;
            this.DisplayName = displayName;
            this.Email = email;
            this.Bio = bio;
            this.Address = address;
            this.Address2 = address2;
            this.City = city;
            this.State = state;
            this.PostalCode = postalCode;
            this.ForeignZip = foreignZip;
            this.Country = country;
            this.WorkPhone = workPhone;
            this.HomePhone = homePhone;
            this.CellPhone = cellPhone;
            this.Active = active;
            this.IsSystem = isSystem;
            this.SmodeId = smodeId;
            this.AppointmentTrn = appointmentTrn;
            this.AlwaysAllowDoubleBooking = alwaysAllowDoubleBooking;
            this.IndependentContractor = independentContractor;
            this.ImageUrl = imageUrl;
            this.IsMale = isMale;
            this.ReservationTrn = reservationTrn;
            this.SortOrder = sortOrder;
            this.MultiLocationPermission = multiLocationPermission;
            this.Name = name;
            this.ProviderIDs = providerIDs;
            this.StaffSettings = staffSettings;
            this.Rep = rep;
            this.Rep2 = rep2;
            this.Rep3 = rep3;
            this.Rep4 = rep4;
            this.Rep5 = rep5;
            this.Rep6 = rep6;
            this.Assistant = assistant;
            this.Assistant2 = assistant2;
            this.EmploymentStart = employmentStart;
            this.EmploymentEnd = employmentEnd;
            this.EmpID = empID;
            this.Appointments = appointments;
            this.Unavailabilities = unavailabilities;
            this.Availabilities = availabilities;
            this.LoginLocations = loginLocations;
        }

        /// <summary>
        /// Gets or sets Id.
        /// </summary>
        [JsonProperty("Id", NullValueHandling = NullValueHandling.Ignore)]
        public long? Id { get; set; }

        /// <summary>
        /// Gets or sets FirstName.
        /// </summary>
        [JsonProperty("FirstName", NullValueHandling = NullValueHandling.Ignore)]
        public string FirstName { get; set; }

        /// <summary>
        /// Gets or sets LastName.
        /// </summary>
        [JsonProperty("LastName", NullValueHandling = NullValueHandling.Ignore)]
        public string LastName { get; set; }

        /// <summary>
        /// Gets or sets DisplayName.
        /// </summary>
        [JsonProperty("DisplayName", NullValueHandling = NullValueHandling.Ignore)]
        public string DisplayName { get; set; }

        /// <summary>
        /// Gets or sets Email.
        /// </summary>
        [JsonProperty("Email", NullValueHandling = NullValueHandling.Ignore)]
        public string Email { get; set; }

        /// <summary>
        /// Gets or sets Bio.
        /// </summary>
        [JsonProperty("Bio", NullValueHandling = NullValueHandling.Ignore)]
        public string Bio { get; set; }

        /// <summary>
        /// Gets or sets Address.
        /// </summary>
        [JsonProperty("Address", NullValueHandling = NullValueHandling.Ignore)]
        public string Address { get; set; }

        /// <summary>
        /// Gets or sets Address2.
        /// </summary>
        [JsonProperty("Address2", NullValueHandling = NullValueHandling.Ignore)]
        public string Address2 { get; set; }

        /// <summary>
        /// Gets or sets City.
        /// </summary>
        [JsonProperty("City", NullValueHandling = NullValueHandling.Ignore)]
        public string City { get; set; }

        /// <summary>
        /// Gets or sets State.
        /// </summary>
        [JsonProperty("State", NullValueHandling = NullValueHandling.Ignore)]
        public string State { get; set; }

        /// <summary>
        /// Gets or sets PostalCode.
        /// </summary>
        [JsonProperty("PostalCode", NullValueHandling = NullValueHandling.Ignore)]
        public string PostalCode { get; set; }

        /// <summary>
        /// Gets or sets ForeignZip.
        /// </summary>
        [JsonProperty("ForeignZip", NullValueHandling = NullValueHandling.Ignore)]
        public string ForeignZip { get; set; }

        /// <summary>
        /// Gets or sets Country.
        /// </summary>
        [JsonProperty("Country", NullValueHandling = NullValueHandling.Ignore)]
        public string Country { get; set; }

        /// <summary>
        /// Gets or sets WorkPhone.
        /// </summary>
        [JsonProperty("WorkPhone", NullValueHandling = NullValueHandling.Ignore)]
        public string WorkPhone { get; set; }

        /// <summary>
        /// Gets or sets HomePhone.
        /// </summary>
        [JsonProperty("HomePhone", NullValueHandling = NullValueHandling.Ignore)]
        public string HomePhone { get; set; }

        /// <summary>
        /// Gets or sets CellPhone.
        /// </summary>
        [JsonProperty("CellPhone", NullValueHandling = NullValueHandling.Ignore)]
        public string CellPhone { get; set; }

        /// <summary>
        /// Gets or sets Active.
        /// </summary>
        [JsonProperty("Active", NullValueHandling = NullValueHandling.Ignore)]
        public bool? Active { get; set; }

        /// <summary>
        /// Gets or sets IsSystem.
        /// </summary>
        [JsonProperty("IsSystem", NullValueHandling = NullValueHandling.Ignore)]
        public bool? IsSystem { get; set; }

        /// <summary>
        /// Gets or sets SmodeId.
        /// </summary>
        [JsonProperty("SmodeId", NullValueHandling = NullValueHandling.Ignore)]
        public int? SmodeId { get; set; }

        /// <summary>
        /// Gets or sets AppointmentTrn.
        /// </summary>
        [JsonProperty("AppointmentTrn", NullValueHandling = NullValueHandling.Ignore)]
        public bool? AppointmentTrn { get; set; }

        /// <summary>
        /// Gets or sets AlwaysAllowDoubleBooking.
        /// </summary>
        [JsonProperty("AlwaysAllowDoubleBooking", NullValueHandling = NullValueHandling.Ignore)]
        public bool? AlwaysAllowDoubleBooking { get; set; }

        /// <summary>
        /// Gets or sets IndependentContractor.
        /// </summary>
        [JsonProperty("IndependentContractor", NullValueHandling = NullValueHandling.Ignore)]
        public bool? IndependentContractor { get; set; }

        /// <summary>
        /// Gets or sets ImageUrl.
        /// </summary>
        [JsonProperty("ImageUrl", NullValueHandling = NullValueHandling.Ignore)]
        public string ImageUrl { get; set; }

        /// <summary>
        /// Gets or sets IsMale.
        /// </summary>
        [JsonProperty("IsMale", NullValueHandling = NullValueHandling.Ignore)]
        public bool? IsMale { get; set; }

        /// <summary>
        /// Gets or sets ReservationTrn.
        /// </summary>
        [JsonProperty("ReservationTrn", NullValueHandling = NullValueHandling.Ignore)]
        public bool? ReservationTrn { get; set; }

        /// <summary>
        /// Gets or sets SortOrder.
        /// </summary>
        [JsonProperty("SortOrder", NullValueHandling = NullValueHandling.Ignore)]
        public int? SortOrder { get; set; }

        /// <summary>
        /// Gets or sets MultiLocationPermission.
        /// </summary>
        [JsonProperty("MultiLocationPermission", NullValueHandling = NullValueHandling.Ignore)]
        public bool? MultiLocationPermission { get; set; }

        /// <summary>
        /// Gets or sets Name.
        /// </summary>
        [JsonProperty("Name", NullValueHandling = NullValueHandling.Ignore)]
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets ProviderIDs.
        /// </summary>
        [JsonProperty("ProviderIDs", NullValueHandling = NullValueHandling.Ignore)]
        public List<string> ProviderIDs { get; set; }

        /// <summary>
        /// Gets or sets StaffSettings.
        /// </summary>
        [JsonProperty("StaffSettings", NullValueHandling = NullValueHandling.Ignore)]
        public Models.MindbodyPublicApiCommonModelsStaffSetting StaffSettings { get; set; }

        /// <summary>
        /// Gets or sets Rep.
        /// </summary>
        [JsonProperty("Rep", NullValueHandling = NullValueHandling.Ignore)]
        public bool? Rep { get; set; }

        /// <summary>
        /// Gets or sets Rep2.
        /// </summary>
        [JsonProperty("Rep2", NullValueHandling = NullValueHandling.Ignore)]
        public bool? Rep2 { get; set; }

        /// <summary>
        /// Gets or sets Rep3.
        /// </summary>
        [JsonProperty("Rep3", NullValueHandling = NullValueHandling.Ignore)]
        public bool? Rep3 { get; set; }

        /// <summary>
        /// Gets or sets Rep4.
        /// </summary>
        [JsonProperty("Rep4", NullValueHandling = NullValueHandling.Ignore)]
        public bool? Rep4 { get; set; }

        /// <summary>
        /// Gets or sets Rep5.
        /// </summary>
        [JsonProperty("Rep5", NullValueHandling = NullValueHandling.Ignore)]
        public bool? Rep5 { get; set; }

        /// <summary>
        /// Gets or sets Rep6.
        /// </summary>
        [JsonProperty("Rep6", NullValueHandling = NullValueHandling.Ignore)]
        public bool? Rep6 { get; set; }

        /// <summary>
        /// Gets or sets Assistant.
        /// </summary>
        [JsonProperty("Assistant", NullValueHandling = NullValueHandling.Ignore)]
        public bool? Assistant { get; set; }

        /// <summary>
        /// Gets or sets Assistant2.
        /// </summary>
        [JsonProperty("Assistant2", NullValueHandling = NullValueHandling.Ignore)]
        public bool? Assistant2 { get; set; }

        /// <summary>
        /// Gets or sets EmploymentStart.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("EmploymentStart", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? EmploymentStart { get; set; }

        /// <summary>
        /// Gets or sets EmploymentEnd.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("EmploymentEnd", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? EmploymentEnd { get; set; }

        /// <summary>
        /// Gets or sets EmpID.
        /// </summary>
        [JsonProperty("EmpID", NullValueHandling = NullValueHandling.Ignore)]
        public string EmpID { get; set; }

        /// <summary>
        /// List of appointments for the staff.
        /// </summary>
        [JsonProperty("Appointments", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.MindbodyPublicApiCommonModelsAppointment> Appointments { get; set; }

        /// <summary>
        /// List of unavailabilities for the staff.
        /// </summary>
        [JsonProperty("Unavailabilities", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.MindbodyPublicApiCommonModelsUnavailability> Unavailabilities { get; set; }

        /// <summary>
        /// List of availabilities for the staff.
        /// </summary>
        [JsonProperty("Availabilities", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.MindbodyPublicApiCommonModelsAvailability> Availabilities { get; set; }

        /// <summary>
        /// Gets or sets LoginLocations.
        /// </summary>
        [JsonProperty("LoginLocations", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.MindbodyPublicApiCommonModelsLocation> LoginLocations { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiCommonModelsStaff : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiCommonModelsStaff other &&
                ((this.Id == null && other.Id == null) || (this.Id?.Equals(other.Id) == true)) &&
                ((this.FirstName == null && other.FirstName == null) || (this.FirstName?.Equals(other.FirstName) == true)) &&
                ((this.LastName == null && other.LastName == null) || (this.LastName?.Equals(other.LastName) == true)) &&
                ((this.DisplayName == null && other.DisplayName == null) || (this.DisplayName?.Equals(other.DisplayName) == true)) &&
                ((this.Email == null && other.Email == null) || (this.Email?.Equals(other.Email) == true)) &&
                ((this.Bio == null && other.Bio == null) || (this.Bio?.Equals(other.Bio) == true)) &&
                ((this.Address == null && other.Address == null) || (this.Address?.Equals(other.Address) == true)) &&
                ((this.Address2 == null && other.Address2 == null) || (this.Address2?.Equals(other.Address2) == true)) &&
                ((this.City == null && other.City == null) || (this.City?.Equals(other.City) == true)) &&
                ((this.State == null && other.State == null) || (this.State?.Equals(other.State) == true)) &&
                ((this.PostalCode == null && other.PostalCode == null) || (this.PostalCode?.Equals(other.PostalCode) == true)) &&
                ((this.ForeignZip == null && other.ForeignZip == null) || (this.ForeignZip?.Equals(other.ForeignZip) == true)) &&
                ((this.Country == null && other.Country == null) || (this.Country?.Equals(other.Country) == true)) &&
                ((this.WorkPhone == null && other.WorkPhone == null) || (this.WorkPhone?.Equals(other.WorkPhone) == true)) &&
                ((this.HomePhone == null && other.HomePhone == null) || (this.HomePhone?.Equals(other.HomePhone) == true)) &&
                ((this.CellPhone == null && other.CellPhone == null) || (this.CellPhone?.Equals(other.CellPhone) == true)) &&
                ((this.Active == null && other.Active == null) || (this.Active?.Equals(other.Active) == true)) &&
                ((this.IsSystem == null && other.IsSystem == null) || (this.IsSystem?.Equals(other.IsSystem) == true)) &&
                ((this.SmodeId == null && other.SmodeId == null) || (this.SmodeId?.Equals(other.SmodeId) == true)) &&
                ((this.AppointmentTrn == null && other.AppointmentTrn == null) || (this.AppointmentTrn?.Equals(other.AppointmentTrn) == true)) &&
                ((this.AlwaysAllowDoubleBooking == null && other.AlwaysAllowDoubleBooking == null) || (this.AlwaysAllowDoubleBooking?.Equals(other.AlwaysAllowDoubleBooking) == true)) &&
                ((this.IndependentContractor == null && other.IndependentContractor == null) || (this.IndependentContractor?.Equals(other.IndependentContractor) == true)) &&
                ((this.ImageUrl == null && other.ImageUrl == null) || (this.ImageUrl?.Equals(other.ImageUrl) == true)) &&
                ((this.IsMale == null && other.IsMale == null) || (this.IsMale?.Equals(other.IsMale) == true)) &&
                ((this.ReservationTrn == null && other.ReservationTrn == null) || (this.ReservationTrn?.Equals(other.ReservationTrn) == true)) &&
                ((this.SortOrder == null && other.SortOrder == null) || (this.SortOrder?.Equals(other.SortOrder) == true)) &&
                ((this.MultiLocationPermission == null && other.MultiLocationPermission == null) || (this.MultiLocationPermission?.Equals(other.MultiLocationPermission) == true)) &&
                ((this.Name == null && other.Name == null) || (this.Name?.Equals(other.Name) == true)) &&
                ((this.ProviderIDs == null && other.ProviderIDs == null) || (this.ProviderIDs?.Equals(other.ProviderIDs) == true)) &&
                ((this.StaffSettings == null && other.StaffSettings == null) || (this.StaffSettings?.Equals(other.StaffSettings) == true)) &&
                ((this.Rep == null && other.Rep == null) || (this.Rep?.Equals(other.Rep) == true)) &&
                ((this.Rep2 == null && other.Rep2 == null) || (this.Rep2?.Equals(other.Rep2) == true)) &&
                ((this.Rep3 == null && other.Rep3 == null) || (this.Rep3?.Equals(other.Rep3) == true)) &&
                ((this.Rep4 == null && other.Rep4 == null) || (this.Rep4?.Equals(other.Rep4) == true)) &&
                ((this.Rep5 == null && other.Rep5 == null) || (this.Rep5?.Equals(other.Rep5) == true)) &&
                ((this.Rep6 == null && other.Rep6 == null) || (this.Rep6?.Equals(other.Rep6) == true)) &&
                ((this.Assistant == null && other.Assistant == null) || (this.Assistant?.Equals(other.Assistant) == true)) &&
                ((this.Assistant2 == null && other.Assistant2 == null) || (this.Assistant2?.Equals(other.Assistant2) == true)) &&
                ((this.EmploymentStart == null && other.EmploymentStart == null) || (this.EmploymentStart?.Equals(other.EmploymentStart) == true)) &&
                ((this.EmploymentEnd == null && other.EmploymentEnd == null) || (this.EmploymentEnd?.Equals(other.EmploymentEnd) == true)) &&
                ((this.EmpID == null && other.EmpID == null) || (this.EmpID?.Equals(other.EmpID) == true)) &&
                ((this.Appointments == null && other.Appointments == null) || (this.Appointments?.Equals(other.Appointments) == true)) &&
                ((this.Unavailabilities == null && other.Unavailabilities == null) || (this.Unavailabilities?.Equals(other.Unavailabilities) == true)) &&
                ((this.Availabilities == null && other.Availabilities == null) || (this.Availabilities?.Equals(other.Availabilities) == true)) &&
                ((this.LoginLocations == null && other.LoginLocations == null) || (this.LoginLocations?.Equals(other.LoginLocations) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Id = {(this.Id == null ? "null" : this.Id.ToString())}");
            toStringOutput.Add($"this.FirstName = {(this.FirstName == null ? "null" : this.FirstName == string.Empty ? "" : this.FirstName)}");
            toStringOutput.Add($"this.LastName = {(this.LastName == null ? "null" : this.LastName == string.Empty ? "" : this.LastName)}");
            toStringOutput.Add($"this.DisplayName = {(this.DisplayName == null ? "null" : this.DisplayName == string.Empty ? "" : this.DisplayName)}");
            toStringOutput.Add($"this.Email = {(this.Email == null ? "null" : this.Email == string.Empty ? "" : this.Email)}");
            toStringOutput.Add($"this.Bio = {(this.Bio == null ? "null" : this.Bio == string.Empty ? "" : this.Bio)}");
            toStringOutput.Add($"this.Address = {(this.Address == null ? "null" : this.Address == string.Empty ? "" : this.Address)}");
            toStringOutput.Add($"this.Address2 = {(this.Address2 == null ? "null" : this.Address2 == string.Empty ? "" : this.Address2)}");
            toStringOutput.Add($"this.City = {(this.City == null ? "null" : this.City == string.Empty ? "" : this.City)}");
            toStringOutput.Add($"this.State = {(this.State == null ? "null" : this.State == string.Empty ? "" : this.State)}");
            toStringOutput.Add($"this.PostalCode = {(this.PostalCode == null ? "null" : this.PostalCode == string.Empty ? "" : this.PostalCode)}");
            toStringOutput.Add($"this.ForeignZip = {(this.ForeignZip == null ? "null" : this.ForeignZip == string.Empty ? "" : this.ForeignZip)}");
            toStringOutput.Add($"this.Country = {(this.Country == null ? "null" : this.Country == string.Empty ? "" : this.Country)}");
            toStringOutput.Add($"this.WorkPhone = {(this.WorkPhone == null ? "null" : this.WorkPhone == string.Empty ? "" : this.WorkPhone)}");
            toStringOutput.Add($"this.HomePhone = {(this.HomePhone == null ? "null" : this.HomePhone == string.Empty ? "" : this.HomePhone)}");
            toStringOutput.Add($"this.CellPhone = {(this.CellPhone == null ? "null" : this.CellPhone == string.Empty ? "" : this.CellPhone)}");
            toStringOutput.Add($"this.Active = {(this.Active == null ? "null" : this.Active.ToString())}");
            toStringOutput.Add($"this.IsSystem = {(this.IsSystem == null ? "null" : this.IsSystem.ToString())}");
            toStringOutput.Add($"this.SmodeId = {(this.SmodeId == null ? "null" : this.SmodeId.ToString())}");
            toStringOutput.Add($"this.AppointmentTrn = {(this.AppointmentTrn == null ? "null" : this.AppointmentTrn.ToString())}");
            toStringOutput.Add($"this.AlwaysAllowDoubleBooking = {(this.AlwaysAllowDoubleBooking == null ? "null" : this.AlwaysAllowDoubleBooking.ToString())}");
            toStringOutput.Add($"this.IndependentContractor = {(this.IndependentContractor == null ? "null" : this.IndependentContractor.ToString())}");
            toStringOutput.Add($"this.ImageUrl = {(this.ImageUrl == null ? "null" : this.ImageUrl == string.Empty ? "" : this.ImageUrl)}");
            toStringOutput.Add($"this.IsMale = {(this.IsMale == null ? "null" : this.IsMale.ToString())}");
            toStringOutput.Add($"this.ReservationTrn = {(this.ReservationTrn == null ? "null" : this.ReservationTrn.ToString())}");
            toStringOutput.Add($"this.SortOrder = {(this.SortOrder == null ? "null" : this.SortOrder.ToString())}");
            toStringOutput.Add($"this.MultiLocationPermission = {(this.MultiLocationPermission == null ? "null" : this.MultiLocationPermission.ToString())}");
            toStringOutput.Add($"this.Name = {(this.Name == null ? "null" : this.Name == string.Empty ? "" : this.Name)}");
            toStringOutput.Add($"this.ProviderIDs = {(this.ProviderIDs == null ? "null" : $"[{string.Join(", ", this.ProviderIDs)} ]")}");
            toStringOutput.Add($"this.StaffSettings = {(this.StaffSettings == null ? "null" : this.StaffSettings.ToString())}");
            toStringOutput.Add($"this.Rep = {(this.Rep == null ? "null" : this.Rep.ToString())}");
            toStringOutput.Add($"this.Rep2 = {(this.Rep2 == null ? "null" : this.Rep2.ToString())}");
            toStringOutput.Add($"this.Rep3 = {(this.Rep3 == null ? "null" : this.Rep3.ToString())}");
            toStringOutput.Add($"this.Rep4 = {(this.Rep4 == null ? "null" : this.Rep4.ToString())}");
            toStringOutput.Add($"this.Rep5 = {(this.Rep5 == null ? "null" : this.Rep5.ToString())}");
            toStringOutput.Add($"this.Rep6 = {(this.Rep6 == null ? "null" : this.Rep6.ToString())}");
            toStringOutput.Add($"this.Assistant = {(this.Assistant == null ? "null" : this.Assistant.ToString())}");
            toStringOutput.Add($"this.Assistant2 = {(this.Assistant2 == null ? "null" : this.Assistant2.ToString())}");
            toStringOutput.Add($"this.EmploymentStart = {(this.EmploymentStart == null ? "null" : this.EmploymentStart.ToString())}");
            toStringOutput.Add($"this.EmploymentEnd = {(this.EmploymentEnd == null ? "null" : this.EmploymentEnd.ToString())}");
            toStringOutput.Add($"this.EmpID = {(this.EmpID == null ? "null" : this.EmpID == string.Empty ? "" : this.EmpID)}");
            toStringOutput.Add($"this.Appointments = {(this.Appointments == null ? "null" : $"[{string.Join(", ", this.Appointments)} ]")}");
            toStringOutput.Add($"this.Unavailabilities = {(this.Unavailabilities == null ? "null" : $"[{string.Join(", ", this.Unavailabilities)} ]")}");
            toStringOutput.Add($"this.Availabilities = {(this.Availabilities == null ? "null" : $"[{string.Join(", ", this.Availabilities)} ]")}");
            toStringOutput.Add($"this.LoginLocations = {(this.LoginLocations == null ? "null" : $"[{string.Join(", ", this.LoginLocations)} ]")}");
        }
    }
}