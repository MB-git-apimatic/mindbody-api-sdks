// <copyright file="MindbodyPublicApiDtoModelsV6ClientControllerGetMembershipsResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiDtoModelsV6ClientControllerGetMembershipsResponse.
    /// </summary>
    public class MindbodyPublicApiDtoModelsV6ClientControllerGetMembershipsResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClientControllerGetMembershipsResponse"/> class.
        /// </summary>
        public MindbodyPublicApiDtoModelsV6ClientControllerGetMembershipsResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClientControllerGetMembershipsResponse"/> class.
        /// </summary>
        /// <param name="memberships">Memberships.</param>
        public MindbodyPublicApiDtoModelsV6ClientControllerGetMembershipsResponse(
            List<Models.MindbodyPublicApiDtoModelsV6Membership> memberships = null)
        {
            this.Memberships = memberships;
        }

        /// <summary>
        /// Details about the memberships.
        /// </summary>
        [JsonProperty("Memberships", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.MindbodyPublicApiDtoModelsV6Membership> Memberships { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiDtoModelsV6ClientControllerGetMembershipsResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiDtoModelsV6ClientControllerGetMembershipsResponse other &&
                ((this.Memberships == null && other.Memberships == null) || (this.Memberships?.Equals(other.Memberships) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Memberships = {(this.Memberships == null ? "null" : $"[{string.Join(", ", this.Memberships)} ]")}");
        }
    }
}