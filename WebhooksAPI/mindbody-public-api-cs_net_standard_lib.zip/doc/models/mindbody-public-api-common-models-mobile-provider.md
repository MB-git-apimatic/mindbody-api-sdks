
# Mindbody Public Api Common Models Mobile Provider

## Structure

`MindbodyPublicApiCommonModelsMobileProvider`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | - |
| `Active` | `bool?` | Optional | - |
| `ProviderName` | `string` | Optional | - |
| `ProviderAddress` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "Id": null,
  "Active": null,
  "ProviderName": null,
  "ProviderAddress": null
}
```

