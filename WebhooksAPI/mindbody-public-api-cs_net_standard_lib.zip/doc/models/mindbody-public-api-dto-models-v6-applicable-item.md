
# Mindbody Public Api Dto Models V6 Applicable Item

Item that will be applied to a promo code

## Structure

`MindbodyPublicApiDtoModelsV6ApplicableItem`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Type` | `string` | Optional | Type of a promo code |
| `Id` | `int?` | Optional | ID of the item |
| `Name` | `string` | Optional | Name of the item |

## Example (as JSON)

```json
{
  "Type": null,
  "Id": null,
  "Name": null
}
```

