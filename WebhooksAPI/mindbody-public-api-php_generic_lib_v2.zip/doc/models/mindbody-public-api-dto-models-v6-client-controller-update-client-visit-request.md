
# Mindbody Public Api Dto Models V6 Client Controller Update Client Visit Request

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientVisitRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `visitId` | `int` | Required | The ID of the visit to be updated. | getVisitId(): int | setVisitId(int visitId): void |
| `makeup` | `?bool` | Optional | When `true`, indicates that the visit is eligible to be made up. | getMakeup(): ?bool | setMakeup(?bool makeup): void |
| `signedIn` | `?bool` | Optional | When `true`, indicates that the client has signed in for the visit. | getSignedIn(): ?bool | setSignedIn(?bool signedIn): void |
| `execute` | `?string` | Optional | The execute code used to update this visit. Possible values are:<br><br>* Cancel<br>* Latecancel<br>* Unlatecancel | getExecute(): ?string | setExecute(?string execute): void |
| `test` | `?bool` | Optional | When `true`, indicates that test mode is enabled. When test mode is enabled, input information is validated, but not committed.<br /><br>Default: **false** | getTest(): ?bool | setTest(?bool test): void |
| `sendEmail` | `?bool` | Optional | When `true`, indicates that the client should be sent an email for cancellations. Note that email is not sent unless the client has an email address and automatic emails have been set up correctly.<br /><br>Default: **false** | getSendEmail(): ?bool | setSendEmail(?bool sendEmail): void |

## Example (as JSON)

```json
{
  "VisitId": 196,
  "Makeup": null,
  "SignedIn": null,
  "Execute": null,
  "Test": null,
  "SendEmail": null
}
```

