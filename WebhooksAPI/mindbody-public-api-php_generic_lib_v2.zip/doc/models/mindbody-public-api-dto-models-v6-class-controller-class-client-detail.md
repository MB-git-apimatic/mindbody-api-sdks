
# Mindbody Public Api Dto Models V6 Class Controller Class Client Detail

Class Client Detail Object

## Structure

`MindbodyPublicApiDtoModelsV6ClassControllerClassClientDetail`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `clientIds` | `string[]` | Required | The RSSID of the clients to remove from the specified classes. | getClientIds(): array | setClientIds(array clientIds): void |
| `classId` | `int` | Required | The ID of the classes that you want to remove the clients from. | getClassId(): int | setClassId(int classId): void |

## Example (as JSON)

```json
{
  "ClientIds": [
    "ClientIds3",
    "ClientIds4"
  ],
  "ClassId": 58
}
```

