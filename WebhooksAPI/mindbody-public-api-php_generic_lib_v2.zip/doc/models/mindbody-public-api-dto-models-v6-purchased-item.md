
# Mindbody Public Api Dto Models V6 Purchased Item

## Structure

`MindbodyPublicApiDtoModelsV6PurchasedItem`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `saleDetailId` | `?int` | Optional | The ID of the sale detail | getSaleDetailId(): ?int | setSaleDetailId(?int saleDetailId): void |
| `id` | `?int` | Optional | The ProductID of the item. | getId(): ?int | setId(?int id): void |
| `isService` | `?bool` | Optional | When `true`, indicates that the purchased item was a pricing option for a service. | getIsService(): ?bool | setIsService(?bool isService): void |
| `barcodeId` | `?string` | Optional | The BarcodeId of the item.<br>For services, BarcodeId may be null<br>If no barcode id is explicitly set by the business it is the internal id in a string format. | getBarcodeId(): ?string | setBarcodeId(?string barcodeId): void |
| `description` | `?string` | Optional | Description of the sale transaction/pricing option description | getDescription(): ?string | setDescription(?string description): void |
| `contractId` | `?int` | Optional | Contract ID purchased by the client | getContractId(): ?int | setContractId(?int contractId): void |
| `categoryId` | `?int` | Optional | Revenue Category ID | getCategoryId(): ?int | setCategoryId(?int categoryId): void |
| `subCategoryId` | `?int` | Optional | Revenue Subcategory ID | getSubCategoryId(): ?int | setSubCategoryId(?int subCategoryId): void |
| `unitPrice` | `?float` | Optional | Per unit price of the item sold | getUnitPrice(): ?float | setUnitPrice(?float unitPrice): void |
| `quantity` | `?int` | Optional | Quantity of the products | getQuantity(): ?int | setQuantity(?int quantity): void |
| `discountPercent` | `?float` | Optional | Discount % applied during sale | getDiscountPercent(): ?float | setDiscountPercent(?float discountPercent): void |
| `discountAmount` | `?float` | Optional | Discount Amount | getDiscountAmount(): ?float | setDiscountAmount(?float discountAmount): void |
| `tax1` | `?float` | Optional | Tax1 applicable for the product | getTax1(): ?float | setTax1(?float tax1): void |
| `tax2` | `?float` | Optional | Tax2 applicable for the product | getTax2(): ?float | setTax2(?float tax2): void |
| `tax3` | `?float` | Optional | Tax3 applicable for the product | getTax3(): ?float | setTax3(?float tax3): void |
| `tax4` | `?float` | Optional | Tax4 applicable for the product | getTax4(): ?float | setTax4(?float tax4): void |
| `tax5` | `?float` | Optional | Tax5 applicable for the product | getTax5(): ?float | setTax5(?float tax5): void |
| `taxAmount` | `?float` | Optional | Tax rate applicable for the product | getTaxAmount(): ?float | setTaxAmount(?float taxAmount): void |
| `totalAmount` | `?float` | Optional | Charged to the customer for paying | getTotalAmount(): ?float | setTotalAmount(?float totalAmount): void |
| `notes` | `?string` | Optional | Notes | getNotes(): ?string | setNotes(?string notes): void |
| `returned` | `?bool` | Optional | Returned or not | getReturned(): ?bool | setReturned(?bool returned): void |
| `paymentRefId` | `?int` | Optional | Payment Reference ID | getPaymentRefId(): ?int | setPaymentRefId(?int paymentRefId): void |
| `expDate` | `?\DateTime` | Optional | Expiration date of the pricing option purchased | getExpDate(): ?\DateTime | setExpDate(?\DateTime expDate): void |
| `activeDate` | `?\DateTime` | Optional | Activation date of pricing option purchased | getActiveDate(): ?\DateTime | setActiveDate(?\DateTime activeDate): void |

## Example (as JSON)

```json
{
  "SaleDetailId": null,
  "Id": null,
  "IsService": null,
  "BarcodeId": null,
  "Description": null,
  "ContractId": null,
  "CategoryId": null,
  "SubCategoryId": null,
  "UnitPrice": null,
  "Quantity": null,
  "DiscountPercent": null,
  "DiscountAmount": null,
  "Tax1": null,
  "Tax2": null,
  "Tax3": null,
  "Tax4": null,
  "Tax5": null,
  "TaxAmount": null,
  "TotalAmount": null,
  "Notes": null,
  "Returned": null,
  "PaymentRefId": null,
  "ExpDate": null,
  "ActiveDate": null
}
```

