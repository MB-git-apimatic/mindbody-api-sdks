
# Schedule Type Enum

## Enumeration

`ScheduleTypeEnum`

## Fields

| Name |
|  --- |
| `ALL` |
| `CLASS_` |
| `ENROLLMENT` |
| `APPOINTMENT` |
| `RESOURCE` |
| `MEDIA` |
| `ARRIVAL` |

