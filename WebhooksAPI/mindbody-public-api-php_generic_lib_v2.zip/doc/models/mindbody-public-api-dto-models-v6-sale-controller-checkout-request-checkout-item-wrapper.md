
# Mindbody Public Api Dto Models V6 Sale Controller Checkout Request Checkout Item Wrapper

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerCheckoutRequestCheckoutItemWrapper`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `item` | [`?MindbodyPublicApiDtoModelsV6SaleControllerCheckoutRequestItemsCheckoutItem`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-checkout-request-items-checkout-item.md) | Optional | - | getItem(): ?MindbodyPublicApiDtoModelsV6SaleControllerCheckoutRequestItemsCheckoutItem | setItem(?MindbodyPublicApiDtoModelsV6SaleControllerCheckoutRequestItemsCheckoutItem item): void |
| `discountAmount` | `?float` | Optional | The amount the item is discounted. This parameter is ignored for packages. | getDiscountAmount(): ?float | setDiscountAmount(?float discountAmount): void |
| `appointmentBookingRequests` | [`?(MindbodyPublicApiDtoModelsV6SaleControllerCheckoutRequestCheckoutAppointmentBookingRequest[])`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-checkout-request-checkout-appointment-booking-request.md) | Optional | A list of appointments to be booked then paid for by this item. This parameter applies only to pricing option items. | getAppointmentBookingRequests(): ?array | setAppointmentBookingRequests(?array appointmentBookingRequests): void |
| `enrollmentIds` | `?(int[])` | Optional | A list of enrollment IDs that this item is to pay for. This parameter applies only to pricing option items. | getEnrollmentIds(): ?array | setEnrollmentIds(?array enrollmentIds): void |
| `classIds` | `?(int[])` | Optional | A list of class IDs that this item is to pay for. This parameter applies only to pricing option items. | getClassIds(): ?array | setClassIds(?array classIds): void |
| `courseIds` | `?(int[])` | Optional | A list of course IDs that this item is to pay for. This parameter applies only to pricing option items. | getCourseIds(): ?array | setCourseIds(?array courseIds): void |
| `visitIds` | `?(int[])` | Optional | A list of visit IDs that this item is to pay for. This parameter applies only to pricing option items. | getVisitIds(): ?array | setVisitIds(?array visitIds): void |
| `appointmentIds` | `?(int[])` | Optional | A list of appointment IDs that this item is to reconcile. | getAppointmentIds(): ?array | setAppointmentIds(?array appointmentIds): void |
| `id` | `?int` | Optional | The item’s unique ID within the cart. | getId(): ?int | setId(?int id): void |
| `quantity` | `?int` | Optional | The number of this item to be purchased. | getQuantity(): ?int | setQuantity(?int quantity): void |

## Example (as JSON)

```json
{
  "Item": null,
  "DiscountAmount": null,
  "AppointmentBookingRequests": null,
  "EnrollmentIds": null,
  "ClassIds": null,
  "CourseIds": null,
  "VisitIds": null,
  "AppointmentIds": null,
  "Id": null,
  "Quantity": null
}
```

