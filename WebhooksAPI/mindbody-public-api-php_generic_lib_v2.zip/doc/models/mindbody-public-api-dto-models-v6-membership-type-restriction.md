
# Mindbody Public Api Dto Models V6 Membership Type Restriction

## Structure

`MindbodyPublicApiDtoModelsV6MembershipTypeRestriction`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | The ID of the membership that is allowed to purchase the contract. | getId(): ?int | setId(?int id): void |
| `name` | `?string` | Optional | The name of the membership type. | getName(): ?string | setName(?string name): void |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null
}
```

