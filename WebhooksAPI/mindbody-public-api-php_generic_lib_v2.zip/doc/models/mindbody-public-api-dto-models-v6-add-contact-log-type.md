
# Mindbody Public Api Dto Models V6 Add Contact Log Type

Defines what sort of subtypes we want to add to this contact log type

## Structure

`MindbodyPublicApiDtoModelsV6AddContactLogType`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | The contact log type’s ID. | getId(): ?int | setId(?int id): void |
| `subTypes` | `?(int[])` | Optional | A list of the subtype IDs used to tag this contact log type. | getSubTypes(): ?array | setSubTypes(?array subTypes): void |

## Example (as JSON)

```json
{
  "Id": null,
  "SubTypes": null
}
```

