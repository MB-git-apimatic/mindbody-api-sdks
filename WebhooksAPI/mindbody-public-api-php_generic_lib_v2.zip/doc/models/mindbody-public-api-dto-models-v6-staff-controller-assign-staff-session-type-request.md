
# Mindbody Public Api Dto Models V6 Staff Controller Assign Staff Session Type Request

## Structure

`MindbodyPublicApiDtoModelsV6StaffControllerAssignStaffSessionTypeRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `staffId` | `int` | Required | The ID of the staff member session type is getting assigned to. The staff member must be assignable to appointments or already be assigned to the session type in the request.<br>**Constraints**: `>= 1` | getStaffId(): int | setStaffId(int staffId): void |
| `sessionTypeId` | `int` | Required | The ID of the session type that is getting assigned to the staff member. The session type must be an appointment.<br>**Constraints**: `>= 1`, `<= 2147483647` | getSessionTypeId(): int | setSessionTypeId(int sessionTypeId): void |
| `active` | `bool` | Required | Indicates if assignment is active. Passing `false` is equivalent to deleting the assignment. | getActive(): bool | setActive(bool active): void |
| `timeLength` | `?int` | Optional | The staff specific amount of time that a session of this type typically lasts. | getTimeLength(): ?int | setTimeLength(?int timeLength): void |
| `prepTime` | `?int` | Optional | Prep time in minutes | getPrepTime(): ?int | setPrepTime(?int prepTime): void |
| `finishTime` | `?int` | Optional | Finish time in minutes | getFinishTime(): ?int | setFinishTime(?int finishTime): void |
| `payRateType` | `?string` | Optional | The pay rate type. Can be one of the following (case insensitive):<br>Percent<br>Flat<br>No Pay<br>If PayRateType is not provided in the request and the request is creating a completely new assignment (not editing an existing active or inactive assignment), then the staff member default pay rate and pay rate amount are used to create the assignment. Otherwise, the existing assignment values are used for any optional request parameters not included in the request. | getPayRateType(): ?string | setPayRateType(?string payRateType): void |
| `payRateAmount` | `?float` | Optional | The pay rate amount for the specific staff member. It is parsed according to the PayRateType. | getPayRateAmount(): ?float | setPayRateAmount(?float payRateAmount): void |

## Example (as JSON)

```json
{
  "StaffId": 156,
  "SessionTypeId": 50,
  "Active": false,
  "TimeLength": null,
  "PrepTime": null,
  "FinishTime": null,
  "PayRateType": null,
  "PayRateAmount": null
}
```

