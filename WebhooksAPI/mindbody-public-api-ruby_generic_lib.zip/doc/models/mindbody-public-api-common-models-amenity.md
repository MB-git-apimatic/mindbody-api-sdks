
# Mindbody Public Api Common Models Amenity

A specific amenity at a location

## Structure

`MindbodyPublicApiCommonModelsAmenity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Optional | The identifying ID of the amenity. |
| `name` | `String` | Optional | The name of the amenity (e.g. "Lockers" or "Food/Drink"). |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null
}
```

