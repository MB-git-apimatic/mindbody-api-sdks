
# Mindbody Public Api Dto Models V6 Sale Controller Get Gift Card Balance Response

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerGetGiftCardBalanceResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `barcode_id` | `String` | Optional | The gift card's barcode ID. |
| `remaining_balance` | `Float` | Optional | The gift card's remaining balance. |

## Example (as JSON)

```json
{
  "BarcodeId": null,
  "RemainingBalance": null
}
```

