
# Days of Week Enum

## Enumeration

`DaysOfWeekEnum`

## Fields

| Name |
|  --- |
| `SUNDAY` |
| `MONDAY` |
| `TUESDAY` |
| `WEDNESDAY` |
| `THURSDAY` |
| `FRIDAY` |
| `SATURDAY` |

