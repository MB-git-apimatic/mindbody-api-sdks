
# Mindbody Public Api Dto Models V6 Appointment Add On

## Structure

`MindbodyPublicApiDtoModelsV6AppointmentAddOn`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Optional | - |
| `name` | `String` | Optional | - |
| `num_deducted` | `Integer` | Optional | - |
| `category_id` | `Integer` | Optional | - |
| `category` | `String` | Optional | - |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null,
  "NumDeducted": null,
  "CategoryId": null,
  "Category": null
}
```

