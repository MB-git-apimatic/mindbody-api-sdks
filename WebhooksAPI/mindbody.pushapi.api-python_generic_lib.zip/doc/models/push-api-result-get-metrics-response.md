
# Push Api Result Get Metrics Response

A result returned for every request to the push API

## Structure

`PushApiResultGetMetricsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `is_success` | `bool` | Optional | - |
| `value` | [`GetMetricsResponse`](../../doc/models/get-metrics-response.md) | Optional | A wrapper for returning subscription metrics to API users |
| `error_information` | [`List of PushApiError`](../../doc/models/push-api-error.md) | Optional | - |

## Example (as JSON)

```json
{
  "value": null
}
```

