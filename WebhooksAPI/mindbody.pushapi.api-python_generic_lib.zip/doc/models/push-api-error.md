
# Push Api Error

An error returned by the push API for application errors

## Structure

`PushApiError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `error_code` | `int` | Optional | A unique ID for the returned error code |
| `error_message` | `string` | Optional | A message indicating what went wrong |
| `error_type` | `string` | Optional | A category/type associated with the error |

## Example (as JSON)

```json
{
  "errorCode": null,
  "errorMessage": null,
  "errorType": null
}
```

