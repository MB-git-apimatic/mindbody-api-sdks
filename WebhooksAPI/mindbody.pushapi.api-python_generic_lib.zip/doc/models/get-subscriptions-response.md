
# Get Subscriptions Response

A wrapper for a get subscriptions request

## Structure

`GetSubscriptionsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `items` | [`List of Subscription`](../../doc/models/subscription.md) | Optional | A list of subscriptions |

## Example (as JSON)

```json
{
  "items": null
}
```

