
# Deactivate Subscription Response

Returned after a subscription is deactivated

## Structure

`DeactivateSubscriptionResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `message` | `string` | Optional | A message about the deactivation request. Unless an error occurs, this message always `"Subscription deactivated successfully."`. |
| `deactivation_date_time` | `datetime` | Optional | The UTC date and time when the deactivation took place. |
| `subscription_id` | `uuid\|string` | Optional | The subscription ID (a GUID). |
| `reference_id` | `string` | Optional | The subscription's reference ID, assigned when the subscription was created. |

## Example (as JSON)

```json
{
  "message": null,
  "deactivationDateTime": null,
  "subscriptionId": null,
  "referenceId": null
}
```

