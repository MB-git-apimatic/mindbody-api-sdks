
# Get Metrics Response

A wrapper for returning subscription metrics to API users

## Structure

`GetMetricsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `items` | [`List of Metric`](../../doc/models/metric.md) | Optional | Contains the metrics for the passed subscription |

## Example (as JSON)

```json
{
  "items": null
}
```

