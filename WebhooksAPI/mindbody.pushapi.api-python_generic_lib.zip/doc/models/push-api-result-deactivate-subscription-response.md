
# Push Api Result Deactivate Subscription Response

A result returned for every request to the push API

## Structure

`PushApiResultDeactivateSubscriptionResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `is_success` | `bool` | Optional | - |
| `value` | [`DeactivateSubscriptionResponse`](../../doc/models/deactivate-subscription-response.md) | Optional | Returned after a subscription is deactivated |
| `error_information` | [`List of PushApiError`](../../doc/models/push-api-error.md) | Optional | - |

## Example (as JSON)

```json
{
  "value": null
}
```

