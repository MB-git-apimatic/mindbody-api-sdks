
# Mindbody Public Api Dto Models V6 Sale Payment

## Structure

`MindbodyPublicApiDtoModelsV6SalePayment`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `long\|int` | Optional | A unique identifier for this payment. |
| `amount` | `float` | Optional | The amount of this payment. |
| `method` | `int` | Optional | The method for this payment. |
| `mtype` | `string` | Optional | The type of payment. |
| `notes` | `string` | Optional | Notes about this payment. |
| `transaction_id` | `int` | Optional | The payment transaction ID |

## Example (as JSON)

```json
{
  "Id": null,
  "Amount": null,
  "Method": null,
  "Type": null,
  "Notes": null,
  "TransactionId": null
}
```

