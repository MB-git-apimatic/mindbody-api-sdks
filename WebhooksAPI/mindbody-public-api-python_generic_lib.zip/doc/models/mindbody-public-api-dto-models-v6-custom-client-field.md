
# Mindbody Public Api Dto Models V6 Custom Client Field

A custom client field

## Structure

`MindbodyPublicApiDtoModelsV6CustomClientField`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Optional | The ID of the custom client field. |
| `data_type` | `string` | Optional | The data type of the field. |
| `name` | `string` | Optional | The name of the field. |

## Example (as JSON)

```json
{
  "Id": null,
  "DataType": null,
  "Name": null
}
```

