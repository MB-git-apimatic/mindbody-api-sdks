
# Mindbody Public Api Dto Models V6 Sale Controller Checkout Request Items Checkout Item

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerCheckoutRequestItemsCheckoutItem`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mtype` | `string` | Optional | The type of item. Possible values are:<br><br>* Service - Indicates that this item is a pricing option.<br>* Product - Indicates that this item is a retail product.<br>* Package - Indicates that this item is a package.<br>* Tip - Indicates that this item is a tip. |
| `metadata` | `dict` | Optional | Contains information about the item to be purchased. See [Cart Item Metadata](https://developers.mindbodyonline.com/PublicDocumentation/V6#cart-item-metadata) for more information. |

## Example (as JSON)

```json
{
  "Type": null,
  "Metadata": null
}
```

