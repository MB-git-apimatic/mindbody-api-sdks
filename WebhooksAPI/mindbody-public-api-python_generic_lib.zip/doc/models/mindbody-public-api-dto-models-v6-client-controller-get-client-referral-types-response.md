
# Mindbody Public Api Dto Models V6 Client Controller Get Client Referral Types Response

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerGetClientReferralTypesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `referral_types` | `List of string` | Optional | The list of available referral types. |

## Example (as JSON)

```json
{
  "ReferralTypes": null
}
```

