
# Mindbody Public Api Dto Models V6 Site Controller Get Resources Response

## Structure

`MindbodyPublicApiDtoModelsV6SiteControllerGetResourcesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | Contains information about the pagination to use. |
| `resources` | [`List of MindbodyPublicApiDtoModelsV6Resource`](../../doc/models/mindbody-public-api-dto-models-v6-resource.md) | Optional | Contains information about resources as the business. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Resources": null
}
```

