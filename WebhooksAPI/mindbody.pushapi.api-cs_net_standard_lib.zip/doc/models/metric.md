
# Metric

Metrics for subscription

## Structure

`Metric`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SubscriptionId` | `Guid?` | Optional | The subscription's ID (a GUID). |
| `Status` | `string` | Optional | The subscription's current status. **Possible Values**:<br /><br>`PendingActivation` - The subscription is created but not receiving event notifications.To start receiving event notifications, set the subscription’s status to Active using the PATCH Subscription endpoint.<br /><br>`Active` - The subscription is active and can receive event notifications.<br /><br>`DeactivatedByUser` - You deactivated the subscription.<br /><br>`DeactivatedByAdmin` - Mindbody deactivated your subscription.<br /><br>`DeactivatedTooManyFailedMessageDeliveryAttempts` - The subscription was deactivated because Mindbody stopped receiving a 2xx HTTP status code from the webhookUrl when posting events. An automated email will be sent to the developer portal email on the account with additional details.<br /><br>`DeactivatedByEventDeactivation` - One of the event IDs associated with the subscription was deactivated, which invalidated and deactivated the subscription. If this occurs, you must create a new subscription using only up-to-date event IDs.<br /> |
| `StatusChangeDate` | `DateTime?` | Optional | The UTC date and time when the subscription `status` was last updated. |
| `CreationDateTime` | `DateTime?` | Optional | The UTC date and time when the subscription was created. |
| `MessagesAttempted` | `long?` | Optional | The number of event notifications Mindbody attempted to deliver to the subscription `webhookUrl`, including retries. |
| `MessagesDelivered` | `long?` | Optional | The number of event notifications Mindbody successfully delivered to the subscription `webhookUrl`. |
| `MessagesUndelivered` | `long?` | Optional | The number of event notifications where MINDBODY received a failure response from the subscription `webhookUrl`. |
| `MessagesFailed` | `long?` | Optional | The number of event notifications that Mindbody stopped trying to send after 3 hours. |

## Example (as JSON)

```json
{
  "subscriptionId": null,
  "status": null,
  "statusChangeDate": null,
  "creationDateTime": null,
  "messagesAttempted": null,
  "messagesDelivered": null,
  "messagesUndelivered": null,
  "messagesFailed": null
}
```

