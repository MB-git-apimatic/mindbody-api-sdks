
# Push Api Result Deactivate Subscription Response

A result returned for every request to the push API

## Structure

`PushApiResultDeactivateSubscriptionResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `IsSuccess` | `bool?` | Optional | - |
| `MValue` | [`Models.DeactivateSubscriptionResponse`](../../doc/models/deactivate-subscription-response.md) | Optional | Returned after a subscription is deactivated |
| `ErrorInformation` | [`List<Models.PushApiError>`](../../doc/models/push-api-error.md) | Optional | - |

## Example (as JSON)

```json
{
  "value": null
}
```

