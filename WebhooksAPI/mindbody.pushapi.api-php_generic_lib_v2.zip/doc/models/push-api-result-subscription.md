
# Push Api Result Subscription

A result returned for every request to the push API

## Structure

`PushApiResultSubscription`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `isSuccess` | `?bool` | Optional | - | getIsSuccess(): ?bool | setIsSuccess(?bool isSuccess): void |
| `value` | [`?Subscription`](../../doc/models/subscription.md) | Optional | A webhook subscription | getValue(): ?Subscription | setValue(?Subscription value): void |
| `errorInformation` | [`?(PushApiError[])`](../../doc/models/push-api-error.md) | Optional | - | getErrorInformation(): ?array | setErrorInformation(?array errorInformation): void |

## Example (as JSON)

```json
{
  "value": null
}
```

