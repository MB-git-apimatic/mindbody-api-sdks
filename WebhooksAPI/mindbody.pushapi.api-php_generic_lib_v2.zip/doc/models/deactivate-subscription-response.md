
# Deactivate Subscription Response

Returned after a subscription is deactivated

## Structure

`DeactivateSubscriptionResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `message` | `?string` | Optional | A message about the deactivation request. Unless an error occurs, this message always `"Subscription deactivated successfully."`. | getMessage(): ?string | setMessage(?string message): void |
| `deactivationDateTime` | `?\DateTime` | Optional | The UTC date and time when the deactivation took place. | getDeactivationDateTime(): ?\DateTime | setDeactivationDateTime(?\DateTime deactivationDateTime): void |
| `subscriptionId` | `?string` | Optional | The subscription ID (a GUID). | getSubscriptionId(): ?string | setSubscriptionId(?string subscriptionId): void |
| `referenceId` | `?string` | Optional | The subscription's reference ID, assigned when the subscription was created. | getReferenceId(): ?string | setReferenceId(?string referenceId): void |

## Example (as JSON)

```json
{
  "message": null,
  "deactivationDateTime": null,
  "subscriptionId": null,
  "referenceId": null
}
```

