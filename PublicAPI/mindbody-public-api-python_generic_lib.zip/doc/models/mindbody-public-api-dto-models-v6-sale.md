
# Mindbody Public Api Dto Models V6 Sale

## Structure

`MindbodyPublicApiDtoModelsV6Sale`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `long\|int` | Optional | The sale ID. |
| `sale_date` | `datetime` | Optional | The date the item was sold. |
| `sale_time` | `string` | Optional | The time the item was sold. |
| `sale_date_time` | `datetime` | Optional | The date and time the item was sold. |
| `original_sale_date_time` | `datetime` | Optional | The date and time the item was sold originally. |
| `sales_rep_id` | `long\|int` | Optional | The sales representative ID |
| `client_id` | `string` | Optional | The ID of the client who made the purchase. |
| `recipient_client_id` | `long\|int` | Optional | Recipient Client Id |
| `purchased_items` | [`List of MindbodyPublicApiDtoModelsV6PurchasedItem`](../../doc/models/mindbody-public-api-dto-models-v6-purchased-item.md) | Optional | Contains information that describes the purchased items. |
| `location_id` | `int` | Optional | The ID of the location where the sale takes place. |
| `payments` | [`List of MindbodyPublicApiDtoModelsV6SalePayment`](../../doc/models/mindbody-public-api-dto-models-v6-sale-payment.md) | Optional | Contains information that describes the payments that contributed to this sale. |

## Example (as JSON)

```json
{
  "Id": null,
  "SaleDate": null,
  "SaleTime": null,
  "SaleDateTime": null,
  "OriginalSaleDateTime": null,
  "SalesRepId": null,
  "ClientId": null,
  "RecipientClientId": null,
  "PurchasedItems": null,
  "LocationId": null,
  "Payments": null
}
```

