
# Mindbody Public Api Dto Models V6 Client Controller Get Client Services Response

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerGetClientServicesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | Contains information about the pagination to use. |
| `client_services` | [`List of MindbodyPublicApiDtoModelsV6ClientService`](../../doc/models/mindbody-public-api-dto-models-v6-client-service.md) | Optional | Contains information about client pricing options. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "ClientServices": null
}
```

