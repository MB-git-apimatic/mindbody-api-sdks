
# Mindbody Public Api Dto Models V6 Client Memberships

## Structure

`MindbodyPublicApiDtoModelsV6ClientMemberships`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `client_id` | `string` | Optional | ID of the client. |
| `memberships` | [`List of MindbodyPublicApiDtoModelsV6ClientMembership`](../../doc/models/mindbody-public-api-dto-models-v6-client-membership.md) | Optional | Client membership details |
| `error_message` | `string` | Optional | Used to return error message on conditional basis |

## Example (as JSON)

```json
{
  "ClientId": null,
  "Memberships": null,
  "ErrorMessage": null
}
```

