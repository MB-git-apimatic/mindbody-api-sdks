
# Mindbody Public Api Dto Models V6 Site Controller Get Categories Response

Get Categories Response Model

## Structure

`MindbodyPublicApiDtoModelsV6SiteControllerGetCategoriesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | Contains information about the pagination to use. |
| `categories` | [`List of MindbodyPublicApiCommonModelsCategory`](../../doc/models/mindbody-public-api-common-models-category.md) | Optional | Contains the Category objects, each of which describes the categories for a site. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Categories": null
}
```

