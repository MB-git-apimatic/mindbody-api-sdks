
# Mindbody Public Api Dto Models V6 Client Controller Update Client Service Request

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientServiceRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `service_id` | `int` | Required | The ID of the service to update. |
| `active_date` | `datetime` | Optional | The date that the service became active. |
| `expiration_date` | `datetime` | Optional | The date that the service is to expire. |
| `count` | `int` | Optional | The number of client service sessions to update. |
| `test` | `bool` | Optional | When `true`, indicates that input information is to be validated, but not committed.<br /><br>When `false` or omitted, the database is affected.<br /><br>Default: **false** |

## Example (as JSON)

```json
{
  "ServiceId": 158,
  "ActiveDate": null,
  "ExpirationDate": null,
  "Count": null,
  "Test": null
}
```

