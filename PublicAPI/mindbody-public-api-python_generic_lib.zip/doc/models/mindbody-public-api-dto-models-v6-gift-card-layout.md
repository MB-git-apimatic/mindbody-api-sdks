
# Mindbody Public Api Dto Models V6 Gift Card Layout

Gift card layout

## Structure

`MindbodyPublicApiDtoModelsV6GiftCardLayout`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `layout_id` | `int` | Optional | The ID of the layout. |
| `layout_name` | `string` | Optional | The name of the layout. |
| `layout_url` | `string` | Optional | The URL of the layout. |

## Example (as JSON)

```json
{
  "LayoutId": null,
  "LayoutName": null,
  "LayoutUrl": null
}
```

