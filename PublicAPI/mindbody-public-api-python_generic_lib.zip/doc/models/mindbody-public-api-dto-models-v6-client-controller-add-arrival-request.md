
# Mindbody Public Api Dto Models V6 Client Controller Add Arrival Request

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerAddArrivalRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `client_id` | `string` | Required | The ID of the requested client. |
| `location_id` | `int` | Required | The ID of the location for the requested arrival. |
| `arrival_type_id` | `int` | Optional | The ID of the arrival program (service category) under which this arrival is to be logged. If this is not provided, the program ID of the first arrival pricing option found will be used.<br>OPTIONAL: will take first payment found if not provided |
| `test` | `bool` | Optional | When `true`, indicates that the arrival log is to be validated, but no new arrival data is added. When `false`, the arrival is logged and the database is affected.<br>Default: **false** |

## Example (as JSON)

```json
{
  "ClientId": "ClientId6",
  "LocationId": 50,
  "ArrivalTypeId": null,
  "Test": null
}
```

