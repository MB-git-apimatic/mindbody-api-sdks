
# Mindbody Public Api Dto Models V6 Promo Code

## Structure

`MindbodyPublicApiDtoModelsV6PromoCode`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string` | Optional | Name of the promo code |
| `code` | `string` | Optional | Code to be used at purchase for discount |
| `active` | `bool` | Optional | Active status |
| `discount` | [`MindbodyPublicApiDtoModelsV6Discount`](../../doc/models/mindbody-public-api-dto-models-v6-discount.md) | Optional | Discount for a promo code |
| `activation_date` | `datetime` | Optional | Date activated |
| `expiration_date` | `datetime` | Optional | Date expired |
| `max_uses` | `int` | Optional | How many times it can be used |
| `number_of_autopays` | `int` | Optional | Number of Autopays |
| `days_after_close_date` | `int` | Optional | Days after close date |
| `allow_online` | `bool` | Optional | Whether it can be used online |
| `days_valid` | [`List of DaysValidEnum`](../../doc/models/days-valid-enum.md) | Optional | What days the promo code can be used |
| `applicable_items` | [`List of MindbodyPublicApiDtoModelsV6ApplicableItem`](../../doc/models/mindbody-public-api-dto-models-v6-applicable-item.md) | Optional | Items that the promo code will have the discount for |

## Example (as JSON)

```json
{
  "Name": null,
  "Code": null,
  "Active": null,
  "Discount": null,
  "ActivationDate": null,
  "ExpirationDate": null,
  "MaxUses": null,
  "NumberOfAutopays": null,
  "DaysAfterCloseDate": null,
  "AllowOnline": null,
  "DaysValid": null,
  "ApplicableItems": null
}
```

