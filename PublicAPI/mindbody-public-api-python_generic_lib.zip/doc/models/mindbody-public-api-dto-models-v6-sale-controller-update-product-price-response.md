
# Mindbody Public Api Dto Models V6 Sale Controller Update Product Price Response

Update Product Price Response Model

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerUpdateProductPriceResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `product` | [`MindbodyPublicApiDtoModelsV6Product`](../../doc/models/mindbody-public-api-dto-models-v6-product.md) | Optional | - |

## Example (as JSON)

```json
{
  "Product": null
}
```

