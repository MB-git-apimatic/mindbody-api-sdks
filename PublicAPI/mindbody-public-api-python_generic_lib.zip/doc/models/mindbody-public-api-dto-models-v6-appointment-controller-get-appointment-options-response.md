
# Mindbody Public Api Dto Models V6 Appointment Controller Get Appointment Options Response

## Structure

`MindbodyPublicApiDtoModelsV6AppointmentControllerGetAppointmentOptionsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `options` | [`List of MindbodyPublicApiDtoModelsV6AppointmentOption`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-option.md) | Optional | Contains information about the appointment options. |

## Example (as JSON)

```json
{
  "Options": null
}
```

