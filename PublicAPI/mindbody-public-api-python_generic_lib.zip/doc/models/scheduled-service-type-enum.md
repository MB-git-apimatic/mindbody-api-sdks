
# Scheduled Service Type Enum

The type of the scheduled service; i.e, a class, appointment, or enrollment.

## Enumeration

`ScheduledServiceTypeEnum`

## Fields

| Name |
|  --- |
| `CLASS` |
| `APPOINTMENT` |
| `ENROLLMENT` |
| `ALL` |

