
# Action Enum

## Enumeration

`ActionEnum`

## Fields

| Name |
|  --- |
| `ENUM_NONE` |
| `ADDED` |
| `UPDATED` |
| `FAILED` |
| `REMOVED` |

