
# Mindbody Public Api Dto Models V6 Site Controller Get Relationships Response

Get Relationships Response Model

## Structure

`MindbodyPublicApiDtoModelsV6SiteControllerGetRelationshipsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | Contains information about the pagination to use. |
| `relationships` | [`List of MindbodyPublicApiDtoModelsV6Relationship`](../../doc/models/mindbody-public-api-dto-models-v6-relationship.md) | Optional | A list of relationships. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Relationships": null
}
```

