
# Mindbody Public Api Common Models Sub Category

## Structure

`MindbodyPublicApiCommonModelsSubCategory`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Optional | The sub category Id used for api calls. |
| `sub_category_name` | `string` | Optional | Sub Category Name |
| `active` | `bool` | Optional | Check if Sub Category is active. |

## Example (as JSON)

```json
{
  "Id": null,
  "SubCategoryName": null,
  "Active": null
}
```

