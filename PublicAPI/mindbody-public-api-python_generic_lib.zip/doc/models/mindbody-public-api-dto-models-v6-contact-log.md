
# Mindbody Public Api Dto Models V6 Contact Log

A contact log.

## Structure

`MindbodyPublicApiDtoModelsV6ContactLog`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `long\|int` | Optional | The contact log’s ID. |
| `text` | `string` | Optional | The contact log’s body text. |
| `created_date_time` | `datetime` | Optional | The local date and time when the contact log was created. |
| `followup_by_date` | `datetime` | Optional | The date by which the assigned staff member should close or follow up on this contact log. |
| `contact_method` | `string` | Optional | The method by which the client wants to be contacted. |
| `contact_name` | `string` | Optional | The name of the client to contact. |
| `client` | [`MindbodyPublicApiDtoModelsV6Client`](../../doc/models/mindbody-public-api-dto-models-v6-client.md) | Optional | The Client. |
| `created_by` | [`MindbodyPublicApiDtoModelsV6Staff`](../../doc/models/mindbody-public-api-dto-models-v6-staff.md) | Optional | The Staff |
| `assigned_to` | [`MindbodyPublicApiDtoModelsV6Staff`](../../doc/models/mindbody-public-api-dto-models-v6-staff.md) | Optional | The Staff |
| `comments` | [`List of MindbodyPublicApiDtoModelsV6ContactLogComment`](../../doc/models/mindbody-public-api-dto-models-v6-contact-log-comment.md) | Optional | The contact log’s comments. |
| `types` | [`List of MindbodyPublicApiDtoModelsV6ContactLogType`](../../doc/models/mindbody-public-api-dto-models-v6-contact-log-type.md) | Optional | Contains information about contact log types. |

## Example (as JSON)

```json
{
  "Id": null,
  "Text": null,
  "CreatedDateTime": null,
  "FollowupByDate": null,
  "ContactMethod": null,
  "ContactName": null,
  "Client": null,
  "CreatedBy": null,
  "AssignedTo": null,
  "Comments": null,
  "Types": null
}
```

