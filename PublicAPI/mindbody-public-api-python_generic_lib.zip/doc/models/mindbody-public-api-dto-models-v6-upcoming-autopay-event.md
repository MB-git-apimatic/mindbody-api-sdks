
# Mindbody Public Api Dto Models V6 Upcoming Autopay Event

## Structure

`MindbodyPublicApiDtoModelsV6UpcomingAutopayEvent`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `client_contract_id` | `int` | Optional | The ID of the contract. |
| `charge_amount` | `float` | Optional | The amount charged. |
| `payment_method` | [`PaymentMethodEnum`](../../doc/models/payment-method-enum.md) | Optional | The payment method. |
| `schedule_date` | `datetime` | Optional | The date and time of the next payment. |

## Example (as JSON)

```json
{
  "ClientContractId": null,
  "ChargeAmount": null,
  "PaymentMethod": null,
  "ScheduleDate": null
}
```

