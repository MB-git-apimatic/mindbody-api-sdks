
# Mindbody Public Api Dto Models V6 Site Controller Get Session Types Response

## Structure

`MindbodyPublicApiDtoModelsV6SiteControllerGetSessionTypesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | Contains information about the pagination to use. |
| `session_types` | [`List of MindbodyPublicApiDtoModelsV6SessionType`](../../doc/models/mindbody-public-api-dto-models-v6-session-type.md) | Optional | Contains information about sessions. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "SessionTypes": null
}
```

