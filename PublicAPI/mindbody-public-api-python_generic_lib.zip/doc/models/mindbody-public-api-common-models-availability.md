
# Mindbody Public Api Common Models Availability

The availability of a specific staff

## Structure

`MindbodyPublicApiCommonModelsAvailability`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Optional | Id of the availability |
| `staff` | [`MindbodyPublicApiCommonModelsStaff`](../../doc/models/mindbody-public-api-common-models-staff.md) | Optional | - |
| `session_type` | [`MindbodyPublicApiCommonModelsSessionType`](../../doc/models/mindbody-public-api-common-models-session-type.md) | Optional | - |
| `programs` | [`List of MindbodyPublicApiCommonModelsProgram`](../../doc/models/mindbody-public-api-common-models-program.md) | Optional | Availabilities program list. |
| `start_date_time` | `datetime` | Optional | Availabilities start date and time. |
| `end_date_time` | `datetime` | Optional | Availabilities end date and time. |
| `bookable_end_date_time` | `datetime` | Optional | Availabilities bookable end date and time. |
| `location` | [`MindbodyPublicApiCommonModelsLocation`](../../doc/models/mindbody-public-api-common-models-location.md) | Optional | - |
| `prep_time` | `int` | Optional | Appointment prep time |
| `finish_time` | `int` | Optional | Appointment finish time |

## Example (as JSON)

```json
{
  "Id": null,
  "Staff": null,
  "SessionType": null,
  "Programs": null,
  "StartDateTime": null,
  "EndDateTime": null,
  "BookableEndDateTime": null,
  "Location": null,
  "PrepTime": null,
  "FinishTime": null
}
```

