
# Mindbody Public Api Dto Models V6 Client Controller Add Client Response

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerAddClientResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `client` | [`MindbodyPublicApiDtoModelsV6Client`](../../doc/models/mindbody-public-api-dto-models-v6-client.md) | Optional | The Client. |

## Example (as JSON)

```json
{
  "Client": null
}
```

