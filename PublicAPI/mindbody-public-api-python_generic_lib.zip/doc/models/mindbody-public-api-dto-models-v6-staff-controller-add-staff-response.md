
# Mindbody Public Api Dto Models V6 Staff Controller Add Staff Response

## Structure

`MindbodyPublicApiDtoModelsV6StaffControllerAddStaffResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `staff` | [`MindbodyPublicApiDtoModelsV6Staff`](../../doc/models/mindbody-public-api-dto-models-v6-staff.md) | Optional | The Staff |

## Example (as JSON)

```json
{
  "Staff": null
}
```

