
# Mindbody Public Api Dto Models V6 Contract Item

## Structure

`MindbodyPublicApiDtoModelsV6ContractItem`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Optional | The ID of the item. |
| `name` | `string` | Optional | The name of the item. |
| `description` | `string` | Optional | A description of the item. |
| `mtype` | `string` | Optional | The type of the item. |
| `price` | `float` | Optional | The price of the item. |
| `quantity` | `int` | Optional | The quantity of the item. |
| `one_time_item` | `bool` | Optional | When `true`, indicates that the item is charged only once.<br /><br>When `false`, indicates that the item is charged multiple times. |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null,
  "Description": null,
  "Type": null,
  "Price": null,
  "Quantity": null,
  "OneTimeItem": null
}
```

