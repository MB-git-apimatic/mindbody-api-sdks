
# Schedule Type 2 Enum

## Enumeration

`ScheduleType2Enum`

## Fields

| Name |
|  --- |
| `ALL` |
| `DROPIN` |
| `ENROLLMENT` |
| `APPOINTMENT` |
| `RESOURCE` |
| `MEDIA` |
| `ARRIVAL` |

