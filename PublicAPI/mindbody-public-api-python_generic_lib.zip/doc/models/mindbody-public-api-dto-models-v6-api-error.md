
# Mindbody Public Api Dto Models V6 Api Error

## Structure

`MindbodyPublicApiDtoModelsV6ApiError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `message` | `string` | Optional | - |
| `code` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "Message": null,
  "Code": null
}
```

