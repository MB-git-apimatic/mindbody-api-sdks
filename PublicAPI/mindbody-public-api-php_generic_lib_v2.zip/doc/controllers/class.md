# Class

```php
$mClassController = $client->getMClassController();
```

## Class Name

`MClassController`

## Methods

* [Class Get Classes](../../doc/controllers/class.md#class-get-classes)
* [Class Get Class Descriptions](../../doc/controllers/class.md#class-get-class-descriptions)
* [Class Get Class Visits](../../doc/controllers/class.md#class-get-class-visits)
* [Class Remove Client From Class](../../doc/controllers/class.md#class-remove-client-from-class)
* [Class Add Class Schedule](../../doc/controllers/class.md#class-add-class-schedule)
* [Class Update Class Schedule](../../doc/controllers/class.md#class-update-class-schedule)
* [Class Add Client to Class](../../doc/controllers/class.md#class-add-client-to-class)
* [Class Get Class Schedules](../../doc/controllers/class.md#class-get-class-schedules)
* [Class Get Waitlist Entries](../../doc/controllers/class.md#class-get-waitlist-entries)
* [Class Remove From Waitlist](../../doc/controllers/class.md#class-remove-from-waitlist)
* [Class Substitute Class Teacher](../../doc/controllers/class.md#class-substitute-class-teacher)
* [Class Remove Clients From Classes](../../doc/controllers/class.md#class-remove-clients-from-classes)
* [Class Get Courses](../../doc/controllers/class.md#class-get-courses)
* [Class Cancel Single Class](../../doc/controllers/class.md#class-cancel-single-class)
* [Class Get Semesters Async](../../doc/controllers/class.md#class-get-semesters-async)


# Class Get Classes

Get scheduled classes.

```php
function classGetClasses(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?array $requestClassDescriptionIds = null,
    ?array $requestClassIds = null,
    ?array $requestClassScheduleIds = null,
    ?string $requestClientId = null,
    ?\DateTime $requestEndDateTime = null,
    ?bool $requestHideCanceledClasses = null,
    ?\DateTime $requestLastModifiedDate = null,
    ?int $requestLimit = null,
    ?array $requestLocationIds = null,
    ?int $requestOffset = null,
    ?array $requestProgramIds = null,
    ?bool $requestSchedulingWindow = null,
    ?array $requestSemesterIds = null,
    ?array $requestSessionTypeIds = null,
    ?array $requestStaffIds = null,
    ?\DateTime $requestStartDateTime = null
): MindbodyPublicApiDtoModelsV6ClassControllerGetClassesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestClassDescriptionIds` | `?(int[])` | Query, Optional | The requested class description IDs. |
| `requestClassIds` | `?(int[])` | Query, Optional | The requested class IDs. |
| `requestClassScheduleIds` | `?(int[])` | Query, Optional | The requested classSchedule Ids. |
| `requestClientId` | `?string` | Query, Optional | The client ID of the client who is viewing this class list. Based on identity, the client may be able to see additional information, such as membership specials. |
| `requestEndDateTime` | `?\DateTime` | Query, Optional | The requested end date for filtering.<br><br />Default: **today’s date** |
| `requestHideCanceledClasses` | `?bool` | Query, Optional | When `true`, canceled classes are removed from the response.<br /><br>When `false`, canceled classes are included in the response.<br /><br>Default: **false** |
| `requestLastModifiedDate` | `?\DateTime` | Query, Optional | When included in the request, only records modified on or after the `LastModifiedDate` specified are included in the response. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationIds` | `?(int[])` | Query, Optional | A list of location IDs on which to base the search. |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestProgramIds` | `?(int[])` | Query, Optional | A list of program IDs on which to base the search. |
| `requestSchedulingWindow` | `?bool` | Query, Optional | When `true`, classes outside scheduling window are removed from the response.<br /><br>When `false`, classes are included in the response, regardless of the scheduling window.<br /><br>Default: **false** |
| `requestSemesterIds` | `?(int[])` | Query, Optional | A list of semester IDs on which to base the search. |
| `requestSessionTypeIds` | `?(int[])` | Query, Optional | A list of session type IDs on which to base the search. |
| `requestStaffIds` | `?(int[])` | Query, Optional | The requested IDs of the teaching staff members. |
| `requestStartDateTime` | `?\DateTime` | Query, Optional | The requested start date for filtering. This also determines what you will see for the ‘BookingWindow’ StartDateTime in the response. For example, if you pass a StartDateTime that is on OR before the BookingWindow ‘Open’ days of the class, you will retrieve the actual ‘StartDateTime’ for the Booking Window. If you pass a StartDateTime that is after the BookingWindow ‘date’, then you will receive results based on that start date. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClassControllerGetClassesResponse`](../../doc/models/mindbody-public-api-dto-models-v6-class-controller-get-classes-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $mClassController->classGetClasses($version, $siteId);
```


# Class Get Class Descriptions

To find class descriptions associated with **scheduled classes**, pass `StaffId`, `StartClassDateTime`, `EndClassDateTime`, or `LocationId` in the request.

```php
function classGetClassDescriptions(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?int $requestClassDescriptionId = null,
    ?\DateTime $requestEndClassDateTime = null,
    ?int $requestLimit = null,
    ?int $requestLocationId = null,
    ?int $requestOffset = null,
    ?array $requestProgramIds = null,
    ?int $requestStaffId = null,
    ?\DateTime $requestStartClassDateTime = null
): MindbodyPublicApiDtoModelsV6ClassControllerGetClassDescriptionsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestClassDescriptionId` | `?int` | Query, Optional | The ID of the requested client. |
| `requestEndClassDateTime` | `?\DateTime` | Query, Optional | Filters the results to class descriptions for scheduled classes that happen before the given date and time. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationId` | `?int` | Query, Optional | Filters results to classes descriptions for schedule classes as the given location. |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestProgramIds` | `?(int[])` | Query, Optional | A list of requested program IDs. |
| `requestStaffId` | `?int` | Query, Optional | Filters results to class descriptions for scheduled classes taught by the given staff member. |
| `requestStartClassDateTime` | `?\DateTime` | Query, Optional | Filters the results to class descriptions for scheduled classes that happen on or after the given date and time. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClassControllerGetClassDescriptionsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-class-controller-get-class-descriptions-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $mClassController->classGetClassDescriptions($version, $siteId);
```


# Class Get Class Visits

Returns a list of visits that contain information for a specified class. On success, this request returns the class object in the response with a list of visits.

```php
function classGetClassVisits(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?int $requestClassID = null,
    ?\DateTime $requestLastModifiedDate = null
): MindbodyPublicApiDtoModelsV6ClassControllerGetClassVisitsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestClassID` | `?int` | Query, Optional | The class ID. |
| `requestLastModifiedDate` | `?\DateTime` | Query, Optional | When included in the request, only records modified on or after the `LastModifiedDate` specified are included in the response. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClassControllerGetClassVisitsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-class-controller-get-class-visits-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $mClassController->classGetClassVisits($version, $siteId);
```


# Class Remove Client From Class

Remove a client from a class.

```php
function classRemoveClientFromClass(
    string $version,
    MindbodyPublicApiDtoModelsV6ClassControllerRemoveClientFromClassRequest $request,
    string $siteId,
    ?string $authorization = null
): MindbodyPublicApiDtoModelsV6ClassControllerRemoveClientFromClassResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6ClassControllerRemoveClientFromClassRequest`](../../doc/models/mindbody-public-api-dto-models-v6-class-controller-remove-client-from-class-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClassControllerRemoveClientFromClassResponse`](../../doc/models/mindbody-public-api-dto-models-v6-class-controller-remove-client-from-class-response.md)

## Example Usage

```php
$version = '6';
$request_clientId = 'ClientId0';
$request_classId = 90;
$request = new Models\MindbodyPublicApiDtoModelsV6ClassControllerRemoveClientFromClassRequest(
    $request_clientId,
    $request_classId
);
$siteId = '-99';

$result = $mClassController->classRemoveClientFromClass($version, $request, $siteId);
```


# Class Add Class Schedule

This endpoint adds a class schedule. For a single day schedule, the EndDate parameter can be omitted.

```php
function classAddClassSchedule(
    string $version,
    MindbodyPublicApiDtoModelsV6AddClassEnrollmentScheduleRequest $request,
    string $siteId,
    ?string $authorization = null
): array
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6AddClassEnrollmentScheduleRequest`](../../doc/models/mindbody-public-api-dto-models-v6-add-class-enrollment-schedule-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

`array`

## Example Usage

```php
$version = '6';
$request = new Models\MindbodyPublicApiDtoModelsV6AddClassEnrollmentScheduleRequest();
$siteId = '-99';

$result = $mClassController->classAddClassSchedule($version, $request, $siteId);
```


# Class Update Class Schedule

```php
function classUpdateClassSchedule(
    string $version,
    MindbodyPublicApiDtoModelsV6UpdateClassEnrollmentScheduleRequest $request,
    string $siteId,
    ?string $authorization = null
): array
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6UpdateClassEnrollmentScheduleRequest`](../../doc/models/mindbody-public-api-dto-models-v6-update-class-enrollment-schedule-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

`array`

## Example Usage

```php
$version = '6';
$request = new Models\MindbodyPublicApiDtoModelsV6UpdateClassEnrollmentScheduleRequest();
$siteId = '-99';

$result = $mClassController->classUpdateClassSchedule($version, $request, $siteId);
```


# Class Add Client to Class

This endpoint adds a client to a class or to a class waiting list. To prevent overbooking a class or booking outside the schedule windows set forth by the business, it is necessary to first check the capacity level of the class (‘MaxCapacity’ and 'TotalBooked’) and the 'IsAvailable’ parameter by running the GetClasses REQUEST. It is helpful to use this endpoint in the following situations:

* Use after calling `GET Clients` and `GET Classes` so that you are sure which client to book in which class.
* If adding a client to a class from a waiting list, use this call after you call `GET WaitlistEntries` and determine the ID of the waiting list from which you are moving the client.
* If adding a client to a class and using a pricing option that the client has already purchased, use this call after you call `GET ClientServices` to determine the ID of the pricing option that the client wants to use.

If you add a client to a class and the client purchases a new pricing option, use `GET Services`, `GET Classes`, and then `POST CheckoutShoppingCart` in place of this call.

This endpoint also supports cross-regional class bookings. If you want to perform a cross-regional class booking, set `CrossRegionalBooking` to `true`. This endpoint does not support adding a user to a waiting list using a cross-regional client pricing option(service). Cross-regional booking workflows do not support client service scheduling restrictions.

When performing a cross-regional class booking, this endpoint loops through the first ten sites that the client is associated with, looks for client pricing options at each of those sites, and then uses the oldest client pricing option found.It is important to note that this endpoint only loops through a maximum of ten associated client sites. If a `ClientID` is associated with more than ten sites in an organization, this endpoint only loops through the first ten.If you know that a client has a client service at another site, you can specify that site using the `CrossRegionalBookingClientServiceSiteId` query parameter.

If you perform a cross-regional booking, two additional fields are included in the `SessionType` object of the response:

* `SiteID`, which specifies where the client service is coming from
* `CrossRegionalBookingPerformed`, a Boolean field that is set to `true`

As a prerequisite to using this endpoint, your `SourceName` must have been granted access to the organization to which the site belongs.

```php
function classAddClientToClass(
    string $version,
    MindbodyPublicApiDtoModelsV6ClassControllerAddClientToClassRequest $request,
    string $siteId,
    ?string $authorization = null
): MindbodyPublicApiDtoModelsV6ClassControllerAddClientToClassResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6ClassControllerAddClientToClassRequest`](../../doc/models/mindbody-public-api-dto-models-v6-class-controller-add-client-to-class-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClassControllerAddClientToClassResponse`](../../doc/models/mindbody-public-api-dto-models-v6-class-controller-add-client-to-class-response.md)

## Example Usage

```php
$version = '6';
$request_clientId = 'ClientId0';
$request_classId = 90;
$request = new Models\MindbodyPublicApiDtoModelsV6ClassControllerAddClientToClassRequest(
    $request_clientId,
    $request_classId
);
$siteId = '-99';

$result = $mClassController->classAddClientToClass($version, $request, $siteId);
```


# Class Get Class Schedules

Get class schedules.

```php
function classGetClassSchedules(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?array $requestClassScheduleIds = null,
    ?\DateTime $requestEndDate = null,
    ?int $requestLimit = null,
    ?array $requestLocationIds = null,
    ?int $requestOffset = null,
    ?array $requestProgramIds = null,
    ?array $requestSessionTypeIds = null,
    ?array $requestStaffIds = null,
    ?\DateTime $requestStartDate = null
): MindbodyPublicApiDtoModelsV6ClassControllerGetClassSchedulesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestClassScheduleIds` | `?(int[])` | Query, Optional | The class schedule IDs.<br><br />Default: **all** |
| `requestEndDate` | `?\DateTime` | Query, Optional | The end date of the range. Return any active enrollments that occur on or before this day.<br><br />Default: **StartDate** |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationIds` | `?(int[])` | Query, Optional | The location IDs.<br><br />Default: **all** |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestProgramIds` | `?(int[])` | Query, Optional | The program IDs.<br><br />Default: **all** |
| `requestSessionTypeIds` | `?(int[])` | Query, Optional | The session type IDs.<br><br />Default: **all** |
| `requestStaffIds` | `?(int[])` | Query, Optional | The staff IDs.<br><br />Default: **all** |
| `requestStartDate` | `?\DateTime` | Query, Optional | The start date of the range. Return any active enrollments that occur on or after this day.<br><br />Default: **today’s date** |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClassControllerGetClassSchedulesResponse`](../../doc/models/mindbody-public-api-dto-models-v6-class-controller-get-class-schedules-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $mClassController->classGetClassSchedules($version, $siteId);
```


# Class Get Waitlist Entries

Returns a list of waiting list entries for a specified class schedule or class. The request requires staff credentials and either a class schedule ID or class ID.

```php
function classGetWaitlistEntries(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?array $requestClassIds = null,
    ?array $requestClassScheduleIds = null,
    ?array $requestClientIds = null,
    ?bool $requestHidePastEntries = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null,
    ?array $requestWaitlistEntryIds = null
): MindbodyPublicApiDtoModelsV6ClassControllerGetWaitlistEntriesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestClassIds` | `?(int[])` | Query, Optional | The requested class IDs. If a class ID is present, the request automatically disregards any class schedule IDs in the request. <br /><br>Either `ClassScheduleIds`, `ClientIds`, `WaitlistEntryIds`, or `ClassIds` is required; the others become optional.<br /><br>Default: **all ClassIds** |
| `requestClassScheduleIds` | `?(int[])` | Query, Optional | The requested class schedule IDs. If a class ID is present, the request automatically disregards any class schedule IDs in the request.<br /><br>Either `ClassScheduleIds`, `ClientIds`, `WaitlistEntryIds`, or `ClassIds` is required; the others become optional.<br /><br>Default: **all ClassScheduleIds** |
| `requestClientIds` | `?(string[])` | Query, Optional | The requested client IDs.<br /><br>Either `ClassScheduleIds`, `ClientIds`, `WaitlistEntryIds`, or `ClassIds` is required; the others become optional.<br /><br>Default: **all ClientIds** |
| `requestHidePastEntries` | `?bool` | Query, Optional | When `true`, indicates that past waiting list entries are hidden from clients.<br /><br>When `false`, indicates that past entries are not hidden from clients.<br /><br>Default: **false** |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestWaitlistEntryIds` | `?(int[])` | Query, Optional | The requested waiting list entry IDs.<br /><br>Either `ClassScheduleIds`, `ClientIds`, `WaitlistEntryIds`, or `ClassIds` is required; the others become optional.<br /><br>Default: **all WaitlistEntryIds** |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClassControllerGetWaitlistEntriesResponse`](../../doc/models/mindbody-public-api-dto-models-v6-class-controller-get-waitlist-entries-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $mClassController->classGetWaitlistEntries($version, $siteId);
```


# Class Remove From Waitlist

This endpoint does not return a response. If a call to this endpoint results in a 200 OK HTTP status code, then the call was successful.

```php
function classRemoveFromWaitlist(
    string $version,
    array $requestWaitlistEntryIds,
    string $siteId,
    ?string $authorization = null
): array
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestWaitlistEntryIds` | `int[]` | Query, Required | A list of `WaitlistEntryIds` to remove from the waiting list. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

`array`

## Example Usage

```php
$version = '6';
$requestWaitlistEntryIds = [138, 139];
$siteId = '-99';

$result = $mClassController->classRemoveFromWaitlist($version, $requestWaitlistEntryIds, $siteId);
```


# Class Substitute Class Teacher

Substitute a class teacher.

```php
function classSubstituteClassTeacher(
    string $version,
    MindbodyPublicApiDtoModelsV6ClassControllerSubstituteClassTeacherRequest $request,
    string $siteId,
    ?string $authorization = null
): MindbodyPublicApiDtoModelsV6ClassControllerSubstituteClassTeacherResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6ClassControllerSubstituteClassTeacherRequest`](../../doc/models/mindbody-public-api-dto-models-v6-class-controller-substitute-class-teacher-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClassControllerSubstituteClassTeacherResponse`](../../doc/models/mindbody-public-api-dto-models-v6-class-controller-substitute-class-teacher-response.md)

## Example Usage

```php
$version = '6';
$request_classId = 90;
$request_staffId = 188;
$request = new Models\MindbodyPublicApiDtoModelsV6ClassControllerSubstituteClassTeacherRequest(
    $request_classId,
    $request_staffId
);
$siteId = '-99';

$result = $mClassController->classSubstituteClassTeacher($version, $request, $siteId);
```


# Class Remove Clients From Classes

This endpoint can be utilized for removing multiple clients from multiple classes in one request.

```php
function classRemoveClientsFromClasses(
    string $version,
    MindbodyPublicApiDtoModelsV6ClassControllerRemoveClientsFromClassesRequest $request,
    string $siteId,
    ?string $authorization = null
): MindbodyPublicApiDtoModelsV6ClassControllerRemoveClientsFromClassesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6ClassControllerRemoveClientsFromClassesRequest`](../../doc/models/mindbody-public-api-dto-models-v6-class-controller-remove-clients-from-classes-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClassControllerRemoveClientsFromClassesResponse`](../../doc/models/mindbody-public-api-dto-models-v6-class-controller-remove-clients-from-classes-response.md)

## Example Usage

```php
$version = '6';
$request = new Models\MindbodyPublicApiDtoModelsV6ClassControllerRemoveClientsFromClassesRequest();
$siteId = '-99';

$result = $mClassController->classRemoveClientsFromClasses($version, $request, $siteId);
```


# Class Get Courses

This endpoint will provide all the data related to courses depending on the access level.<br />
Note: The Authorization is an optional header.If Authorization header is not passed, the response will be masked else full response will be provided.

```php
function classGetCourses(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?array $getCoursesRequestCourseIDs = null,
    ?\DateTime $getCoursesRequestEndDate = null,
    ?int $getCoursesRequestLimit = null,
    ?array $getCoursesRequestLocationIDs = null,
    ?int $getCoursesRequestOffset = null,
    ?array $getCoursesRequestProgramIDs = null,
    ?array $getCoursesRequestSemesterIDs = null,
    ?array $getCoursesRequestStaffIDs = null,
    ?\DateTime $getCoursesRequestStartDate = null
): MindbodyPublicApiDtoModelsV6ClassControllerGetCoursesReponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `getCoursesRequestCourseIDs` | `?(int[])` | Query, Optional | Return only courses that are available for the specified CourseIds. |
| `getCoursesRequestEndDate` | `?\DateTime` | Query, Optional | The end date range. Any active courses that are on or before this day.<br><br />(optional) Defaults to StartDate. |
| `getCoursesRequestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `getCoursesRequestLocationIDs` | `?(int[])` | Query, Optional | Return only courses that are available for the specified LocationIds. |
| `getCoursesRequestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `getCoursesRequestProgramIDs` | `?(int[])` | Query, Optional | Return only courses that are available for the specified ProgramIds. |
| `getCoursesRequestSemesterIDs` | `?(int[])` | Query, Optional | Return only courses that are available for the specified SemesterIds. |
| `getCoursesRequestStaffIDs` | `?(int[])` | Query, Optional | Return only courses that are available for the specified StaffIds. |
| `getCoursesRequestStartDate` | `?\DateTime` | Query, Optional | The start date range. Any active courses that are on or after this day.<br><br />(optional) Defaults to today. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClassControllerGetCoursesReponse`](../../doc/models/mindbody-public-api-dto-models-v6-class-controller-get-courses-reponse.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $mClassController->classGetCourses($version, $siteId);
```


# Class Cancel Single Class

This endpoint will cancel a single class from studio.

```php
function classCancelSingleClass(
    string $version,
    MindbodyPublicApiDtoModelsV6ClassControllerCancelSingleClassRequest $request,
    string $siteId,
    ?string $authorization = null
): MindbodyPublicApiDtoModelsV6ClassControllerCancelSingleClassResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6ClassControllerCancelSingleClassRequest`](../../doc/models/mindbody-public-api-dto-models-v6-class-controller-cancel-single-class-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClassControllerCancelSingleClassResponse`](../../doc/models/mindbody-public-api-dto-models-v6-class-controller-cancel-single-class-response.md)

## Example Usage

```php
$version = '6';
$request = new Models\MindbodyPublicApiDtoModelsV6ClassControllerCancelSingleClassRequest();
$siteId = '-99';

$result = $mClassController->classCancelSingleClass($version, $request, $siteId);
```


# Class Get Semesters Async

This endpoint retrieves the business class semesters.

```php
function classGetSemestersAsync(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?bool $requestActive = null,
    ?\DateTime $requestEndDate = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null,
    ?array $requestSemesterIDs = null,
    ?\DateTime $requestStartDate = null
): MindbodyPublicApiDtoModelsV6ClassControllerGetSemestersResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestActive` | `?bool` | Query, Optional | When true, the response only contains semesters which are activated. When false, only deactivated semesters are returned.<br>Default: **All semesters** |
| `requestEndDate` | `?\DateTime` | Query, Optional | The end date for the range. All semesters that are on or before this day.<br>Default: **StartDate** |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestSemesterIDs` | `?(int[])` | Query, Optional | The requested semester IDs. |
| `requestStartDate` | `?\DateTime` | Query, Optional | The start date for the range. All semesters that are on or after this day.<br>Default: **today’s date** |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClassControllerGetSemestersResponse`](../../doc/models/mindbody-public-api-dto-models-v6-class-controller-get-semesters-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $mClassController->classGetSemestersAsync($version, $siteId);
```

