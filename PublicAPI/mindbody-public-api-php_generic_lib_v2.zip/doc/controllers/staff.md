# Staff

```php
$staffController = $client->getStaffController();
```

## Class Name

`StaffController`

## Methods

* [Staff Get Staff](../../doc/controllers/staff.md#staff-get-staff)
* [Staff Get Staff Permissions](../../doc/controllers/staff.md#staff-get-staff-permissions)
* [Staff Get Staff Image URL](../../doc/controllers/staff.md#staff-get-staff-image-url)
* [Staff Update Staff Permissions](../../doc/controllers/staff.md#staff-update-staff-permissions)
* [Staff Add Staff](../../doc/controllers/staff.md#staff-add-staff)
* [Staff Update Staff](../../doc/controllers/staff.md#staff-update-staff)
* [Staff Add Staff Availability](../../doc/controllers/staff.md#staff-add-staff-availability)
* [Staff Get Staff Session Types](../../doc/controllers/staff.md#staff-get-staff-session-types)
* [Staff Assign Staff Session Type](../../doc/controllers/staff.md#staff-assign-staff-session-type)
* [Staff Get Sales Reps](../../doc/controllers/staff.md#staff-get-sales-reps)


# Staff Get Staff

When a user token is not passed with the request or the passed user token has insufficient viewing permissions, only the following staff data is returned in the response:

* FirstName
* LastName
* Id
* Bio
* DisplayName
* ImageUrl
* EmpID

```php
function staffGetStaff(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?array $requestFilters = null,
    ?int $requestLimit = null,
    ?int $requestLocationId = null,
    ?int $requestOffset = null,
    ?int $requestSessionTypeId = null,
    ?array $requestStaffIds = null,
    ?\DateTime $requestStartDateTime = null
): MindbodyPublicApiDtoModelsV6StaffControllerGetStaffResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestFilters` | `?(string[])` | Query, Optional | Filters to apply to the search. Possible values are:<br><br>* StaffViewable<br>* AppointmentInstructor<br>* ClassInstructor<br>* Male<br>* Female |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationId` | `?int` | Query, Optional | Return only staff members that are available at the specified location. You must supply a valid `SessionTypeID` and `StartDateTime` to use this parameter. |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestSessionTypeId` | `?int` | Query, Optional | Return only staff members that are available for the specified session type. You must supply a valid `StartDateTime` and `LocationID` to use this parameter. |
| `requestStaffIds` | `?(int[])` | Query, Optional | A list of the requested staff IDs. |
| `requestStartDateTime` | `?\DateTime` | Query, Optional | Return only staff members that are available at the specified date and time. You must supply a valid `SessionTypeID` and `LocationID` to use this parameter. |

## Response Type

[`MindbodyPublicApiDtoModelsV6StaffControllerGetStaffResponse`](../../doc/models/mindbody-public-api-dto-models-v6-staff-controller-get-staff-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $staffController->staffGetStaff($version, $siteId);
```


# Staff Get Staff Permissions

Get configured staff permissions for a staff member.

```php
function staffGetStaffPermissions(
    string $version,
    int $requestStaffId,
    string $siteId,
    ?string $authorization = null
): MindbodyPublicApiDtoModelsV6StaffControllerGetStaffPermissionsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestStaffId` | `int` | Query, Required | The ID of the staff member whose permissions you want to return. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6StaffControllerGetStaffPermissionsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-staff-controller-get-staff-permissions-response.md)

## Example Usage

```php
$version = '6';
$requestStaffId = 180;
$siteId = '-99';

$result = $staffController->staffGetStaffPermissions($version, $requestStaffId, $siteId);
```


# Staff Get Staff Image URL

This endpoint can be utilized to retrieve image urls for requested staff member.

```php
function staffGetStaffImageURL(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?int $requestStaffId = null
): MindbodyPublicApiDtoModelsV6StaffControllerGetStaffImageURLResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestStaffId` | `?int` | Query, Optional | The ID of the staff member whose image URL details you want to retrieve. |

## Response Type

[`MindbodyPublicApiDtoModelsV6StaffControllerGetStaffImageURLResponse`](../../doc/models/mindbody-public-api-dto-models-v6-staff-controller-get-staff-image-url-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $staffController->staffGetStaffImageURL($version, $siteId);
```


# Staff Update Staff Permissions

Assigns a permission group to a staff member. A staff user token must be included with staff assigned the ManageStaffPayRates permission.

```php
function staffUpdateStaffPermissions(
    string $version,
    MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffPermissionsRequest $request,
    string $siteId,
    ?string $authorization = null
): MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffPermissionsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffPermissionsRequest`](../../doc/models/mindbody-public-api-dto-models-v6-staff-controller-update-staff-permissions-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffPermissionsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-staff-controller-update-staff-permissions-response.md)

## Example Usage

```php
$version = '6';
$request_staffId = 188;
$request_permissionGroupName = 'PermissionGroupName8';
$request = new Models\MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffPermissionsRequest(
    $request_staffId,
    $request_permissionGroupName
);
$siteId = '-99';

$result = $staffController->staffUpdateStaffPermissions($version, $request, $siteId);
```


# Staff Add Staff

Creates a new staff member record at the specified business. The `FirstName` and `LastName` parameters are always required for this request.

```php
function staffAddStaff(
    string $version,
    MindbodyPublicApiDtoModelsV6StaffControllerAddStaffRequest $request,
    string $siteId,
    ?string $authorization = null
): MindbodyPublicApiDtoModelsV6StaffControllerAddStaffResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6StaffControllerAddStaffRequest`](../../doc/models/mindbody-public-api-dto-models-v6-staff-controller-add-staff-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6StaffControllerAddStaffResponse`](../../doc/models/mindbody-public-api-dto-models-v6-staff-controller-add-staff-response.md)

## Example Usage

```php
$version = '6';
$request_firstName = 'FirstName8';
$request_lastName = 'LastName8';
$request = new Models\MindbodyPublicApiDtoModelsV6StaffControllerAddStaffRequest(
    $request_firstName,
    $request_lastName
);
$siteId = '-99';

$result = $staffController->staffAddStaff($version, $request, $siteId);
```


# Staff Update Staff

Updates an existing staff member record at the specified business. The ID is a required parameters for this request.

```php
function staffUpdateStaff(
    string $version,
    MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffRequest $request,
    string $siteId,
    ?string $authorization = null
): MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffRequest`](../../doc/models/mindbody-public-api-dto-models-v6-staff-controller-update-staff-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffResponse`](../../doc/models/mindbody-public-api-dto-models-v6-staff-controller-update-staff-response.md)

## Example Usage

```php
$version = '6';
$request_iD = 142;
$request = new Models\MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffRequest(
    $request_iD
);
$siteId = '-99';

$result = $staffController->staffUpdateStaff($version, $request, $siteId);
```


# Staff Add Staff Availability

Enables to add staff availability or unavailability for a given staff member.

```php
function staffAddStaffAvailability(
    string $version,
    MindbodyPublicApiDtoModelsV6StaffControllerAddStaffAvailabilityRequest $request,
    string $siteId,
    ?string $authorization = null
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6StaffControllerAddStaffAvailabilityRequest`](../../doc/models/mindbody-public-api-dto-models-v6-staff-controller-add-staff-availability-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

`void`

## Example Usage

```php
$version = '6';
$request_staffId = 188;
$request_isAvailability = false;
$request_daysOfWeek = ['DaysOfWeek7'];
$request_startTime = 'StartTime4';
$request_endTime = 'EndTime0';
$request_startDate = 'StartDate0';
$request_endDate = 'EndDate6';
$request = new Models\MindbodyPublicApiDtoModelsV6StaffControllerAddStaffAvailabilityRequest(
    $request_staffId,
    $request_isAvailability,
    $request_daysOfWeek,
    $request_startTime,
    $request_endTime,
    $request_startDate,
    $request_endDate
);
$siteId = '-99';

$staffController->staffAddStaffAvailability($version, $request, $siteId);
```


# Staff Get Staff Session Types

Gets a list of active session types for a specific staff member. A staff user token must be included with staff assigned the ManageStaffPayRates permission.

```php
function staffGetStaffSessionTypes(
    string $version,
    int $requestStaffId,
    string $siteId,
    ?string $authorization = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null,
    ?bool $requestOnlineOnly = null,
    ?array $requestProgramIds = null
): MindbodyPublicApiDtoModelsV6StaffControllerGetStaffSessionTypesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestStaffId` | `int` | Query, Required | The ID of the staff member whose session types you want to return. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestOnlineOnly` | `?bool` | Query, Optional | When `true`, indicates that only the session types that can be booked online should be returned.<br>Default: **false** |
| `requestProgramIds` | `?(int[])` | Query, Optional | Filters results to session types that belong to one of the given program IDs. If omitted, all program IDs return. |

## Response Type

[`MindbodyPublicApiDtoModelsV6StaffControllerGetStaffSessionTypesResponse`](../../doc/models/mindbody-public-api-dto-models-v6-staff-controller-get-staff-session-types-response.md)

## Example Usage

```php
$version = '6';
$requestStaffId = 180;
$siteId = '-99';

$result = $staffController->staffGetStaffSessionTypes($version, $requestStaffId, $siteId);
```


# Staff Assign Staff Session Type

Assigns a staff member to an appointment session type with staff specific properties such as time length and pay rate. A staff user token must be included with staff assigned the ManageStaffPayRates permission.

```php
function staffAssignStaffSessionType(
    string $version,
    MindbodyPublicApiDtoModelsV6StaffControllerAssignStaffSessionTypeRequest $request,
    string $siteId,
    ?string $authorization = null
): MindbodyPublicApiDtoModelsV6StaffControllerAssignStaffSessionTypeResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6StaffControllerAssignStaffSessionTypeRequest`](../../doc/models/mindbody-public-api-dto-models-v6-staff-controller-assign-staff-session-type-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6StaffControllerAssignStaffSessionTypeResponse`](../../doc/models/mindbody-public-api-dto-models-v6-staff-controller-assign-staff-session-type-response.md)

## Example Usage

```php
$version = '6';
$request_staffId = 188;
$request_sessionTypeId = 82;
$request_active = false;
$request = new Models\MindbodyPublicApiDtoModelsV6StaffControllerAssignStaffSessionTypeRequest(
    $request_staffId,
    $request_sessionTypeId,
    $request_active
);
$siteId = '-99';

$result = $staffController->staffAssignStaffSessionType($version, $request, $siteId);
```


# Staff Get Sales Reps

This endpoint returns the basic details of the staffs that are marked as sales reps.

```php
function staffGetSalesReps(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?bool $requestActiveOnly = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null,
    ?array $requestSalesRepNumbers = null
): MindbodyPublicApiDtoModelsV6StaffControllerGetSalesRepsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestActiveOnly` | `?bool` | Query, Optional | When `true`, will return only active reps data.<br>Default : **false** |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestSalesRepNumbers` | `?(int[])` | Query, Optional | This is the list of the sales rep numbers for which the salesrep data will be fetched. |

## Response Type

[`MindbodyPublicApiDtoModelsV6StaffControllerGetSalesRepsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-staff-controller-get-sales-reps-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $staffController->staffGetSalesReps($version, $siteId);
```

