
# Mindbody Public Api Dto Models V6 Sale Controller Update Sale Date Request

Update Sales Date Request Model

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerUpdateSaleDateRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `saleID` | `?int` | Optional | The Sale ID for which saleDate needs to be updated. This is the `Sale[].Id` returned from GET Sales. | getSaleID(): ?int | setSaleID(?int saleID): void |
| `saleDate` | `?\DateTime` | Optional | The sale date which needs to be modified. | getSaleDate(): ?\DateTime | setSaleDate(?\DateTime saleDate): void |

## Example (as JSON)

```json
{
  "SaleID": null,
  "SaleDate": null
}
```

