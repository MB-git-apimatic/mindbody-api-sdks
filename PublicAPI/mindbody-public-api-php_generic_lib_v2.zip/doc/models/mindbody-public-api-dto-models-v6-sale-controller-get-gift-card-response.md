
# Mindbody Public Api Dto Models V6 Sale Controller Get Gift Card Response

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerGetGiftCardResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | Contains information about the pagination to use. | getPaginationResponse(): ?MindbodyPublicApiDtoModelsV6PaginationResponse | setPaginationResponse(?MindbodyPublicApiDtoModelsV6PaginationResponse paginationResponse): void |
| `giftCards` | [`?(MindbodyPublicApiDtoModelsV6GiftCard[])`](../../doc/models/mindbody-public-api-dto-models-v6-gift-card.md) | Optional | Contains information about the gift cards. | getGiftCards(): ?array | setGiftCards(?array giftCards): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "GiftCards": null
}
```

