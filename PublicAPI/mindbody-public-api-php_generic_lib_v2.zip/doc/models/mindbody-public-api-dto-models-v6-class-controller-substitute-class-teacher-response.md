
# Mindbody Public Api Dto Models V6 Class Controller Substitute Class Teacher Response

## Structure

`MindbodyPublicApiDtoModelsV6ClassControllerSubstituteClassTeacherResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `class` | [`?MindbodyPublicApiDtoModelsV6SubstituteTeacherClass`](../../doc/models/mindbody-public-api-dto-models-v6-substitute-teacher-class.md) | Optional | Represents a single class instance. Used in SubstituteClassTeacher endpoint. | getClass(): ?MindbodyPublicApiDtoModelsV6SubstituteTeacherClass | setClass(?MindbodyPublicApiDtoModelsV6SubstituteTeacherClass class): void |

## Example (as JSON)

```json
{
  "Class": null
}
```

