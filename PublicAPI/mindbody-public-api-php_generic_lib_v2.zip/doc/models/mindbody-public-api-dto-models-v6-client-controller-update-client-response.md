
# Mindbody Public Api Dto Models V6 Client Controller Update Client Response

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `client` | [`?MindbodyPublicApiDtoModelsV6ClientWithSuspensionInfo`](../../doc/models/mindbody-public-api-dto-models-v6-client-with-suspension-info.md) | Optional | A Client DTO with Suspension Informatoin | getClient(): ?MindbodyPublicApiDtoModelsV6ClientWithSuspensionInfo | setClient(?MindbodyPublicApiDtoModelsV6ClientWithSuspensionInfo client): void |

## Example (as JSON)

```json
{
  "Client": null
}
```

