
# Mindbody Public Api Dto Models V6 Client Controller Upload Client Photo Request

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerUploadClientPhotoRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `bytes` | `string` | Required | A Base64-encoded string representation of the image’s byte array. | getBytes(): string | setBytes(string bytes): void |
| `clientId` | `string` | Required | The RSSID of the client for whom the photo is to be uploaded. | getClientId(): string | setClientId(string clientId): void |

## Example (as JSON)

```json
{
  "Bytes": "Bytes0",
  "ClientId": "ClientId6"
}
```

