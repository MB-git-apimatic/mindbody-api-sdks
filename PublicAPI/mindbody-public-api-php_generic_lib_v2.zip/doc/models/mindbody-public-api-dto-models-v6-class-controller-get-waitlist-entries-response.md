
# Mindbody Public Api Dto Models V6 Class Controller Get Waitlist Entries Response

## Structure

`MindbodyPublicApiDtoModelsV6ClassControllerGetWaitlistEntriesResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | Contains information about the pagination to use. | getPaginationResponse(): ?MindbodyPublicApiDtoModelsV6PaginationResponse | setPaginationResponse(?MindbodyPublicApiDtoModelsV6PaginationResponse paginationResponse): void |
| `waitlistEntries` | [`?(MindbodyPublicApiDtoModelsV6WaitlistEntry[])`](../../doc/models/mindbody-public-api-dto-models-v6-waitlist-entry.md) | Optional | Contains information about the waiting list entries. | getWaitlistEntries(): ?array | setWaitlistEntries(?array waitlistEntries): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "WaitlistEntries": null
}
```

