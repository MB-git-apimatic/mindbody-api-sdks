
# Mindbody Public Api Dto Models V6 Applicable Item

Item that will be applied to a promo code

## Structure

`MindbodyPublicApiDtoModelsV6ApplicableItem`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `type` | `?string` | Optional | Type of a promo code | getType(): ?string | setType(?string type): void |
| `id` | `?int` | Optional | ID of the item | getId(): ?int | setId(?int id): void |
| `name` | `?string` | Optional | Name of the item | getName(): ?string | setName(?string name): void |

## Example (as JSON)

```json
{
  "Type": null,
  "Id": null,
  "Name": null
}
```

