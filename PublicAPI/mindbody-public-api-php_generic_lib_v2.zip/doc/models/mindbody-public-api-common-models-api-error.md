
# Mindbody Public Api Common Models Api Error

## Structure

`MindbodyPublicApiCommonModelsApiError`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `message` | `?string` | Optional | - | getMessage(): ?string | setMessage(?string message): void |
| `code` | `?string` | Optional | - | getCode(): ?string | setCode(?string code): void |

## Example (as JSON)

```json
{
  "Message": null,
  "Code": null
}
```

