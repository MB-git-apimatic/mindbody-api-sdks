
# Mindbody Public Api Dto Models V6 Appointment Controller Add Availabilities Response

## Structure

`MindbodyPublicApiDtoModelsV6AppointmentControllerAddAvailabilitiesResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `staffMembers` | [`?(MindbodyPublicApiCommonModelsStaff[])`](../../doc/models/mindbody-public-api-common-models-staff.md) | Optional | - | getStaffMembers(): ?array | setStaffMembers(?array staffMembers): void |
| `errors` | [`?(MindbodyPublicApiCommonModelsApiError[])`](../../doc/models/mindbody-public-api-common-models-api-error.md) | Optional | - | getErrors(): ?array | setErrors(?array errors): void |

## Example (as JSON)

```json
{
  "StaffMembers": null,
  "Errors": null
}
```

