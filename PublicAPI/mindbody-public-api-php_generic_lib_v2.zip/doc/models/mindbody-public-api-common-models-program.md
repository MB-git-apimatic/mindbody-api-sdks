
# Mindbody Public Api Common Models Program

## Structure

`MindbodyPublicApiCommonModelsProgram`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `cancelOffset` | `?int` | Optional | - | getCancelOffset(): ?int | setCancelOffset(?int cancelOffset): void |
| `id` | `?int` | Optional | - | getId(): ?int | setId(?int id): void |
| `name` | `?string` | Optional | - | getName(): ?string | setName(?string name): void |
| `scheduleType` | [`?string (ScheduleType2Enum)`](../../doc/models/schedule-type-2-enum.md) | Optional | - | getScheduleType(): ?string | setScheduleType(?string scheduleType): void |
| `contentFormat` | [`?string (ContentFormatEnum)`](../../doc/models/content-format-enum.md) | Optional | - | getContentFormat(): ?string | setContentFormat(?string contentFormat): void |
| `onlineBookingDisabled` | `?bool` | Optional | - | getOnlineBookingDisabled(): ?bool | setOnlineBookingDisabled(?bool onlineBookingDisabled): void |

## Example (as JSON)

```json
{
  "CancelOffset": null,
  "Id": null,
  "Name": null,
  "ScheduleType": null,
  "ContentFormat": null,
  "OnlineBookingDisabled": null
}
```

