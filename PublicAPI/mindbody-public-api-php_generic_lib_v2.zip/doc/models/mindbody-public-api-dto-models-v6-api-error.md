
# Mindbody Public Api Dto Models V6 Api Error

## Structure

`MindbodyPublicApiDtoModelsV6ApiError`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `message` | `?string` | Optional | - | getMessage(): ?string | setMessage(?string message): void |
| `code` | `?string` | Optional | - | getCode(): ?string | setCode(?string code): void |

## Example (as JSON)

```json
{
  "Message": null,
  "Code": null
}
```

