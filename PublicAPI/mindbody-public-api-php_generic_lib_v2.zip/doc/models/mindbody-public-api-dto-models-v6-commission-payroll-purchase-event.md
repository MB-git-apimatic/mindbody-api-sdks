
# Mindbody Public Api Dto Models V6 Commission Payroll Purchase Event

## Structure

`MindbodyPublicApiDtoModelsV6CommissionPayrollPurchaseEvent`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `staffId` | `?int` | Optional | The ID of the staff member who earned commissions. | getStaffId(): ?int | setStaffId(?int staffId): void |
| `saleDateTime` | `?\DateTime` | Optional | The date and time when the sale occurred. | getSaleDateTime(): ?\DateTime | setSaleDateTime(?\DateTime saleDateTime): void |
| `saleId` | `?int` | Optional | The sale’s ID. | getSaleId(): ?int | setSaleId(?int saleId): void |
| `saleType` | `?string` | Optional | The Sales type. When this is "Purchase" indicates that this sale paid commission to a staff. When this is "Return" | getSaleType(): ?string | setSaleType(?string saleType): void |
| `productId` | `?int` | Optional | The product ID of the item for which the staff earned commissions. | getProductId(): ?int | setProductId(?int productId): void |
| `earningsDetails` | [`?(MindbodyPublicApiDtoModelsV6CommissionDetail[])`](../../doc/models/mindbody-public-api-dto-models-v6-commission-detail.md) | Optional | Contains information about which commissions the staff earned for this item. | getEarningsDetails(): ?array | setEarningsDetails(?array earningsDetails): void |
| `earnings` | `?float` | Optional | The total commissions earned by the staff for this item. | getEarnings(): ?float | setEarnings(?float earnings): void |

## Example (as JSON)

```json
{
  "StaffId": null,
  "SaleDateTime": null,
  "SaleId": null,
  "SaleType": null,
  "ProductId": null,
  "EarningsDetails": null,
  "Earnings": null
}
```

