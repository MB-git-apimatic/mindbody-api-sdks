
# Mindbody Public Api Dto Models V6 Appointment Add On

## Structure

`MindbodyPublicApiDtoModelsV6AppointmentAddOn`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | - | getId(): ?int | setId(?int id): void |
| `name` | `?string` | Optional | - | getName(): ?string | setName(?string name): void |
| `numDeducted` | `?int` | Optional | - | getNumDeducted(): ?int | setNumDeducted(?int numDeducted): void |
| `categoryId` | `?int` | Optional | - | getCategoryId(): ?int | setCategoryId(?int categoryId): void |
| `category` | `?string` | Optional | - | getCategory(): ?string | setCategory(?string category): void |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null,
  "NumDeducted": null,
  "CategoryId": null,
  "Category": null
}
```

