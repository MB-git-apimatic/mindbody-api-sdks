
# Mindbody Public Api Dto Models V6 Client Controller Get Active Clients Memberships Response

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerGetActiveClientsMembershipsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | Contains information about the pagination to use. | getPaginationResponse(): ?MindbodyPublicApiDtoModelsV6PaginationResponse | setPaginationResponse(?MindbodyPublicApiDtoModelsV6PaginationResponse paginationResponse): void |
| `clientMemberships` | [`?(MindbodyPublicApiDtoModelsV6ClientMemberships[])`](../../doc/models/mindbody-public-api-dto-models-v6-client-memberships.md) | Optional | Details about the requested memberships. | getClientMemberships(): ?array | setClientMemberships(?array clientMemberships): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "ClientMemberships": null
}
```

