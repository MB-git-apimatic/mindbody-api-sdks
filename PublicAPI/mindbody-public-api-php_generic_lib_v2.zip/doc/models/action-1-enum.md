
# Action 1 Enum

The action taken.

## Enumeration

`Action1Enum`

## Fields

| Name |
|  --- |
| `NONE` |
| `ADDED` |
| `UPDATED` |
| `FAILED` |
| `REMOVED` |

