
# Mindbody Public Api Common Models Amenity

A specific amenity at a location

## Structure

`MindbodyPublicApiCommonModelsAmenity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | The identifying ID of the amenity. | getId(): ?int | setId(?int id): void |
| `name` | `?string` | Optional | The name of the amenity (e.g. "Lockers" or "Food/Drink"). | getName(): ?string | setName(?string name): void |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null
}
```

