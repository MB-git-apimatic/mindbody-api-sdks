
# Mindbody Public Api Dto Models V6 Payroll Controller Get Time Cards Response

## Structure

`MindbodyPublicApiDtoModelsV6PayrollControllerGetTimeCardsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | Contains information about the pagination to use. | getPaginationResponse(): ?MindbodyPublicApiDtoModelsV6PaginationResponse | setPaginationResponse(?MindbodyPublicApiDtoModelsV6PaginationResponse paginationResponse): void |
| `timeCards` | [`?(MindbodyPublicApiDtoModelsV6TimeCardEvent[])`](../../doc/models/mindbody-public-api-dto-models-v6-time-card-event.md) | Optional | Information about time card entries, ordered by staff ID. | getTimeCards(): ?array | setTimeCards(?array timeCards): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "TimeCards": null
}
```

