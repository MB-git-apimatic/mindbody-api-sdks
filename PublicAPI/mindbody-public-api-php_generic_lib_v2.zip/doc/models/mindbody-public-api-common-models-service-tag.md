
# Mindbody Public Api Common Models Service Tag

ServiceTag refers to Category and Subcategory fields for classes and appointments

## Structure

`MindbodyPublicApiCommonModelsServiceTag`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | - | getId(): ?int | setId(?int id): void |
| `name` | `?string` | Optional | - | getName(): ?string | setName(?string name): void |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null
}
```

