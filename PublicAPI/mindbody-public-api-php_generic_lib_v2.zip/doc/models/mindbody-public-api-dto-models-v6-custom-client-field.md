
# Mindbody Public Api Dto Models V6 Custom Client Field

A custom client field

## Structure

`MindbodyPublicApiDtoModelsV6CustomClientField`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | The ID of the custom client field. | getId(): ?int | setId(?int id): void |
| `dataType` | `?string` | Optional | The data type of the field. | getDataType(): ?string | setDataType(?string dataType): void |
| `name` | `?string` | Optional | The name of the field. | getName(): ?string | setName(?string name): void |

## Example (as JSON)

```json
{
  "Id": null,
  "DataType": null,
  "Name": null
}
```

