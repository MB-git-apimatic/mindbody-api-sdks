
# Mindbody Public Api Dto Models V6 Sale Controller Get Gift Card Balance Response

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerGetGiftCardBalanceResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `barcodeId` | `?string` | Optional | The gift card's barcode ID. | getBarcodeId(): ?string | setBarcodeId(?string barcodeId): void |
| `remainingBalance` | `?float` | Optional | The gift card's remaining balance. | getRemainingBalance(): ?float | setRemainingBalance(?float remainingBalance): void |

## Example (as JSON)

```json
{
  "BarcodeId": null,
  "RemainingBalance": null
}
```

