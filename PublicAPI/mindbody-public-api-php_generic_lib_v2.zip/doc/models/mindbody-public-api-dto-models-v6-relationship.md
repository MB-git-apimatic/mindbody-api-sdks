
# Mindbody Public Api Dto Models V6 Relationship

Jim is a RelationshipName1 of John. John is a RelationshipName2 of Jim.

## Structure

`MindbodyPublicApiDtoModelsV6Relationship`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | The ID of the relationship. | getId(): ?int | setId(?int id): void |
| `relationshipName1` | `?string` | Optional | The name of the first relationship. | getRelationshipName1(): ?string | setRelationshipName1(?string relationshipName1): void |
| `relationshipName2` | `?string` | Optional | The name of the second relationship. | getRelationshipName2(): ?string | setRelationshipName2(?string relationshipName2): void |

## Example (as JSON)

```json
{
  "Id": null,
  "RelationshipName1": null,
  "RelationshipName2": null
}
```

