
# Mindbody Public Api Dto Models V6 Payroll Controller Get Scheduled Service Earnings Response

## Structure

`MindbodyPublicApiDtoModelsV6PayrollControllerGetScheduledServiceEarningsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | Contains information about the pagination to use. | getPaginationResponse(): ?MindbodyPublicApiDtoModelsV6PaginationResponse | setPaginationResponse(?MindbodyPublicApiDtoModelsV6PaginationResponse paginationResponse): void |
| `scheduledServiceEarnings` | [`?(MindbodyPublicApiDtoModelsV6ScheduledServiceEarningsEvent[])`](../../doc/models/mindbody-public-api-dto-models-v6-scheduled-service-earnings-event.md) | Optional | Contains the class payroll events. | getScheduledServiceEarnings(): ?array | setScheduledServiceEarnings(?array scheduledServiceEarnings): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "ScheduledServiceEarnings": null
}
```

