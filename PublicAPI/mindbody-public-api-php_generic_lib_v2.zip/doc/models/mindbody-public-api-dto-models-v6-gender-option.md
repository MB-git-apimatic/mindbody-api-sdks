
# Mindbody Public Api Dto Models V6 Gender Option

A gender option available at a site

## Structure

`MindbodyPublicApiDtoModelsV6GenderOption`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | The id of the gender option | getId(): ?int | setId(?int id): void |
| `name` | `?string` | Optional | The name of the gender option | getName(): ?string | setName(?string name): void |
| `isActive` | `?bool` | Optional | Whether the gender option is active and can be assigned to a consumer profile | getIsActive(): ?bool | setIsActive(?bool isActive): void |
| `isDefault` | `?bool` | Optional | Whether the gender option is the default value applied to a consumer profile | getIsDefault(): ?bool | setIsDefault(?bool isDefault): void |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null,
  "IsActive": null,
  "IsDefault": null
}
```

