
# Mindbody Public Api Dto Models V6 Staff Controller Get Staff Response

## Structure

`MindbodyPublicApiDtoModelsV6StaffControllerGetStaffResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | Contains information about the pagination to use. | getPaginationResponse(): ?MindbodyPublicApiDtoModelsV6PaginationResponse | setPaginationResponse(?MindbodyPublicApiDtoModelsV6PaginationResponse paginationResponse): void |
| `staffMembers` | [`?(MindbodyPublicApiDtoModelsV6Staff[])`](../../doc/models/mindbody-public-api-dto-models-v6-staff.md) | Optional | A list of staff members. See Staff for a description of the 'Staff' information. | getStaffMembers(): ?array | setStaffMembers(?array staffMembers): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "StaffMembers": null
}
```

