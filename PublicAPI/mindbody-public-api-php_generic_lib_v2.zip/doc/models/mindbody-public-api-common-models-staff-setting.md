
# Mindbody Public Api Common Models Staff Setting

## Structure

`MindbodyPublicApiCommonModelsStaffSetting`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `useStaffNicknames` | `?bool` | Optional | - | getUseStaffNicknames(): ?bool | setUseStaffNicknames(?bool useStaffNicknames): void |
| `showStaffLastNamesOnSchedules` | `?bool` | Optional | - | getShowStaffLastNamesOnSchedules(): ?bool | setShowStaffLastNamesOnSchedules(?bool showStaffLastNamesOnSchedules): void |

## Example (as JSON)

```json
{
  "UseStaffNicknames": null,
  "ShowStaffLastNamesOnSchedules": null
}
```

