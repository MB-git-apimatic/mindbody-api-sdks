
# Mindbody Public Api Dto Models V6 Class

Represents a single class instance. The class meets at the start time, goes until the end time.

## Structure

`MindbodyPublicApiDtoModelsV6Class`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `classScheduleId` | `?int` | Optional | The ID used to retrieve the class schedule for the desired class. | getClassScheduleId(): ?int | setClassScheduleId(?int classScheduleId): void |
| `visits` | [`?(MindbodyPublicApiDtoModelsV6Visit[])`](../../doc/models/mindbody-public-api-dto-models-v6-visit.md) | Optional | Contains information about visits. | getVisits(): ?array | setVisits(?array visits): void |
| `clients` | [`?(MindbodyPublicApiDtoModelsV6Client[])`](../../doc/models/mindbody-public-api-dto-models-v6-client.md) | Optional | Contains information about clients. | getClients(): ?array | setClients(?array clients): void |
| `location` | [`?MindbodyPublicApiDtoModelsV6Location`](../../doc/models/mindbody-public-api-dto-models-v6-location.md) | Optional | - | getLocation(): ?MindbodyPublicApiDtoModelsV6Location | setLocation(?MindbodyPublicApiDtoModelsV6Location location): void |
| `resource` | [`?MindbodyPublicApiDtoModelsV6Resource`](../../doc/models/mindbody-public-api-dto-models-v6-resource.md) | Optional | Contains information about resources, such as rooms. | getResource(): ?MindbodyPublicApiDtoModelsV6Resource | setResource(?MindbodyPublicApiDtoModelsV6Resource resource): void |
| `maxCapacity` | `?int` | Optional | The maximum number of clients allowed in the class. | getMaxCapacity(): ?int | setMaxCapacity(?int maxCapacity): void |
| `webCapacity` | `?int` | Optional | The maximum number of clients allowed to sign up online for the class. | getWebCapacity(): ?int | setWebCapacity(?int webCapacity): void |
| `totalBooked` | `?int` | Optional | The total number of clients booked in the class. | getTotalBooked(): ?int | setTotalBooked(?int totalBooked): void |
| `totalSignedIn` | `?int` | Optional | The total number of clients signed into the class. | getTotalSignedIn(): ?int | setTotalSignedIn(?int totalSignedIn): void |
| `totalBookedWaitlist` | `?int` | Optional | The total number of booked clients on the waiting list for the class. | getTotalBookedWaitlist(): ?int | setTotalBookedWaitlist(?int totalBookedWaitlist): void |
| `webBooked` | `?int` | Optional | The total number of clients who signed up online for the class. | getWebBooked(): ?int | setWebBooked(?int webBooked): void |
| `semesterId` | `?int` | Optional | The ID of the semester that the class is a part of, if any. | getSemesterId(): ?int | setSemesterId(?int semesterId): void |
| `isCanceled` | `?bool` | Optional | When `true`, indicates that the class has been cancelled.<br /><br>When `false`, indicates that the class has not been cancelled. | getIsCanceled(): ?bool | setIsCanceled(?bool isCanceled): void |
| `substitute` | `?bool` | Optional | When `true`, indicates that the class is being taught by a substitute teacher.<br /><br>When `false`, indicates that the class is being taught by its regular teacher. | getSubstitute(): ?bool | setSubstitute(?bool substitute): void |
| `active` | `?bool` | Optional | When `true`, indicates that the class is shown to clients when in consumer mode.<br /><br>When `false`, indicates that the class is not shown to clients when in consumer mode. | getActive(): ?bool | setActive(?bool active): void |
| `isWaitlistAvailable` | `?bool` | Optional | When `true`, indicates that the clients can be placed on a waiting list for the class.<br /><br>When `false`, indicates that the clients cannot be placed on a waiting list for the class. | getIsWaitlistAvailable(): ?bool | setIsWaitlistAvailable(?bool isWaitlistAvailable): void |
| `isEnrolled` | `?bool` | Optional | When `true`, indicates that the client with the given `ClientId` is enrolled in this class.<br /><br>When `false`, indicates that the client with the given `ClientId` is not enrolled in this class. | getIsEnrolled(): ?bool | setIsEnrolled(?bool isEnrolled): void |
| `hideCancel` | `?bool` | Optional | When `true`, indicates that this class is hidden when cancelled.<br /><br>When `false`, indicates that this class is not hidden when cancelled. | getHideCancel(): ?bool | setHideCancel(?bool hideCancel): void |
| `id` | `?int` | Optional | The unique identifier for the class. | getId(): ?int | setId(?int id): void |
| `isAvailable` | `?bool` | Optional | When `true`, indicates that the client with the given client ID can book this class.<br /><br>When `false`, indicates that the client with the given client ID cannot book this class. | getIsAvailable(): ?bool | setIsAvailable(?bool isAvailable): void |
| `startDateTime` | `?\DateTime` | Optional | The time this class is scheduled to start. | getStartDateTime(): ?\DateTime | setStartDateTime(?\DateTime startDateTime): void |
| `endDateTime` | `?\DateTime` | Optional | The time this class is scheduled to end. | getEndDateTime(): ?\DateTime | setEndDateTime(?\DateTime endDateTime): void |
| `lastModifiedDateTime` | `?\DateTime` | Optional | The last time this class was modified. | getLastModifiedDateTime(): ?\DateTime | setLastModifiedDateTime(?\DateTime lastModifiedDateTime): void |
| `classDescription` | [`?MindbodyPublicApiDtoModelsV6ClassDescription`](../../doc/models/mindbody-public-api-dto-models-v6-class-description.md) | Optional | Represents a class definition. The class meets at the start time, goes until the end time. | getClassDescription(): ?MindbodyPublicApiDtoModelsV6ClassDescription | setClassDescription(?MindbodyPublicApiDtoModelsV6ClassDescription classDescription): void |
| `staff` | [`?MindbodyPublicApiDtoModelsV6Staff`](../../doc/models/mindbody-public-api-dto-models-v6-staff.md) | Optional | The Staff | getStaff(): ?MindbodyPublicApiDtoModelsV6Staff | setStaff(?MindbodyPublicApiDtoModelsV6Staff staff): void |
| `bookingWindow` | [`?MindbodyPublicApiDtoModelsV6BookingWindow`](../../doc/models/mindbody-public-api-dto-models-v6-booking-window.md) | Optional | The booking window for registration | getBookingWindow(): ?MindbodyPublicApiDtoModelsV6BookingWindow | setBookingWindow(?MindbodyPublicApiDtoModelsV6BookingWindow bookingWindow): void |
| `bookingStatus` | [`?string (BookingStatusEnum)`](../../doc/models/booking-status-enum.md) | Optional | Contains the booking’s payment status. | getBookingStatus(): ?string | setBookingStatus(?string bookingStatus): void |
| `virtualStreamLink` | `?string` | Optional | The URL for the live stream for the class if hosted on the mindbody virtual wellness platform | getVirtualStreamLink(): ?string | setVirtualStreamLink(?string virtualStreamLink): void |

## Example (as JSON)

```json
{
  "ClassScheduleId": null,
  "Visits": null,
  "Clients": null,
  "Location": null,
  "Resource": null,
  "MaxCapacity": null,
  "WebCapacity": null,
  "TotalBooked": null,
  "TotalSignedIn": null,
  "TotalBookedWaitlist": null,
  "WebBooked": null,
  "SemesterId": null,
  "IsCanceled": null,
  "Substitute": null,
  "Active": null,
  "IsWaitlistAvailable": null,
  "IsEnrolled": null,
  "HideCancel": null,
  "Id": null,
  "IsAvailable": null,
  "StartDateTime": null,
  "EndDateTime": null,
  "LastModifiedDateTime": null,
  "ClassDescription": null,
  "Staff": null,
  "BookingWindow": null,
  "BookingStatus": null,
  "VirtualStreamLink": null
}
```

