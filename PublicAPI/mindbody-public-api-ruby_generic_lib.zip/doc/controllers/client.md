# Client

```ruby
client_controller = client.client
```

## Class Name

`ClientController`

## Methods

* [Client Get Clients](../../doc/controllers/client.md#client-get-clients)
* [Client Get Client Duplicates](../../doc/controllers/client.md#client-get-client-duplicates)
* [Client Get Client Formula Notes](../../doc/controllers/client.md#client-get-client-formula-notes)
* [Client Delete Client Formula Note](../../doc/controllers/client.md#client-delete-client-formula-note)
* [Client Add Formula Note](../../doc/controllers/client.md#client-add-formula-note)
* [Client Upload Client Document](../../doc/controllers/client.md#client-upload-client-document)
* [Client Upload Client Photo](../../doc/controllers/client.md#client-upload-client-photo)
* [Client Get Client Contracts](../../doc/controllers/client.md#client-get-client-contracts)
* [Client Get Client Services](../../doc/controllers/client.md#client-get-client-services)
* [Client Get Client Visits](../../doc/controllers/client.md#client-get-client-visits)
* [Client Get Client Schedule](../../doc/controllers/client.md#client-get-client-schedule)
* [Client Get Active Client Memberships](../../doc/controllers/client.md#client-get-active-client-memberships)
* [Client Get Required Client Fields](../../doc/controllers/client.md#client-get-required-client-fields)
* [Client Get Client Referral Types](../../doc/controllers/client.md#client-get-client-referral-types)
* [Client Get Client Account Balances](../../doc/controllers/client.md#client-get-client-account-balances)
* [Client Get Client Purchases](../../doc/controllers/client.md#client-get-client-purchases)
* [Client Get Client Indexes](../../doc/controllers/client.md#client-get-client-indexes)
* [Client Get Custom Client Fields](../../doc/controllers/client.md#client-get-custom-client-fields)
* [Client Add Contact Log](../../doc/controllers/client.md#client-add-contact-log)
* [Client Update Contact Log](../../doc/controllers/client.md#client-update-contact-log)
* [Client Get Cross Regional Client Associations](../../doc/controllers/client.md#client-get-cross-regional-client-associations)
* [Client Add Client](../../doc/controllers/client.md#client-add-client)
* [Client Update Client](../../doc/controllers/client.md#client-update-client)
* [Client Update Client Visit](../../doc/controllers/client.md#client-update-client-visit)
* [Client Add Arrival](../../doc/controllers/client.md#client-add-arrival)
* [Client Send Password Reset Email](../../doc/controllers/client.md#client-send-password-reset-email)
* [Client Get Contact Logs](../../doc/controllers/client.md#client-get-contact-logs)
* [Client Update Client Service](../../doc/controllers/client.md#client-update-client-service)
* [Client Get Direct Debit Info](../../doc/controllers/client.md#client-get-direct-debit-info)
* [Client Delete Direct Debit Info](../../doc/controllers/client.md#client-delete-direct-debit-info)
* [Client Add Client Direct Debit Info](../../doc/controllers/client.md#client-add-client-direct-debit-info)
* [Client Get Client Rewards](../../doc/controllers/client.md#client-get-client-rewards)
* [Client Update Client Rewards](../../doc/controllers/client.md#client-update-client-rewards)
* [Client Get Client Complete Info](../../doc/controllers/client.md#client-get-client-complete-info)
* [Client Get Contact Log Types](../../doc/controllers/client.md#client-get-contact-log-types)
* [Client Delete Contact Log](../../doc/controllers/client.md#client-delete-contact-log)
* [Client Send Auto Email](../../doc/controllers/client.md#client-send-auto-email)
* [Client Get Active Clients Memberships](../../doc/controllers/client.md#client-get-active-clients-memberships)
* [Client Terminate Contract](../../doc/controllers/client.md#client-terminate-contract)
* [Client Update Client Contract Autopays](../../doc/controllers/client.md#client-update-client-contract-autopays)
* [Client Suspend Contract](../../doc/controllers/client.md#client-suspend-contract)
* [Client Merge Client](../../doc/controllers/client.md#client-merge-client)


# Client Get Clients

This endpoint requires staff user credentials. This endpoint supports pagination. See Pagination for a description of the Pagination information.

```ruby
def client_get_clients(version,
                       site_id,
                       authorization: nil,
                       request_client_i_ds: nil,
                       request_include_inactive: nil,
                       request_is_prospect: nil,
                       request_last_modified_date: nil,
                       request_limit: nil,
                       request_offset: nil,
                       request_search_text: nil,
                       request_unique_ids: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |
| `request_client_i_ds` | `Array<String>` | Query, Optional | The requested client IDs.<br>Default: **all IDs** that the authenticated user’s access level allows.<br /><br>Note: You can fetch information for maximum 20 clients at once. |
| `request_include_inactive` | `TrueClass\|FalseClass` | Query, Optional | When `true`, indicates the results to include active and inactive clients.<br /><br>When `false`, indicates that only those clients who are marked as active should be returned.<br>Default: **false** |
| `request_is_prospect` | `TrueClass\|FalseClass` | Query, Optional | When `true`, filters the results to include only those clients marked as prospects for the business.<br /><br>When `false`, indicates that only those clients who are not marked prospects should be returned. |
| `request_last_modified_date` | `DateTime` | Query, Optional | Filters the results to include only the clients that have been modified on or after this date. |
| `request_limit` | `Integer` | Query, Optional | Number of results to include, defaults to 100 |
| `request_offset` | `Integer` | Query, Optional | Page offset, defaults to 0. |
| `request_search_text` | `String` | Query, Optional | Text to use in the search. Can include FirstName, LastName, and Email. Note that user credentials must be provided. |
| `request_unique_ids` | `Array<Integer>` | Query, Optional | Filters results to clients with these `UniqueIDs`. This parameter cannot be used with `ClientIDs` or `SearchText`.<br>Default: **all UniqueIDs** that the authenticated user’s access level allows. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetClientsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-clients-response.md)

## Example Usage

```ruby
version = '6'
site_id = '-99'

result = client_controller.client_get_clients(version, site_id, )
```


# Client Get Client Duplicates

This endpoint gets client records that would be considered duplicates based on case-insensitive matching of the client’s first name, last name, and email. For there to be results, all three parameters must match a client record. This endpoint requires staff user credentials.

An empty `ClientDuplicates` object in the response from this endpoint indicates that there were no client records found that match the first name, last name, and email fields passed in.

If one client record is returned, it is not a duplicate itself, but no other client record can be created or updated that would match this client’s first name, last name, and email combination.

If more than one client record is returned, these clients are duplicates of each other.We recommend discussing with the business how they would like to resolve duplicate records in the event the response contains more than one client record.Businesses can use the Merge Duplicate Clients tool in the Core Business Mode software to resolve the duplicate client records.

```ruby
def client_get_client_duplicates(version,
                                 site_id,
                                 authorization: nil,
                                 request_email: nil,
                                 request_first_name: nil,
                                 request_last_name: nil,
                                 request_limit: nil,
                                 request_offset: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |
| `request_email` | `String` | Query, Optional | The client email to match on when searching for duplicates. |
| `request_first_name` | `String` | Query, Optional | The client first name to match on when searching for duplicates. |
| `request_last_name` | `String` | Query, Optional | The client last name to match on when searching for duplicates. |
| `request_limit` | `Integer` | Query, Optional | Number of results to include, defaults to 100 |
| `request_offset` | `Integer` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetClientDuplicatesResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-client-duplicates-response.md)

## Example Usage

```ruby
version = '6'
site_id = '-99'

result = client_controller.client_get_client_duplicates(version, site_id, )
```


# Client Get Client Formula Notes

***QueryParams***: Enables to retrieve cross regional formula notes for a client, or for a specific appointment. The two parameters are optional, however at least one must be provided. This endpoint supports pagination.

```ruby
def client_get_client_formula_notes(version,
                                    site_id,
                                    authorization: nil,
                                    request_appointment_id: nil,
                                    request_client_id: nil,
                                    request_limit: nil,
                                    request_offset: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |
| `request_appointment_id` | `Integer` | Query, Optional | The appointment ID of an appointment in the studio specified in the header of the request. |
| `request_client_id` | `String` | Query, Optional | The client ID of the client whose formula notes are being requested. |
| `request_limit` | `Integer` | Query, Optional | Number of results to include, defaults to 100 |
| `request_offset` | `Integer` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetClientFormulaNotesResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-client-formula-notes-response.md)

## Example Usage

```ruby
version = '6'
site_id = '-99'

result = client_controller.client_get_client_formula_notes(version, site_id, )
```


# Client Delete Client Formula Note

This endpoint deletes an existing formula note. A staff user token must be included with staff assigned permission to view client profile or have both ViewAppointmentDetails and ModifyAppointment permissions.

```ruby
def client_delete_client_formula_note(version,
                                      request_client_id,
                                      request_formula_note_id,
                                      site_id,
                                      authorization: nil,
                                      request_limit: nil,
                                      request_offset: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `request_client_id` | `String` | Query, Required | The client ID of the client whose formula note needs to be deleted. |
| `request_formula_note_id` | `Integer` | Query, Required | The formula note ID for the note to be deleted. |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |
| `request_limit` | `Integer` | Query, Optional | Number of results to include, defaults to 100 |
| `request_offset` | `Integer` | Query, Optional | Page offset, defaults to 0. |

## Response Type

`void`

## Example Usage

```ruby
version = '6'
request_client_id = 'request.clientId2'
request_formula_note_id = 72
site_id = '-99'

result = client_controller.client_delete_client_formula_note(version, request_client_id, request_formula_note_id, site_id, )
```


# Client Add Formula Note

This endpoint adds a formula note for a specified client or specified client appointment. A staff user token must be included with staff assigned permission to view client profile or have both ViewAppointmentDetails and ModifyAppointment permissions.

```ruby
def client_add_formula_note(version,
                            request,
                            site_id,
                            authorization: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6ClientControllerAddFormulaNoteRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-add-formula-note-request.md) | Body, Required | - |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerFormulaNoteResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-formula-note-response.md)

## Example Usage

```ruby
version = '6'
request = MindbodyPublicApiDtoModelsV6ClientControllerAddFormulaNoteRequest.new
request.client_id = 'ClientId0'
request.note = 'Note6'
site_id = '-99'

result = client_controller.client_add_formula_note(version, request, site_id, )
```


# Client Upload Client Document

Uploads a document file for a specific client. Returns a string representation of the image byte array. The maximum size file that can be uploaded is **4MB**.

```ruby
def client_upload_client_document(version,
                                  request,
                                  site_id,
                                  authorization: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6ClientControllerUploadClientDocumentRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-upload-client-document-request.md) | Body, Required | - |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerUploadClientDocumentResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-upload-client-document-response.md)

## Example Usage

```ruby
version = '6'
request = MindbodyPublicApiDtoModelsV6ClientControllerUploadClientDocumentRequest.new
request.client_id = 'ClientId0'
request.file = MindbodyPublicApiDtoModelsV6ClientDocument.new
request.file.file_name = 'FileName2'
request.file.media_type = 'MediaType2'
request.file.buffer = 'Buffer4'
site_id = '-99'

result = client_controller.client_upload_client_document(version, request, site_id, )
```


# Client Upload Client Photo

Uploads a client’s profile photo. The maximum file size is 4 MB and acceptable file types are:

* bmp
* jpeg
* gif
* tiff
* png

```ruby
def client_upload_client_photo(version,
                               request,
                               site_id,
                               authorization: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6ClientControllerUploadClientPhotoRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-upload-client-photo-request.md) | Body, Required | - |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerUploadClientPhotoResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-upload-client-photo-response.md)

## Example Usage

```ruby
version = '6'
request = MindbodyPublicApiDtoModelsV6ClientControllerUploadClientPhotoRequest.new
request.bytes = 'Bytes6'
request.client_id = 'ClientId0'
site_id = '-99'

result = client_controller.client_upload_client_photo(version, request, site_id, )
```


# Client Get Client Contracts

Get contracts that a client has purchased.

```ruby
def client_get_client_contracts(version,
                                request_client_id,
                                site_id,
                                authorization: nil,
                                request_client_associated_sites_offset: nil,
                                request_cross_regional_lookup: nil,
                                request_limit: nil,
                                request_offset: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `request_client_id` | `String` | Query, Required | The ID of the client. |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |
| `request_client_associated_sites_offset` | `Integer` | Query, Optional | Determines how many sites are skipped over when retrieving a client’s cross regional contracts. Used when a client ID is linked to more than ten sites in an organization. Only a maximum of ten site databases are queried when this call is made and `CrossRegionalLookup` is set to `true`. To change which sites are queried, change this offset value.<br>Default: **0** |
| `request_cross_regional_lookup` | `TrueClass\|FalseClass` | Query, Optional | When `true`, indicates that the requesting client’s cross regional contracts are returned, if any.<br /><br>When `false`, indicates that cross regional contracts are not returned. |
| `request_limit` | `Integer` | Query, Optional | Number of results to include, defaults to 100 |
| `request_offset` | `Integer` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetClientContractsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-client-contracts-response.md)

## Example Usage

```ruby
version = '6'
request_client_id = 'request.clientId2'
site_id = '-99'

result = client_controller.client_get_client_contracts(version, request_client_id, site_id, )
```


# Client Get Client Services

Get pricing options that a client has purchased.

```ruby
def client_get_client_services(version,
                               request_client_id,
                               site_id,
                               authorization: nil,
                               request_class_id: nil,
                               request_client_associated_sites_offset: nil,
                               request_cross_regional_lookup: nil,
                               request_end_date: nil,
                               request_ignore_cross_regional_site_limit: nil,
                               request_limit: nil,
                               request_location_ids: nil,
                               request_offset: nil,
                               request_program_ids: nil,
                               request_session_type_id: nil,
                               request_show_active_only: nil,
                               request_start_date: nil,
                               request_visit_count: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `request_client_id` | `String` | Query, Required | The ID of the client to query. The results are a list of pricing options that the client has purchased. Note that “service” and “pricing option” are synonymous in this section of the documentation. |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |
| `request_class_id` | `Integer` | Query, Optional | Filters results to only those pricing options that can be used to pay for this class. |
| `request_client_associated_sites_offset` | `Integer` | Query, Optional | Used to retrieve a client’s pricing options from multiple sites within an organization when the client is associated with more than ten sites. To change which ten sites are searched, change this offset value. A value of 0 means that no sites are skipped and the first ten sites are returned. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that you must always have `CrossRegionalLookup` set to `true` to use this parameter.<br /><br>Default: **0**<br><br>For example, if a client is associated with 25 sites, you need to call `GetClientServices` three times, as follows:<br><br>* Use `GET CrossRegionalClientAssociations` to determine how many sites a client is associated with, which tells you how many additional calls you need to make.<br>* Either omit `ClientAssociatedSitesOffset` or set it to 0 to return the client’s services (pricing options) from sites 1-10.<br>* Set `ClientAssociatedSitesOffset` to 10 to return the client pricing options from sites 11-20<br>* Set `ClientAssociatedSitesOffset` to 20 to return the client pricing options from sites 21-25 |
| `request_cross_regional_lookup` | `TrueClass\|FalseClass` | Query, Optional | Used to retrieve a client’s pricing options from multiple sites within an organization. When included and set to `true`, it searches a maximum of ten sites with which this client is associated. When a client is associated with more than ten sites, use `ClientAssociatedSitesOffset` as many times as needed to search the additional sites with which the client is associated. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that a `SiteID` is returned and populated in the `ClientServices` response when `CrossRegionalLookup` is set to `true`.<br>Default: **false** |
| `request_end_date` | `DateTime` | Query, Optional | Filters results to pricing options that are valid on or before this date.<br>Default: **today’s date** |
| `request_ignore_cross_regional_site_limit` | `TrueClass\|FalseClass` | Query, Optional | Used to specify if the number of cross regional sites used to search for client’s pricing options should be ignored.<br>Default: **false** |
| `request_limit` | `Integer` | Query, Optional | Number of results to include, defaults to 100 |
| `request_location_ids` | `Array<Integer>` | Query, Optional | Filters results to pricing options that can be used at the listed location IDs. |
| `request_offset` | `Integer` | Query, Optional | Page offset, defaults to 0. |
| `request_program_ids` | `Array<Integer>` | Query, Optional | Filters results to pricing options that belong to one of the given program IDs. |
| `request_session_type_id` | `Integer` | Query, Optional | Filters results to pricing options that will pay for the given session type ID. Use this to find pricing options that will pay for a specific appointment type. |
| `request_show_active_only` | `TrueClass\|FalseClass` | Query, Optional | When `true`, includes active services only.<br>Default: **false** |
| `request_start_date` | `DateTime` | Query, Optional | Filters results to pricing options that are valid on or after this date.<br>Default: **today’s date** |
| `request_visit_count` | `Integer` | Query, Optional | A filter on the minimum number of visits a service can pay for. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetClientServicesResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-client-services-response.md)

## Example Usage

```ruby
version = '6'
request_client_id = 'request.clientId2'
site_id = '-99'

result = client_controller.client_get_client_services(version, request_client_id, site_id, )
```


# Client Get Client Visits

Gets the Client Visits for a specific client.

```ruby
def client_get_client_visits(version,
                             request_client_id,
                             site_id,
                             authorization: nil,
                             request_client_associated_sites_offset: nil,
                             request_cross_regional_lookup: nil,
                             request_end_date: nil,
                             request_limit: nil,
                             request_offset: nil,
                             request_start_date: nil,
                             request_unpaids_only: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `request_client_id` | `String` | Query, Required | The ID of the requested client. |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |
| `request_client_associated_sites_offset` | `Integer` | Query, Optional | The number of sites to skip when returning the site associated with a client. |
| `request_cross_regional_lookup` | `TrueClass\|FalseClass` | Query, Optional | When `true`, indicates that past and scheduled client visits across all sites in the region are returned.<br /><br>When `false`, indicates that only visits at the current site are returned. |
| `request_end_date` | `DateTime` | Query, Optional | The date past which class visits are not returned.<br>Default: **today’s date** |
| `request_limit` | `Integer` | Query, Optional | Number of results to include, defaults to 100 |
| `request_offset` | `Integer` | Query, Optional | Page offset, defaults to 0. |
| `request_start_date` | `DateTime` | Query, Optional | The date before which class visits are not returned.<br>Default: **the end date** |
| `request_unpaids_only` | `TrueClass\|FalseClass` | Query, Optional | When `true`, indicates that only visits that have not been paid for are returned.<br /><br>When `false`, indicates that all visits are returned, regardless of whether they have been paid for.<br /><br>Default: **false** |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetClientVisitsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-client-visits-response.md)

## Example Usage

```ruby
version = '6'
request_client_id = 'request.clientId2'
site_id = '-99'

result = client_controller.client_get_client_visits(version, request_client_id, site_id, )
```


# Client Get Client Schedule

This endpoint can be utilized to retrieve scheduled visits which is associated with the requested client.

```ruby
def client_get_client_schedule(version,
                               request_client_id,
                               site_id,
                               authorization: nil,
                               request_client_associated_sites_offset: nil,
                               request_cross_regional_lookup: nil,
                               request_end_date: nil,
                               request_limit: nil,
                               request_offset: nil,
                               request_start_date: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `request_client_id` | `String` | Query, Required | The ID of the requested client. |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |
| `request_client_associated_sites_offset` | `Integer` | Query, Optional | The number of sites to skip when returning the site associated with a client. |
| `request_cross_regional_lookup` | `TrueClass\|FalseClass` | Query, Optional | When `true`, indicates that past and scheduled client visits across all sites in the region are returned.<br>When `false`, indicates that only visits at the current site are returned. |
| `request_end_date` | `DateTime` | Query, Optional | The date past which class visits are not returned.<br>Default is today’s date |
| `request_limit` | `Integer` | Query, Optional | Number of results to include, defaults to 100 |
| `request_offset` | `Integer` | Query, Optional | Page offset, defaults to 0. |
| `request_start_date` | `DateTime` | Query, Optional | The date before which class visits are not returned.<br>Default is the end date |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetClientScheduleResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-client-schedule-response.md)

## Example Usage

```ruby
version = '6'
request_client_id = 'request.clientId2'
site_id = '-99'

result = client_controller.client_get_client_schedule(version, request_client_id, site_id, )
```


# Client Get Active Client Memberships

Please note that client memberships with location restrictions can only be used to pay for scheduled services at the site to which they belong. Memberships with location restrictions can not be used to pay for scheduled services at other sites within an organization.

```ruby
def client_get_active_client_memberships(version,
                                         request_client_id,
                                         site_id,
                                         authorization: nil,
                                         request_client_associated_sites_offset: nil,
                                         request_cross_regional_lookup: nil,
                                         request_limit: nil,
                                         request_location_id: nil,
                                         request_offset: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `request_client_id` | `String` | Query, Required | The ID of the client for whom memberships are returned. |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |
| `request_client_associated_sites_offset` | `Integer` | Query, Optional | Used to retrieve a client’s memberships from multiple sites within an organization when the client is associated with more than ten sites. To change which ten sites are searched, change this offset value. A value of 0 means that no sites are skipped and the first ten sites are returned. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that you must always have `CrossRegionalLookup` set to `true` to use this parameter.<br /><br>Default: **0**<br><br>For example, if a client is associated with 25 sites, you need to call `GetClientServices` three times, as follows:<br><br>* Use `GET CrossRegionalClientAssociations` to determine how many sites a client is associated with, which tells you how many additional calls you need to make.<br>* Either omit `ClientAssociatedSitesOffset` or set it to 0 to return the client’s services (pricing options) from sites 1-10.<br>* Set `ClientAssociatedSitesOffset` to 10 to return the client pricing options from sites 11-20<br>* Set `ClientAssociatedSitesOffset` to 20 to return the client pricing options from sites 21-25 |
| `request_cross_regional_lookup` | `TrueClass\|FalseClass` | Query, Optional | Used to retrieve a client’s memberships from multiple sites within an organization. When included and set to `true`, it searches a maximum of ten sites with which this client is associated. When a client is associated with more than ten sites, use `ClientAssociatedSitesOffset` as many times as needed to search the additional sites with which the client is associated. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that a `SiteID` is returned and populated in the `ClientServices` response when `CrossRegionalLookup` is set to `true`.<br>Default: **false** |
| `request_limit` | `Integer` | Query, Optional | Number of results to include, defaults to 100 |
| `request_location_id` | `Integer` | Query, Optional | Filters results to memberships that can be used to pay for scheduled services at that location. This parameter can not be passed when `CrossRegionalLookup` is `true`. |
| `request_offset` | `Integer` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetActiveClientMembershipsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-active-client-memberships-response.md)

## Example Usage

```ruby
version = '6'
request_client_id = 'request.clientId2'
site_id = '-99'

result = client_controller.client_get_active_client_memberships(version, request_client_id, site_id, )
```


# Client Get Required Client Fields

Gets the list of fields that a new client has to fill out in business mode, specifically for the sign-up process. `AddClient` and `UpdateClient` validate against these fields.

This endpoint has no query parameters.

```ruby
def client_get_required_client_fields(version,
                                      site_id,
                                      authorization: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetRequiredClientFieldsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-required-client-fields-response.md)

## Example Usage

```ruby
version = '6'
site_id = '-99'

result = client_controller.client_get_required_client_fields(version, site_id, )
```


# Client Get Client Referral Types

Gets a list of referral types. Referral types are options that new clients can choose to identify how they learned about the business. Referral types are typically used for the sign-up process.

```ruby
def client_get_client_referral_types(version,
                                     site_id,
                                     authorization: nil,
                                     request_include_inactive: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |
| `request_include_inactive` | `TrueClass\|FalseClass` | Query, Optional | When `true`, filters the results to include subtypes and inactive referral types.<br /><br>When `false`, includes no subtypes and only active types.<br>Default:**false** |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetClientReferralTypesResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-client-referral-types-response.md)

## Example Usage

```ruby
version = '6'
site_id = '-99'

result = client_controller.client_get_client_referral_types(version, site_id, )
```


# Client Get Client Account Balances

Get account balance information for one or more client(s).

```ruby
def client_get_client_account_balances(version,
                                       request_client_ids,
                                       site_id,
                                       authorization: nil,
                                       request_balance_date: nil,
                                       request_class_id: nil,
                                       request_limit: nil,
                                       request_offset: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `request_client_ids` | `Array<String>` | Query, Required | The list of clients IDs for which you want account balances. |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |
| `request_balance_date` | `DateTime` | Query, Optional | The date you want a balance relative to.<br>Default: **the current date** |
| `request_class_id` | `Integer` | Query, Optional | The class ID of the event for which you want a balance. |
| `request_limit` | `Integer` | Query, Optional | Number of results to include, defaults to 100 |
| `request_offset` | `Integer` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetClientAccountBalancesResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-client-account-balances-response.md)

## Example Usage

```ruby
version = '6'
request_client_ids = ['request.clientIds9', 'request.clientIds0', 'request.clientIds1']
site_id = '-99'

result = client_controller.client_get_client_account_balances(version, request_client_ids, site_id, )
```


# Client Get Client Purchases

Gets a list of purchases made by a specific client.

```ruby
def client_get_client_purchases(version,
                                request_client_id,
                                site_id,
                                authorization: nil,
                                request_end_date: nil,
                                request_limit: nil,
                                request_offset: nil,
                                request_sale_id: nil,
                                request_start_date: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `request_client_id` | `String` | Query, Required | The ID of the client you are querying for purchases. |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |
| `request_end_date` | `DateTime` | Query, Optional | Filters results to purchases made before this timestamp.<br /><br>Default: **end of today** |
| `request_limit` | `Integer` | Query, Optional | Number of results to include, defaults to 100 |
| `request_offset` | `Integer` | Query, Optional | Page offset, defaults to 0. |
| `request_sale_id` | `Integer` | Query, Optional | Filters results to the single record associated with this ID. |
| `request_start_date` | `DateTime` | Query, Optional | Filters results to purchases made on or after this timestamp.<br /><br>Default: **now** |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetClientPurchasesResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-client-purchases-response.md)

## Example Usage

```ruby
version = '6'
request_client_id = 'request.clientId2'
site_id = '-99'

result = client_controller.client_get_client_purchases(version, request_client_id, site_id, )
```


# Client Get Client Indexes

Client indexes are used to analyze client demographics. A business owner can set up different categories with sets of values which they can assign to each client. Client indexes are used in client searches, for tagging clients so that the owner can send mass emails to similar groups, and for many reports.

For more information, see Client Indexes and [Client Index Values (video tutorial)](https://support.mindbodyonline.com/s/article/203261653-Client-indexes-and-client-index-values-video-tutorial?language=en_USclient).

```ruby
def client_get_client_indexes(version,
                              site_id,
                              authorization: nil,
                              request_required_only: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |
| `request_required_only` | `TrueClass\|FalseClass` | Query, Optional | When `true`, filters the results to only indexes that are required on creation.<br /><br>When `false` or omitted, returns all of the client indexes. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetClientIndexesResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-client-indexes-response.md)

## Example Usage

```ruby
version = '6'
site_id = '-99'

result = client_controller.client_get_client_indexes(version, site_id, )
```


# Client Get Custom Client Fields

Get a site's configured custom client fields.

```ruby
def client_get_custom_client_fields(version,
                                    site_id,
                                    authorization: nil,
                                    request_limit: nil,
                                    request_offset: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |
| `request_limit` | `Integer` | Query, Optional | Number of results to include, defaults to 100 |
| `request_offset` | `Integer` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetCustomClientFieldsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-custom-client-fields-response.md)

## Example Usage

```ruby
version = '6'
site_id = '-99'

result = client_controller.client_get_custom_client_fields(version, site_id, )
```


# Client Add Contact Log

Add a contact log to a client's account.

```ruby
def client_add_contact_log(version,
                           request,
                           site_id,
                           authorization: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6ClientControllerAddContactLogRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-add-contact-log-request.md) | Body, Required | - |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ContactLog`](../../doc/models/mindbody-public-api-dto-models-v6-contact-log.md)

## Example Usage

```ruby
version = '6'
request = MindbodyPublicApiDtoModelsV6ClientControllerAddContactLogRequest.new
request.client_id = 'ClientId0'
request.contact_method = 'ContactMethod0'
site_id = '-99'

result = client_controller.client_add_contact_log(version, request, site_id, )
```


# Client Update Contact Log

Update a contact log on a client's account.

```ruby
def client_update_contact_log(version,
                              request,
                              site_id,
                              authorization: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6ClientControllerUpdateContactLogRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-update-contact-log-request.md) | Body, Required | - |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ContactLog`](../../doc/models/mindbody-public-api-dto-models-v6-contact-log.md)

## Example Usage

```ruby
version = '6'
request = MindbodyPublicApiDtoModelsV6ClientControllerUpdateContactLogRequest.new
site_id = '-99'

result = client_controller.client_update_contact_log(version, request, site_id, )
```


# Client Get Cross Regional Client Associations

Returns a list of sites that a particular client ID (also referred to as an RSSID) or a client email address is associated with in a cross-regional organization. Either the `ClientID` or `Email` parameter is required. If both are provided, the `ClientID` is used.

Use this endpoint to retrieve information for other Public API endpoints, about the same client at multiple sites within an organization. To use this endpoint, your developer account must have been granted permission to the site’s entire organization.

Note that this endpoint does not work on the Developer Sandbox site, as it is not set up for cross-regional use cases.

```ruby
def client_get_cross_regional_client_associations(version,
                                                  site_id,
                                                  authorization: nil,
                                                  request_client_id: nil,
                                                  request_email: nil,
                                                  request_limit: nil,
                                                  request_offset: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |
| `request_client_id` | `String` | Query, Optional | Looks up the cross regional associations by the client’s ID. Either `ClientId` or `Email` must be provided. If both are provided, the `ClientId` is used by default. |
| `request_email` | `String` | Query, Optional | Looks up the cross regional associations by the client’s email address. Either `ClientId` or `Email` must be provided. If both are provided, the `ClientId` is used by default. |
| `request_limit` | `Integer` | Query, Optional | Number of results to include, defaults to 100 |
| `request_offset` | `Integer` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetCrossRegionalClientAssociationsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-cross-regional-client-associations-response.md)

## Example Usage

```ruby
version = '6'
site_id = '-99'

result = client_controller.client_get_cross_regional_client_associations(version, site_id, )
```


# Client Add Client

Starting the week of May 11th, 2020 all versions of the Public API will no longer allow duplicate clients to be created. This applies to both adding a client and updating a client record. A duplicate client is created when two profiles have the same first name, last name and email.<br />
Creates a new client record at the specified business.Passing a User Token as Authorization will create a client and respect Business Mode required fields.Omitting the token will create a client and respect Consumer Mode required fi elds. To make sure you are collecting all required pieces of information, first run GetRequired ClientFields.<br />
If you have purchased an Ultimate tier then this endpoint will automatically start showing new opportunity on Sales Pipeline.

```ruby
def client_add_client(version,
                      request,
                      site_id,
                      authorization: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6ClientControllerAddClientRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-add-client-request.md) | Body, Required | The `FirstName` and `LastName` parameters are always required in this request.<br>All other parameters are optional, but note that any of the optional parameters could be required by a particular business,<br>depending on how the business has configured the site settings. If `GetRequiredClientFields` returns `EmergContact` in the list of required fields,<br>then all emergency contact parameters are required, which includes `EmergencyContactInfoEmail`, `EmergencyContactInfoName`, `EmergencyContactInfoPhone`, and `EmergencyContactInfoRelationship`. |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerAddClientResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-add-client-response.md)

## Example Usage

```ruby
version = '6'
request = MindbodyPublicApiDtoModelsV6ClientControllerAddClientRequest.new
request.first_name = 'FirstName8'
request.last_name = 'LastName8'
site_id = '-99'

result = client_controller.client_add_client(version, request, site_id, )
```


# Client Update Client

Starting the week of May 11th, 2020 all versions of the Public API will no longer allow duplicate clients to be created. This applies to both adding a client and updating a client record. A duplicate client is created when two profiles have the same first name, last name and email.<br />
Updates an existing client for a specific subscriber.Passing a User Token as Authorization respects Business Mode required fields.Omitting the token respects Consumer Mode required fields.To make sure you are collecting all required pieces of information, first run GetRequiredClientFields..Use this endpoint as follows:

* If you need to update the `ReferredBy` parameter, use this endpoint after calling `GET ClientReferralTypes`.
* When updating a client’s home location, use after calling `GET Locations`.
* If you are updating a client’s stored credit card, use after calling `GET AcceptedCardTypes` so that you can make sure the card is a type that is accepted at the subscriber.<br />

If this endpoint is used on a cross-regional site, passing in a client’s RSSID and email address creates a cross-regional link. This means that the client is created in cross-regional sites where the client does not exist and `GET CrossRegionalClientAssociations` returns all appropriate cross-regional sites. When `CrossRegionalUpdate` is omitted or set to `true`, the client’s updated information is propagated to all of the region’s sites. If `CrossRegionalUpdate` is set to `false`, only the local client is updated.

Note that the following items cannot be updated for a cross-regional client:

* `ClientIndexes`
* `ClientRelationships`
* `CustomClientFields`
* `SalesReps`
* `SendAccountEmails`
* `SendAccountTexts`
* `SendPromotionalEmails`
* `SendPromotionalTexts`
* `SendScheduleEmails`
* `SendScheduleTexts`
* `Gender` (for site custom values)

Custom client Gender options can only be created with non-cross-regional requests.

If you have purchased an Ultimate tier then this endpoint will automatically start showing a new opportunity on Sales Pipeline.It will create a new opportunity if the current request modify the contact as follows::

* You need to update the `IsProspect` parameter, to `true`.<br />
* You need to update the `ProspectStage`.`Description parameter`, to `New Lead`.<br />

Updates made to any inactive clients will automatically reactivate the client unless the `Acive` property is explicitly set to `false` in the request body.

```ruby
def client_update_client(version,
                         request,
                         site_id,
                         authorization: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-update-client-request.md) | Body, Required | - |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-update-client-response.md)

## Example Usage

```ruby
version = '6'
request = MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientRequest.new
request.client = MindbodyPublicApiDtoModelsV6ClientWithSuspensionInfo.new
site_id = '-99'

result = client_controller.client_update_client(version, request, site_id, )
```


# Client Update Client Visit

Updates the status of the specified visit.

```ruby
def client_update_client_visit(version,
                               request,
                               site_id,
                               authorization: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientVisitRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-update-client-visit-request.md) | Body, Required | - |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientVisitResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-update-client-visit-response.md)

## Example Usage

```ruby
version = '6'
request = MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientVisitRequest.new
request.visit_id = 92
site_id = '-99'

result = client_controller.client_update_client_visit(version, request, site_id, )
```


# Client Add Arrival

Marks a client as arrived for a specified location. A staff user token must be included with staff assigned the LaunchSignInScreen permission.

When used on a site that is part of a region, the following additional logic will apply:

* When a client exists within the region but not at the studio where the arrival is being logged, a local client record will be automatically created.
* If the local client does not have an applicable local membership or pricing option, a membership or pricing option will be automatically used if it exists elsewhere within the region.

```ruby
def client_add_arrival(version,
                       request,
                       site_id,
                       authorization: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6ClientControllerAddArrivalRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-add-arrival-request.md) | Body, Required | - |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerAddArrivalResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-add-arrival-response.md)

## Example Usage

```ruby
version = '6'
request = MindbodyPublicApiDtoModelsV6ClientControllerAddArrivalRequest.new
request.client_id = 'ClientId0'
request.location_id = 238
site_id = '-99'

result = client_controller.client_add_arrival(version, request, site_id, )
```


# Client Send Password Reset Email

Send a password reset email to a client.

```ruby
def client_send_password_reset_email(version,
                                     request,
                                     site_id,
                                     authorization: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6ClientControllerSendPasswordResetEmailRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-send-password-reset-email-request.md) | Body, Required | - |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |

## Response Type

`Object`

## Example Usage

```ruby
version = '6'
request = MindbodyPublicApiDtoModelsV6ClientControllerSendPasswordResetEmailRequest.new
request.user_email = 'UserEmail2'
request.user_first_name = 'UserFirstName2'
request.user_last_name = 'UserLastName8'
site_id = '-99'

result = client_controller.client_send_password_reset_email(version, request, site_id, )
```


# Client Get Contact Logs

This endpoint contains a variety of filters that can return not just all contact logs, but also system-generated contact logs, contact logs assigned to specific staff members, and contact logs of specific types or subtypes.

```ruby
def client_get_contact_logs(version,
                            request_client_id,
                            site_id,
                            authorization: nil,
                            request_end_date: nil,
                            request_limit: nil,
                            request_offset: nil,
                            request_show_system_generated: nil,
                            request_staff_ids: nil,
                            request_start_date: nil,
                            request_subtype_ids: nil,
                            request_type_ids: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `request_client_id` | `String` | Query, Required | The ID of the client whose contact logs are being requested. |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |
| `request_end_date` | `DateTime` | Query, Optional | Filters the results to contact logs created before this date.<br /><br>Default: **the start date** |
| `request_limit` | `Integer` | Query, Optional | Number of results to include, defaults to 100 |
| `request_offset` | `Integer` | Query, Optional | Page offset, defaults to 0. |
| `request_show_system_generated` | `TrueClass\|FalseClass` | Query, Optional | When `true`, system-generated contact logs are returned in the results.<br /><br>Default: **false** |
| `request_staff_ids` | `Array<Integer>` | Query, Optional | Filters the results to return contact logs assigned to one or more staff IDs. |
| `request_start_date` | `DateTime` | Query, Optional | Filters the results to contact logs created on or after this date.<br /><br>Default: **the current date** |
| `request_subtype_ids` | `Array<Integer>` | Query, Optional | Filters the results to contact logs assigned one or more of these subtype IDs. |
| `request_type_ids` | `Array<Integer>` | Query, Optional | Filters the results to contact logs assigned one or more of these type IDs. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetContactLogsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-contact-logs-response.md)

## Example Usage

```ruby
version = '6'
request_client_id = 'request.clientId2'
site_id = '-99'

result = client_controller.client_get_contact_logs(version, request_client_id, site_id, )
```


# Client Update Client Service

Updates the active date and/or expiration date of a client pricing option. This request requires staff user credentials. If the active date is modified, the expiration date is also modified accordingly. If the expiration date is modified, the active date is unchanged.

```ruby
def client_update_client_service(version,
                                 request,
                                 site_id,
                                 authorization: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientServiceRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-update-client-service-request.md) | Body, Required | - |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientServiceResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-update-client-service-response.md)

## Example Usage

```ruby
version = '6'
request = MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientServiceRequest.new
request.service_id = 130
site_id = '-99'

result = client_controller.client_update_client_service(version, request, site_id, )
```


# Client Get Direct Debit Info

This endpoint returns direct debit info stored on a client's account. This endpoint requires staff user credentials.

A null response from this endpoint indicates that the client has no usable direct debit information on their account.Use the POST AddClientDirectDebitInfo endpoint to add direct debit information to a client’s account.

```ruby
def client_get_direct_debit_info(version,
                                 site_id,
                                 authorization: nil,
                                 client_id: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |
| `client_id` | `String` | Query, Optional | The ID of the client. |

## Response Type

[`MindbodyPublicApiDtoModelsV6DirectDebitInfo`](../../doc/models/mindbody-public-api-dto-models-v6-direct-debit-info.md)

## Example Usage

```ruby
version = '6'
site_id = '-99'

result = client_controller.client_get_direct_debit_info(version, site_id, )
```


# Client Delete Direct Debit Info

This endpoint deletes direct debit info from a client’s account. This endpoint requires staff user credentials.

```ruby
def client_delete_direct_debit_info(version,
                                    site_id,
                                    authorization: nil,
                                    client_id: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |
| `client_id` | `String` | Query, Optional | The ID of the client. |

## Response Type

`Object`

## Example Usage

```ruby
version = '6'
site_id = '-99'

result = client_controller.client_delete_direct_debit_info(version, site_id, )
```


# Client Add Client Direct Debit Info

This endpoint adds direct debit info to a client’s account. This endpoint requires staff user credentials.

```ruby
def client_add_client_direct_debit_info(version,
                                        request,
                                        site_id,
                                        authorization: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6ClientControllerAddClientDirectDebitInfoRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-add-client-direct-debit-info-request.md) | Body, Required | - |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerAddClientDirectDebitInfoResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-add-client-direct-debit-info-response.md)

## Example Usage

```ruby
version = '6'
request = MindbodyPublicApiDtoModelsV6ClientControllerAddClientDirectDebitInfoRequest.new
site_id = '-99'

result = client_controller.client_add_client_direct_debit_info(version, request, site_id, )
```


# Client Get Client Rewards

Gets the client rewards.

```ruby
def client_get_client_rewards(version,
                              request_client_id,
                              site_id,
                              authorization: nil,
                              request_end_date: nil,
                              request_limit: nil,
                              request_offset: nil,
                              request_start_date: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `request_client_id` | `String` | Query, Required | The ID of the client. |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |
| `request_end_date` | `DateTime` | Query, Optional | The end date of transaction.<br>Default: **StartDate** |
| `request_limit` | `Integer` | Query, Optional | Number of results to include, defaults to 100 |
| `request_offset` | `Integer` | Query, Optional | Page offset, defaults to 0. |
| `request_start_date` | `DateTime` | Query, Optional | The start date of transaction.<br>Default: **today** |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetClientRewardsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-client-rewards-response.md)

## Example Usage

```ruby
version = '6'
request_client_id = 'request.clientId2'
site_id = '-99'

result = client_controller.client_get_client_rewards(version, request_client_id, site_id, )
```


# Client Update Client Rewards

Earns or redeems rewards points for a given client, based on site settings. Cross regional rewards are not supported at this time.

```ruby
def client_update_client_rewards(version,
                                 request,
                                 site_id,
                                 authorization: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientRewardsRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-update-client-rewards-request.md) | Body, Required | - |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetClientRewardsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-client-rewards-response.md)

## Example Usage

```ruby
version = '6'
request = MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientRewardsRequest.new
request.client_id = 'ClientId0'
request.points = 10
request.action = 'Action6'
site_id = '-99'

result = client_controller.client_update_client_rewards(version, request, site_id, )
```


# Client Get Client Complete Info

This endpoint returns complete client information along with list of purchased services, contract details, membership details and arrival programs for a specific client.

```ruby
def client_get_client_complete_info(version,
                                    request_client_id,
                                    site_id,
                                    authorization: nil,
                                    request_client_associated_sites_offset: nil,
                                    request_cross_regional_lookup: nil,
                                    request_end_date: nil,
                                    request_required_client_data: nil,
                                    request_start_date: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `request_client_id` | `String` | Query, Required | Filters results to client with these ID. |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |
| `request_client_associated_sites_offset` | `Integer` | Query, Optional | Used to retrieve a client’s pricing options from multiple sites within an organization when the client is associated with more than ten sites. To change which ten sites are searched, change this offset value. A value of 0 means that no sites are skipped and the first ten sites are returned. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that you must always have `CrossRegionalLookup` set to `true` to use this parameter.<br /><br>Default: **0**<br><br>For example, if a client is associated with 25 sites, you need to call `GetClientServices` three times, as follows:<br><br>* Use `GET CrossRegionalClientAssociations` to determine how many sites a client is associated with, which tells you how many additional calls you need to make.<br>* Either omit `ClientAssociatedSitesOffset` or set it to 0 to return the client’s services (pricing options) from sites 1-10.<br>* Set `ClientAssociatedSitesOffset` to 10 to return the client pricing options from sites 11-20<br>* Set `ClientAssociatedSitesOffset` to 20 to return the client pricing options from sites 21-25 |
| `request_cross_regional_lookup` | `TrueClass\|FalseClass` | Query, Optional | Used to retrieve a clients pricing options from multiple sites within an organization.When included and set to `true`,<br>it searches a maximum of ten sites with which this client is associated.When a client is associated with more than ten sites, use `ClientAssociatedSitesOffset` as many times as needed to search the additional sites with which the client is associated.<br>You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with.<br>Note that a `SiteID` is returned and populated in the `ClientServices` response when `CrossRegionalLookup` is set to `true`.<br>Default: **false** |
| `request_end_date` | `DateTime` | Query, Optional | Filters results to pricing options that are valid on or before this date. |
| `request_required_client_data` | `Array<String>` | Query, Optional | Used to retrieve list of purchased services, contract details, membership details and arrival programs for a specific client.<br>Default `ClientServices`, `ClientContracts`, `ClientMemberships` and `ClientArrivals` will be returned when `RequiredClientDatais` not set.<br>When `RequiredClientData` is set to `Contracts` then only `ClientContracts` will be returned in the response.<br>When `RequiredClientData` is set to Services then only `ClientServices` will be returned in the response.<br>When `RequiredClientData` is set to `Memberships` then only `ClientMemberships` will be returned in the response.<br>When `RequiredClientData` is set to `ArrivalPrograms` then only `ClientArrivals` will be returned in the response. |
| `request_start_date` | `DateTime` | Query, Optional | Filters results to pricing options that are valid on or after this date. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetClientCompleteInfoResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-client-complete-info-response.md)

## Example Usage

```ruby
version = '6'
request_client_id = 'request.clientId2'
site_id = '-99'

result = client_controller.client_get_client_complete_info(version, request_client_id, site_id, )
```


# Client Get Contact Log Types

This endpoint contains a variety of filters that can return not just all contact logs, but also system-generated contact logs, contact logs assigned to specific staff members, and contact logs of specific types or subtypes.

```ruby
def client_get_contact_log_types(version,
                                 site_id,
                                 authorization: nil,
                                 request_contact_log_type_id: nil,
                                 request_limit: nil,
                                 request_offset: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |
| `request_contact_log_type_id` | `Integer` | Query, Optional | The requested ContactLogType ID.<br>Default: **all** IDs that the authenticated user’s access level allows. |
| `request_limit` | `Integer` | Query, Optional | Number of results to include, defaults to 100 |
| `request_offset` | `Integer` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetContactLogTypesResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-contact-log-types-response.md)

## Example Usage

```ruby
version = '6'
site_id = '-99'

result = client_controller.client_get_contact_log_types(version, site_id, )
```


# Client Delete Contact Log

This endpoint deletes contactlog of client. This endpoint requires staff user credentials.

```ruby
def client_delete_contact_log(version,
                              request_client_id,
                              request_contact_log_id,
                              site_id,
                              authorization: nil,
                              request_test: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `request_client_id` | `String` | Query, Required | The client ID of the client whose Contact Log is being deleted. |
| `request_contact_log_id` | `Integer` | Query, Required | The Contact Log ID. |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |
| `request_test` | `TrueClass\|FalseClass` | Query, Optional | When `true`, indicates that this is a test request and no data is inserted into the subscriber’s database.<br>When `false`, the database is updated. |

## Response Type

`Object`

## Example Usage

```ruby
version = '6'
request_client_id = 'request.clientId2'
request_contact_log_id = 90
site_id = '-99'

result = client_controller.client_delete_contact_log(version, request_client_id, request_contact_log_id, site_id, )
```


# Client Send Auto Email

This endpoint requires staff user credentials.

```ruby
def client_send_auto_email(version,
                           request,
                           site_id,
                           authorization: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6ClientControllerSendAutoEmailRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-send-auto-email-request.md) | Body, Required | - |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |

## Response Type

`Object`

## Example Usage

```ruby
version = '6'
request = MindbodyPublicApiDtoModelsV6ClientControllerSendAutoEmailRequest.new
request.client_id = 'ClientId0'
request.email_type = 'EmailType4'
site_id = '-99'

result = client_controller.client_send_auto_email(version, request, site_id, )
```


# Client Get Active Clients Memberships

The endpoint returns a list of memberships for multiple clients we pass in query parameter. Please note that clients memberships with location restrictions can only be used to pay for scheduled services at the site to which they belong. Memberships with location restrictions can not be used to pay for scheduled services at other sites within an organization.

```ruby
def client_get_active_clients_memberships(version,
                                          request_client_ids,
                                          site_id,
                                          authorization: nil,
                                          request_client_associated_sites_offset: nil,
                                          request_cross_regional_lookup: nil,
                                          request_limit: nil,
                                          request_location_id: nil,
                                          request_offset: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `request_client_ids` | `Array<String>` | Query, Required | The ID of the client for whom memberships are returned. Maximum allowed : 200. |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |
| `request_client_associated_sites_offset` | `Integer` | Query, Optional | Used to retrieve a client’s memberships from multiple sites within an organization when the client is associated with more than ten sites. To change which ten sites are searched, change this offset value. A value of 0 means that no sites are skipped and the first ten sites are returned. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that you must always have `CrossRegionalLookup` set to `true` to use this parameter.<br /><br>Default: **0**<br><br>For example, if a client is associated with 25 sites, you need to call `GetClientServices` three times, as follows:<br><br>* Use `GET CrossRegionalClientAssociations` to determine how many sites a client is associated with, which tells you how many additional calls you need to make.<br>* Either omit `ClientAssociatedSitesOffset` or set it to 0 to return the client’s services (pricing options) from sites 1-10.<br>* Set `ClientAssociatedSitesOffset` to 10 to return the client pricing options from sites 11-20<br>* Set `ClientAssociatedSitesOffset` to 20 to return the client pricing options from sites 21-25 |
| `request_cross_regional_lookup` | `TrueClass\|FalseClass` | Query, Optional | Used to retrieve a client’s memberships from multiple sites within an organization. When included and set to `true`, it searches a maximum of ten sites with which this client is associated. When a client is associated with more than ten sites, use `ClientAssociatedSitesOffset` as many times as needed to search the additional sites with which the client is associated. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that a `SiteID` is returned and populated in the `ClientServices` response when `CrossRegionalLookup` is set to `true`.<br>Default: **false** |
| `request_limit` | `Integer` | Query, Optional | Number of results to include, defaults to 100 |
| `request_location_id` | `Integer` | Query, Optional | Filters results to memberships that can be used to pay for scheduled services at that location. This parameter can not be passed when `CrossRegionalLookup` is `true`. |
| `request_offset` | `Integer` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetActiveClientsMembershipsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-active-clients-memberships-response.md)

## Example Usage

```ruby
version = '6'
request_client_ids = ['request.clientIds9', 'request.clientIds0', 'request.clientIds1']
site_id = '-99'

result = client_controller.client_get_active_clients_memberships(version, request_client_ids, site_id, )
```


# Client Terminate Contract

This endpoint terminates a client contract. This endpoint requires staff user credentials with TerminateClientContract permission.

```ruby
def client_terminate_contract(version,
                              request,
                              site_id,
                              authorization: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6ClientControllerTerminateContractRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-terminate-contract-request.md) | Body, Required | - |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerTerminateContractResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-terminate-contract-response.md)

## Example Usage

```ruby
version = '6'
request = MindbodyPublicApiDtoModelsV6ClientControllerTerminateContractRequest.new
request.client_id = 'ClientId0'
request.client_contract_id = 118
request.termination_date = DateTimeHelper.from_rfc3339('2016-03-13T12:52:32.123Z')
site_id = '-99'

result = client_controller.client_terminate_contract(version, request, site_id, )
```


# Client Update Client Contract Autopays

```ruby
def client_update_client_contract_autopays(version,
                                           request,
                                           site_id,
                                           authorization: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6SaleControllerUpdateClientContractAutopaysRequest`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-update-client-contract-autopays-request.md) | Body, Required | - |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6Contract`](../../doc/models/mindbody-public-api-dto-models-v6-contract.md)

## Example Usage

```ruby
version = '6'
request = MindbodyPublicApiDtoModelsV6SaleControllerUpdateClientContractAutopaysRequest.new
site_id = '-99'

result = client_controller.client_update_client_contract_autopays(version, request, site_id, )
```


# Client Suspend Contract

Suspend client contract

```ruby
def client_suspend_contract(version,
                            request,
                            site_id,
                            authorization: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6ClientControllerSuspendContractRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-suspend-contract-request.md) | Body, Required | - |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerSuspendContractResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-suspend-contract-response.md)

## Example Usage

```ruby
version = '6'
request = MindbodyPublicApiDtoModelsV6ClientControllerSuspendContractRequest.new
request.client_id = 'ClientId0'
request.client_contract_id = 118
site_id = '-99'

result = client_controller.client_suspend_contract(version, request, site_id, )
```


# Client Merge Client

```ruby
def client_merge_client(version,
                        request,
                        site_id,
                        authorization: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6ClientControllerMergeClientsRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-merge-clients-request.md) | Body, Required | - |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |

## Response Type

`Object`

## Example Usage

```ruby
version = '6'
request = MindbodyPublicApiDtoModelsV6ClientControllerMergeClientsRequest.new
site_id = '-99'

result = client_controller.client_merge_client(version, request, site_id, )
```

