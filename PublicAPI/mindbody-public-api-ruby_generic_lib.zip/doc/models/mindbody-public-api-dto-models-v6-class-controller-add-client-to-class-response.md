
# Mindbody Public Api Dto Models V6 Class Controller Add Client to Class Response

## Structure

`MindbodyPublicApiDtoModelsV6ClassControllerAddClientToClassResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `visit` | [`MindbodyPublicApiDtoModelsV6ExtensionModelsAddClientToClassVisit`](../../doc/models/mindbody-public-api-dto-models-v6-extension-models-add-client-to-class-visit.md) | Optional | - |

## Example (as JSON)

```json
{
  "Visit": null
}
```

