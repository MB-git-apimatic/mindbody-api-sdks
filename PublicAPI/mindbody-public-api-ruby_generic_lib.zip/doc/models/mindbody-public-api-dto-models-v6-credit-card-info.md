
# Mindbody Public Api Dto Models V6 Credit Card Info

INformation about an individual credit card

## Structure

`MindbodyPublicApiDtoModelsV6CreditCardInfo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `credit_card_number` | `String` | Optional | - |
| `exp_month` | `String` | Optional | - |
| `exp_year` | `String` | Optional | - |
| `billing_name` | `String` | Optional | - |
| `billing_address` | `String` | Optional | - |
| `billing_city` | `String` | Optional | - |
| `billing_state` | `String` | Optional | - |
| `billing_postal_code` | `String` | Optional | - |
| `save_info` | `TrueClass\|FalseClass` | Optional | - |
| `card_id` | `String` | Optional | Card Id of a stored instruments card |

## Example (as JSON)

```json
{
  "CreditCardNumber": null,
  "ExpMonth": null,
  "ExpYear": null,
  "BillingName": null,
  "BillingAddress": null,
  "BillingCity": null,
  "BillingState": null,
  "BillingPostalCode": null,
  "SaveInfo": null,
  "CardId": null
}
```

