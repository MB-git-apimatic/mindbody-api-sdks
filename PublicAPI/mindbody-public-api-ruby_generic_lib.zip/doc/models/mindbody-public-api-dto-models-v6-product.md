
# Mindbody Public Api Dto Models V6 Product

## Structure

`MindbodyPublicApiDtoModelsV6Product`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `product_id` | `Integer` | Optional | A ProductID of the product. |
| `id` | `String` | Optional | The unique ID of the product variant, for example, a particular size and color combination. |
| `category_id` | `Integer` | Optional | A CategoryID of the product. |
| `sub_category_id` | `Integer` | Optional | A SubCategoryID of the product. |
| `price` | `Float` | Optional | The price of the product. |
| `tax_included` | `Float` | Optional | If tax inclusive-pricing is enabled, this field shows how much tax was added to the price. |
| `tax_rate` | `Float` | Optional | The tax rate that was applied to this purchase. |
| `group_id` | `Integer` | Optional | The unique ID of the product group. |
| `name` | `String` | Optional | The name of the product. |
| `online_price` | `Float` | Optional | The online price of the product. |
| `short_description` | `String` | Optional | A short description of the product. |
| `long_description` | `String` | Optional | A longer description of the product. |
| `type_group` | `Integer` | Optional | A TypeGroup of the product. |
| `supplier_id` | `Integer` | Optional | A SupplierID of the product. |
| `supplier_name` | `String` | Optional | A Supplier name of the product. |
| `image_url` | `String` | Optional | - |
| `color` | [`MindbodyPublicApiDtoModelsV6Color`](../../doc/models/mindbody-public-api-dto-models-v6-color.md) | Optional | A color used by products. |
| `size` | [`MindbodyPublicApiDtoModelsV6Size`](../../doc/models/mindbody-public-api-dto-models-v6-size.md) | Optional | - |
| `manufacturer_id` | `String` | Optional | The ManufacturerId of the product. |

## Example (as JSON)

```json
{
  "ProductId": null,
  "Id": null,
  "CategoryId": null,
  "SubCategoryId": null,
  "Price": null,
  "TaxIncluded": null,
  "TaxRate": null,
  "GroupId": null,
  "Name": null,
  "OnlinePrice": null,
  "ShortDescription": null,
  "LongDescription": null,
  "TypeGroup": null,
  "SupplierId": null,
  "SupplierName": null,
  "ImageURL": null,
  "Color": null,
  "Size": null,
  "ManufacturerId": null
}
```

