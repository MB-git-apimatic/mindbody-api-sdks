
# Mindbody Public Api Dto Models V6 Package

## Structure

`MindbodyPublicApiDtoModelsV6Package`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Optional | The ID of the package. |
| `name` | `String` | Optional | The name of the package. |
| `discount_percentage` | `Float` | Optional | The discount percentage applied to the package. |
| `sell_online` | `TrueClass\|FalseClass` | Optional | When `true`, only products that can be sold online are returned.<br /><br>When `false`, all products are returned. |
| `services` | [`Array<MindbodyPublicApiDtoModelsV6Service>`](../../doc/models/mindbody-public-api-dto-models-v6-service.md) | Optional | Information about the services in the packages. |
| `products` | [`Array<MindbodyPublicApiDtoModelsV6Product>`](../../doc/models/mindbody-public-api-dto-models-v6-product.md) | Optional | Information about the products in the packages. |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null,
  "DiscountPercentage": null,
  "SellOnline": null,
  "Services": null,
  "Products": null
}
```

