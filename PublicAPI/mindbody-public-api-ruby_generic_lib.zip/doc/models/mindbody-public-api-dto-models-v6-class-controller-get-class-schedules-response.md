
# Mindbody Public Api Dto Models V6 Class Controller Get Class Schedules Response

## Structure

`MindbodyPublicApiDtoModelsV6ClassControllerGetClassSchedulesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | Contains information about the pagination to use. |
| `class_schedules` | [`Array<MindbodyPublicApiDtoModelsV6ClassSchedule>`](../../doc/models/mindbody-public-api-dto-models-v6-class-schedule.md) | Optional | Contains information about the class schedules. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "ClassSchedules": null
}
```

