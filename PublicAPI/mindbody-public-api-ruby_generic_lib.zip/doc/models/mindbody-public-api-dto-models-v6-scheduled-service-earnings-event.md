
# Mindbody Public Api Dto Models V6 Scheduled Service Earnings Event

## Structure

`MindbodyPublicApiDtoModelsV6ScheduledServiceEarningsEvent`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `staff_id` | `Integer` | Optional | The ID of the staff member who taught the class. |
| `scheduled_service_id` | `Integer` | Optional | The class' ID. |
| `scheduled_service_type` | [`ScheduledServiceTypeEnum`](../../doc/models/scheduled-service-type-enum.md) | Optional | The type of the scheduled service; i.e, a class, appointment, or enrollment. |
| `earnings` | `Float` | Optional | The total monetary amount the staff is to be paid for this class. |
| `date_time` | `DateTime` | Optional | - |

## Example (as JSON)

```json
{
  "StaffId": null,
  "ScheduledServiceId": null,
  "ScheduledServiceType": null,
  "Earnings": null,
  "DateTime": null
}
```

