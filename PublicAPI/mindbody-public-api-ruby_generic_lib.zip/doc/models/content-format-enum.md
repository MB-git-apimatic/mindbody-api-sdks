
# Content Format Enum

## Enumeration

`ContentFormatEnum`

## Fields

| Name |
|  --- |
| `INPERSON` |
| `MINDBODY` |
| `OTHER` |

