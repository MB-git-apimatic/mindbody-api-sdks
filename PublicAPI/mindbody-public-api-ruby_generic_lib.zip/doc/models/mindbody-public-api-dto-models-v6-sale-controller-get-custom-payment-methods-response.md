
# Mindbody Public Api Dto Models V6 Sale Controller Get Custom Payment Methods Response

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerGetCustomPaymentMethodsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | Contains information about the pagination to use. |
| `payment_methods` | [`Array<MindbodyPublicApiDtoModelsV6CustomPaymentMethod>`](../../doc/models/mindbody-public-api-dto-models-v6-custom-payment-method.md) | Optional | Contains information about the custom payment methods. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "PaymentMethods": null
}
```

