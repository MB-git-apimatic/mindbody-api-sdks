
# Mindbody Public Api Dto Models V6 Client Controller Get Client Indexes Response

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerGetClientIndexesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `client_indexes` | [`Array<MindbodyPublicApiDtoModelsV6ClientIndex>`](../../doc/models/mindbody-public-api-dto-models-v6-client-index.md) | Optional | Contains information about the client indexes. |

## Example (as JSON)

```json
{
  "ClientIndexes": null
}
```

