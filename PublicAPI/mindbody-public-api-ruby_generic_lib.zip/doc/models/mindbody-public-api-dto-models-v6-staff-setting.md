
# Mindbody Public Api Dto Models V6 Staff Setting

## Structure

`MindbodyPublicApiDtoModelsV6StaffSetting`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `use_staff_nicknames` | `TrueClass\|FalseClass` | Optional | - |
| `show_staff_last_names_on_schedules` | `TrueClass\|FalseClass` | Optional | - |

## Example (as JSON)

```json
{
  "UseStaffNicknames": null,
  "ShowStaffLastNamesOnSchedules": null
}
```

