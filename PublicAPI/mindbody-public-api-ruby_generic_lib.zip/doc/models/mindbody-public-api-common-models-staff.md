
# Mindbody Public Api Common Models Staff

## Structure

`MindbodyPublicApiCommonModelsStaff`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Optional | - |
| `first_name` | `String` | Optional | - |
| `last_name` | `String` | Optional | - |
| `display_name` | `String` | Optional | - |
| `email` | `String` | Optional | - |
| `bio` | `String` | Optional | - |
| `address` | `String` | Optional | - |
| `address_2` | `String` | Optional | - |
| `city` | `String` | Optional | - |
| `state` | `String` | Optional | - |
| `postal_code` | `String` | Optional | - |
| `foreign_zip` | `String` | Optional | - |
| `country` | `String` | Optional | - |
| `work_phone` | `String` | Optional | - |
| `home_phone` | `String` | Optional | - |
| `cell_phone` | `String` | Optional | - |
| `active` | `TrueClass\|FalseClass` | Optional | - |
| `is_system` | `TrueClass\|FalseClass` | Optional | - |
| `smode_id` | `Integer` | Optional | - |
| `appointment_trn` | `TrueClass\|FalseClass` | Optional | - |
| `always_allow_double_booking` | `TrueClass\|FalseClass` | Optional | - |
| `independent_contractor` | `TrueClass\|FalseClass` | Optional | - |
| `image_url` | `String` | Optional | - |
| `is_male` | `TrueClass\|FalseClass` | Optional | - |
| `reservation_trn` | `TrueClass\|FalseClass` | Optional | - |
| `sort_order` | `Integer` | Optional | - |
| `multi_location_permission` | `TrueClass\|FalseClass` | Optional | - |
| `name` | `String` | Optional | - |
| `provider_i_ds` | `Array<String>` | Optional | - |
| `staff_settings` | [`MindbodyPublicApiCommonModelsStaffSetting`](../../doc/models/mindbody-public-api-common-models-staff-setting.md) | Optional | - |
| `rep` | `TrueClass\|FalseClass` | Optional | - |
| `rep_2` | `TrueClass\|FalseClass` | Optional | - |
| `rep_3` | `TrueClass\|FalseClass` | Optional | - |
| `rep_4` | `TrueClass\|FalseClass` | Optional | - |
| `rep_5` | `TrueClass\|FalseClass` | Optional | - |
| `rep_6` | `TrueClass\|FalseClass` | Optional | - |
| `assistant` | `TrueClass\|FalseClass` | Optional | - |
| `assistant_2` | `TrueClass\|FalseClass` | Optional | - |
| `employment_start` | `DateTime` | Optional | - |
| `employment_end` | `DateTime` | Optional | - |
| `emp_id` | `String` | Optional | - |
| `appointments` | [`Array<MindbodyPublicApiCommonModelsAppointment>`](../../doc/models/mindbody-public-api-common-models-appointment.md) | Optional | List of appointments for the staff. |
| `unavailabilities` | [`Array<MindbodyPublicApiCommonModelsUnavailability>`](../../doc/models/mindbody-public-api-common-models-unavailability.md) | Optional | List of unavailabilities for the staff. |
| `availabilities` | [`Array<MindbodyPublicApiCommonModelsAvailability>`](../../doc/models/mindbody-public-api-common-models-availability.md) | Optional | List of availabilities for the staff. |
| `login_locations` | [`Array<MindbodyPublicApiCommonModelsLocation>`](../../doc/models/mindbody-public-api-common-models-location.md) | Optional | - |

## Example (as JSON)

```json
{
  "Id": null,
  "FirstName": null,
  "LastName": null,
  "DisplayName": null,
  "Email": null,
  "Bio": null,
  "Address": null,
  "Address2": null,
  "City": null,
  "State": null,
  "PostalCode": null,
  "ForeignZip": null,
  "Country": null,
  "WorkPhone": null,
  "HomePhone": null,
  "CellPhone": null,
  "Active": null,
  "IsSystem": null,
  "SmodeId": null,
  "AppointmentTrn": null,
  "AlwaysAllowDoubleBooking": null,
  "IndependentContractor": null,
  "ImageUrl": null,
  "IsMale": null,
  "ReservationTrn": null,
  "SortOrder": null,
  "MultiLocationPermission": null,
  "Name": null,
  "ProviderIDs": null,
  "StaffSettings": null,
  "Rep": null,
  "Rep2": null,
  "Rep3": null,
  "Rep4": null,
  "Rep5": null,
  "Rep6": null,
  "Assistant": null,
  "Assistant2": null,
  "EmploymentStart": null,
  "EmploymentEnd": null,
  "EmpID": null,
  "Appointments": null,
  "Unavailabilities": null,
  "Availabilities": null,
  "LoginLocations": null
}
```

