
# Mindbody Public Api Dto Models V6 Client Index

A client index.

## Structure

`MindbodyPublicApiDtoModelsV6ClientIndex`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Optional | The unique ID of the client index. |
| `name` | `String` | Optional | The name of the client index. |
| `required_business_mode` | `TrueClass\|FalseClass` | Optional | When `true`, indicates that the index is required when creating profiles in business mode. |
| `required_consumer_mode` | `TrueClass\|FalseClass` | Optional | When `true`, indicates that the index is required when creating profiles in consumer mode. |
| `values` | [`Array<MindbodyPublicApiDtoModelsV6ClientIndexValue>`](../../doc/models/mindbody-public-api-dto-models-v6-client-index-value.md) | Optional | Contains information about the index's possible values. |
| `action` | [`Action7Enum`](../../doc/models/action-7-enum.md) | Optional | The action performed on this object. |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null,
  "RequiredBusinessMode": null,
  "RequiredConsumerMode": null,
  "Values": null,
  "Action": null
}
```

