
# Mindbody Public Api Dto Models V6 Service

## Structure

`MindbodyPublicApiDtoModelsV6Service`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `price` | `Float` | Optional | The cost of the pricing option when sold at a physical location. |
| `online_price` | `Float` | Optional | The cost of the pricing option when sold online. |
| `tax_included` | `Float` | Optional | The amount of tax included in the price, if inclusive pricing is enabled. |
| `program_id` | `Integer` | Optional | The ID of the program that this pricing option applies to. |
| `tax_rate` | `Float` | Optional | The tax rate applied to the pricing option. This field is populated only when you include a `LocationID` in the request. |
| `product_id` | `Integer` | Optional | The unique ID of the pricing option. |
| `id` | `String` | Optional | The barcode ID of the pricing option. |
| `name` | `String` | Optional | The name of the pricing option. |
| `count` | `Integer` | Optional | The initial count of usages available for the pricing option. |
| `sell_online` | `TrueClass\|FalseClass` | Optional | A flag for whether or not the pricing option is sold online. |
| `sale_in_contract_only` | `TrueClass\|FalseClass` | Optional | A flag for whether or not the pricing option is contractonly. |
| `type` | `String` | Optional | Indicates if the pricing option is a drop-in, series, or unlimiited. |
| `expiration_type` | `String` | Optional | Indicates if the pricing option begins its activation on the date of sale or first usage. |
| `expiration_unit` | `String` | Optional | The unit, either days or months, of ExpirationLength. |
| `expiration_length` | `Integer` | Optional | The lifetime of a pricing option. |
| `revenue_category` | `String` | Optional | The revenue category of the pricing option. |
| `membership_id` | `Integer` | Optional | The ID that this pricing option grants membership to. |
| `sell_at_location_ids` | `Array<Integer>` | Optional | The location IDs where this pricing option is sold. |
| `use_at_location_ids` | `Array<Integer>` | Optional | The location IDs where this pricing option may be used. |
| `priority` | `String` | Optional | The priority of the pricing option. |
| `is_intro_offer` | `TrueClass\|FalseClass` | Optional | A flag that indicates if this pricing option is an introductory offer. |
| `intro_offer_type` | `String` | Optional | Indicates if this pricing option may be purchased to new clients or all clients. |
| `is_third_party_discount_pricing` | `TrueClass\|FalseClass` | Optional | A flag that indicates if this pricing option involves a third party discount |
| `program` | `String` | Optional | The name of the program corresponding to ProgramId. |
| `discontinued` | `TrueClass\|FalseClass` | Optional | Whether this pricing option has been discontinued or not |

## Example (as JSON)

```json
{
  "Price": null,
  "OnlinePrice": null,
  "TaxIncluded": null,
  "ProgramId": null,
  "TaxRate": null,
  "ProductId": null,
  "Id": null,
  "Name": null,
  "Count": null,
  "SellOnline": null,
  "SaleInContractOnly": null,
  "Type": null,
  "ExpirationType": null,
  "ExpirationUnit": null,
  "ExpirationLength": null,
  "RevenueCategory": null,
  "MembershipId": null,
  "SellAtLocationIds": null,
  "UseAtLocationIds": null,
  "Priority": null,
  "IsIntroOffer": null,
  "IntroOfferType": null,
  "IsThirdPartyDiscountPricing": null,
  "Program": null,
  "Discontinued": null
}
```

