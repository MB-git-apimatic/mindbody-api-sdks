
# Mindbody Public Api Dto Models V6 Gender Option

A gender option available at a site

## Structure

`MindbodyPublicApiDtoModelsV6GenderOption`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Optional | The id of the gender option |
| `name` | `String` | Optional | The name of the gender option |
| `is_active` | `TrueClass\|FalseClass` | Optional | Whether the gender option is active and can be assigned to a consumer profile |
| `is_default` | `TrueClass\|FalseClass` | Optional | Whether the gender option is the default value applied to a consumer profile |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null,
  "IsActive": null,
  "IsDefault": null
}
```

