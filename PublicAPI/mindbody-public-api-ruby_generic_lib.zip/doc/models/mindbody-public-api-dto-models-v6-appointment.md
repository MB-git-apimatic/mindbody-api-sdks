
# Mindbody Public Api Dto Models V6 Appointment

Contains information about an appointment.

## Structure

`MindbodyPublicApiDtoModelsV6Appointment`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `gender_preference` | [`GenderPreferenceEnum`](../../doc/models/gender-preference-enum.md) | Optional | The preferred gender of the appointment provider. |
| `duration` | `Integer` | Optional | The duration of the appointment. |
| `provider_id` | `String` | Optional | If a user has Complementary and Alternative Medicine features enabled, this property indicates the provider assigned to the appointment. |
| `id` | `Integer` | Optional | The unique ID of the appointment. |
| `status` | [`StatusEnum`](../../doc/models/status-enum.md) | Optional | The status of this appointment. |
| `start_date_time` | `DateTime` | Optional | The date and time the appointment is to start. |
| `end_date_time` | `DateTime` | Optional | The date and time the appointment is to end. |
| `notes` | `String` | Optional | Any notes associated with the appointment. |
| `partner_external_id` | `String` | Optional | Optional external key for api partners. |
| `staff_requested` | `TrueClass\|FalseClass` | Optional | When `true`, indicates that the staff member was requested specifically by the client. |
| `program_id` | `Integer` | Optional | The ID of the program to which this appointment belongs. |
| `session_type_id` | `Integer` | Optional | The ID of the session type of this appointment. |
| `location_id` | `Integer` | Optional | The ID of the location where this appointment is to take place. |
| `staff_id` | `Integer` | Optional | The ID of the staff member providing the service for this appointment. |
| `client_id` | `String` | Optional | The RSSID of the client who is booked for this appointment. |
| `first_appointment` | `TrueClass\|FalseClass` | Optional | When `true`, indicates that this is the client’s first appointment at this site. |
| `is_waitlist` | `TrueClass\|FalseClass` | Optional | Whether to add appointment to waitlist. |
| `waitlist_entry_id` | `Integer` | Optional | ID of the appointment waitlist. |
| `client_service_id` | `Integer` | Optional | The ID of the pass on the client’s account that is to pay for this appointment. |
| `resources` | [`Array<MindbodyPublicApiDtoModelsV6Resource>`](../../doc/models/mindbody-public-api-dto-models-v6-resource.md) | Optional | The resources this appointment is to use. |
| `add_ons` | [`Array<MindbodyPublicApiDtoModelsV6AddOnSmall>`](../../doc/models/mindbody-public-api-dto-models-v6-add-on-small.md) | Optional | Any AddOns associated with the appointment |
| `online_description` | `String` | Optional | Online Description associated with the appointment |

## Example (as JSON)

```json
{
  "GenderPreference": null,
  "Duration": null,
  "ProviderId": null,
  "Id": null,
  "Status": null,
  "StartDateTime": null,
  "EndDateTime": null,
  "Notes": null,
  "PartnerExternalId": null,
  "StaffRequested": null,
  "ProgramId": null,
  "SessionTypeId": null,
  "LocationId": null,
  "StaffId": null,
  "ClientId": null,
  "FirstAppointment": null,
  "IsWaitlist": null,
  "WaitlistEntryId": null,
  "ClientServiceId": null,
  "Resources": null,
  "AddOns": null,
  "OnlineDescription": null
}
```

