
# Mindbody Public Api Dto Models V6 Sale Controller Get Contracts Response

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerGetContractsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | Contains information about the pagination to use. |
| `contracts` | [`Array<MindbodyPublicApiDtoModelsV6Contract>`](../../doc/models/mindbody-public-api-dto-models-v6-contract.md) | Optional | Contains information about each contract. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Contracts": null
}
```

