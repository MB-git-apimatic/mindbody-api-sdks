// <copyright file="ICustomHeaderAuthenticationCredentials.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Authentication
{
    using System;

    public interface ICustomHeaderAuthenticationCredentials
    {
        /// <summary>
        /// Gets string value for aPIKey.
        /// </summary>
        string APIKey { get; }

        /// <summary>
        ///  Returns true if credentials matched.
        /// </summary>
        /// <param name="aPIKey"> The string value for credentials.</param>
        /// <returns>True if credentials matched.</returns>
        bool Equals(string aPIKey);
    }
}