// <copyright file="EnrollmentController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Authentication;
    using MINDBODYPublicAPI.Standard.Http.Client;
    using MINDBODYPublicAPI.Standard.Http.Request;
    using MINDBODYPublicAPI.Standard.Http.Request.Configuration;
    using MINDBODYPublicAPI.Standard.Http.Response;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// EnrollmentController.
    /// </summary>
    public class EnrollmentController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="EnrollmentController"/> class.
        /// </summary>
        /// <param name="config"> config instance. </param>
        /// <param name="httpClient"> httpClient. </param>
        /// <param name="authManagers"> authManager. </param>
        internal EnrollmentController(IConfiguration config, IHttpClient httpClient, IDictionary<string, IAuthManager> authManagers)
            : base(config, httpClient, authManagers)
        {
        }

        /// <summary>
        /// Book a client into an enrollment.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClassSchedule response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6ClassSchedule EnrollmentAddClientToEnrollment(
                string version,
                Models.MindbodyPublicApiDtoModelsV6ClassControllerAddClientToEnrollmentRequest request,
                string siteId,
                string authorization = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6ClassSchedule> t = this.EnrollmentAddClientToEnrollmentAsync(version, request, siteId, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Book a client into an enrollment.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClassSchedule response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6ClassSchedule> EnrollmentAddClientToEnrollmentAsync(
                string version,
                Models.MindbodyPublicApiDtoModelsV6ClassControllerAddClientToEnrollmentRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/enrollment/addclienttoenrollment");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "Content-Type", "application/json" },
                { "authorization", authorization },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(request);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6ClassSchedule>(response.Body);
        }

        /// <summary>
        /// Returns a list of enrollments. An enrollment is a service, such as a workshop or an event, that a staff member offers to multiple students, who commit to coming to all or most of the scheduled sessions. Enrollments typically run for a limited time only.
        ///             .
        /// When a user token is not passed with the request or the passed user token has insufficient viewing permissions, only the following staff data is returned in the response:.
        ///             .
        /// * FirstName.
        /// * LastName.
        /// * Id.
        /// * Bio.
        /// * DisplayName.
        /// * ImageUrl.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClassScheduleIds">Optional parameter: A list of the requested class schedule IDs. If omitted, all class schedule IDs return..</param>
        /// <param name="requestEndDate">Optional parameter: The end of the date range. The response returns any active enrollments that occur on or before this day.<br />  Default: **StartDate**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationIds">Optional parameter: List of the IDs for the requested locations. If omitted, all location IDs return..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestProgramIds">Optional parameter: List of the IDs for the requested programs. If omitted, all program IDs return..</param>
        /// <param name="requestSessionTypeIds">Optional parameter: List of the IDs for the requested session types. If omitted, all session types IDs return..</param>
        /// <param name="requestStaffIds">Optional parameter: List of the IDs for the requested staff IDs. If omitted, all staff IDs return..</param>
        /// <param name="requestStartDate">Optional parameter: The start of the date range. The response returns any active enrollments that occur on or after this day.<br />  Default: **today’s date**.</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClassControllerGetEnrollmentsResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6ClassControllerGetEnrollmentsResponse EnrollmentGetEnrollments(
                string version,
                string siteId,
                string authorization = null,
                List<int> requestClassScheduleIds = null,
                DateTime? requestEndDate = null,
                int? requestLimit = null,
                List<int> requestLocationIds = null,
                int? requestOffset = null,
                List<int> requestProgramIds = null,
                List<int> requestSessionTypeIds = null,
                List<long> requestStaffIds = null,
                DateTime? requestStartDate = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6ClassControllerGetEnrollmentsResponse> t = this.EnrollmentGetEnrollmentsAsync(version, siteId, authorization, requestClassScheduleIds, requestEndDate, requestLimit, requestLocationIds, requestOffset, requestProgramIds, requestSessionTypeIds, requestStaffIds, requestStartDate);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Returns a list of enrollments. An enrollment is a service, such as a workshop or an event, that a staff member offers to multiple students, who commit to coming to all or most of the scheduled sessions. Enrollments typically run for a limited time only.
        ///             .
        /// When a user token is not passed with the request or the passed user token has insufficient viewing permissions, only the following staff data is returned in the response:.
        ///             .
        /// * FirstName.
        /// * LastName.
        /// * Id.
        /// * Bio.
        /// * DisplayName.
        /// * ImageUrl.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClassScheduleIds">Optional parameter: A list of the requested class schedule IDs. If omitted, all class schedule IDs return..</param>
        /// <param name="requestEndDate">Optional parameter: The end of the date range. The response returns any active enrollments that occur on or before this day.<br />  Default: **StartDate**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationIds">Optional parameter: List of the IDs for the requested locations. If omitted, all location IDs return..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestProgramIds">Optional parameter: List of the IDs for the requested programs. If omitted, all program IDs return..</param>
        /// <param name="requestSessionTypeIds">Optional parameter: List of the IDs for the requested session types. If omitted, all session types IDs return..</param>
        /// <param name="requestStaffIds">Optional parameter: List of the IDs for the requested staff IDs. If omitted, all staff IDs return..</param>
        /// <param name="requestStartDate">Optional parameter: The start of the date range. The response returns any active enrollments that occur on or after this day.<br />  Default: **today’s date**.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClassControllerGetEnrollmentsResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6ClassControllerGetEnrollmentsResponse> EnrollmentGetEnrollmentsAsync(
                string version,
                string siteId,
                string authorization = null,
                List<int> requestClassScheduleIds = null,
                DateTime? requestEndDate = null,
                int? requestLimit = null,
                List<int> requestLocationIds = null,
                int? requestOffset = null,
                List<int> requestProgramIds = null,
                List<int> requestSessionTypeIds = null,
                List<long> requestStaffIds = null,
                DateTime? requestStartDate = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/enrollment/enrollments");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "request.classScheduleIds", requestClassScheduleIds },
                { "request.endDate", requestEndDate.HasValue ? requestEndDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null },
                { "request.limit", requestLimit },
                { "request.locationIds", requestLocationIds },
                { "request.offset", requestOffset },
                { "request.programIds", requestProgramIds },
                { "request.sessionTypeIds", requestSessionTypeIds },
                { "request.staffIds", requestStaffIds },
                { "request.startDate", requestStartDate.HasValue ? requestStartDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6ClassControllerGetEnrollmentsResponse>(response.Body);
        }

        /// <summary>
        /// This endpoint adds a enrollment schedule. You can require clients to sign up for the entire enrollment schedule or allow them to pick specific sessions using the AllowOpenEnrollment parameter.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDataModelsWrittenClassSchedulesInfo response from the API call.</returns>
        public Models.MindbodyPublicApiDataModelsWrittenClassSchedulesInfo EnrollmentAddEnrollmentSchedule(
                string version,
                Models.MindbodyPublicApiDtoModelsV6AddClassEnrollmentScheduleRequest request,
                string siteId,
                string authorization = null)
        {
            Task<Models.MindbodyPublicApiDataModelsWrittenClassSchedulesInfo> t = this.EnrollmentAddEnrollmentScheduleAsync(version, request, siteId, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// This endpoint adds a enrollment schedule. You can require clients to sign up for the entire enrollment schedule or allow them to pick specific sessions using the AllowOpenEnrollment parameter.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDataModelsWrittenClassSchedulesInfo response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDataModelsWrittenClassSchedulesInfo> EnrollmentAddEnrollmentScheduleAsync(
                string version,
                Models.MindbodyPublicApiDtoModelsV6AddClassEnrollmentScheduleRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/enrollment/addenrollmentschedule");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "Content-Type", "application/json" },
                { "authorization", authorization },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(request);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDataModelsWrittenClassSchedulesInfo>(response.Body);
        }

        /// <summary>
        /// Enrollment_UpdateEnrollmentSchedule EndPoint.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the object response from the API call.</returns>
        public object EnrollmentUpdateEnrollmentSchedule(
                string version,
                Models.MindbodyPublicApiDtoModelsV6UpdateClassEnrollmentScheduleRequest request,
                string siteId,
                string authorization = null)
        {
            Task<object> t = this.EnrollmentUpdateEnrollmentScheduleAsync(version, request, siteId, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Enrollment_UpdateEnrollmentSchedule EndPoint.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the object response from the API call.</returns>
        public async Task<object> EnrollmentUpdateEnrollmentScheduleAsync(
                string version,
                Models.MindbodyPublicApiDtoModelsV6UpdateClassEnrollmentScheduleRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/enrollment/updateenrollmentschedule");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "Content-Type", "application/json" },
                { "authorization", authorization },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(request);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return response.Body;
        }
    }
}