// <copyright file="MindbodyPublicApiDtoModelsV6ClientMembership.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiDtoModelsV6ClientMembership.
    /// </summary>
    public class MindbodyPublicApiDtoModelsV6ClientMembership
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClientMembership"/> class.
        /// </summary>
        public MindbodyPublicApiDtoModelsV6ClientMembership()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClientMembership"/> class.
        /// </summary>
        /// <param name="restrictedLocations">RestrictedLocations.</param>
        /// <param name="iconCode">IconCode.</param>
        /// <param name="membershipId">MembershipId.</param>
        /// <param name="activeDate">ActiveDate.</param>
        /// <param name="count">Count.</param>
        /// <param name="current">Current.</param>
        /// <param name="expirationDate">ExpirationDate.</param>
        /// <param name="id">Id.</param>
        /// <param name="productId">ProductId.</param>
        /// <param name="name">Name.</param>
        /// <param name="paymentDate">PaymentDate.</param>
        /// <param name="program">Program.</param>
        /// <param name="remaining">Remaining.</param>
        /// <param name="siteId">SiteId.</param>
        /// <param name="action">Action.</param>
        public MindbodyPublicApiDtoModelsV6ClientMembership(
            List<Models.MindbodyPublicApiDtoModelsV6Location> restrictedLocations = null,
            string iconCode = null,
            int? membershipId = null,
            DateTime? activeDate = null,
            int? count = null,
            bool? current = null,
            DateTime? expirationDate = null,
            long? id = null,
            int? productId = null,
            string name = null,
            DateTime? paymentDate = null,
            Models.MindbodyPublicApiDtoModelsV6Program program = null,
            int? remaining = null,
            int? siteId = null,
            Models.Action1Enum? action = null)
        {
            this.RestrictedLocations = restrictedLocations;
            this.IconCode = iconCode;
            this.MembershipId = membershipId;
            this.ActiveDate = activeDate;
            this.Count = count;
            this.Current = current;
            this.ExpirationDate = expirationDate;
            this.Id = id;
            this.ProductId = productId;
            this.Name = name;
            this.PaymentDate = paymentDate;
            this.Program = program;
            this.Remaining = remaining;
            this.SiteId = siteId;
            this.Action = action;
        }

        /// <summary>
        /// The locations that the membership is restricted to, if any.
        /// Please note that client memberships with location restrictions can only be used to pay for scheduled services at the site to which they belong. Memberships with location restrictions can not be used to pay for scheduled services at other sites within an organization.
        /// </summary>
        [JsonProperty("RestrictedLocations", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.MindbodyPublicApiDtoModelsV6Location> RestrictedLocations { get; set; }

        /// <summary>
        /// Text code that represents the `MembershipIcon`.
        /// </summary>
        [JsonProperty("IconCode", NullValueHandling = NullValueHandling.Ignore)]
        public string IconCode { get; set; }

        /// <summary>
        /// The membership's ID.
        /// </summary>
        [JsonProperty("MembershipId", NullValueHandling = NullValueHandling.Ignore)]
        public int? MembershipId { get; set; }

        /// <summary>
        /// The date that this pricing option became active and could be used to pay for services.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("ActiveDate", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? ActiveDate { get; set; }

        /// <summary>
        /// The number of service sessions this pricing option contained when first purchased.
        /// </summary>
        [JsonProperty("Count", NullValueHandling = NullValueHandling.Ignore)]
        public int? Count { get; set; }

        /// <summary>
        /// When `true`, there are service sessions remaining on the pricing option that can be used pay for the current session.<br />
        /// When `false`, the client cannot use this pricing option to pay for other services.
        /// </summary>
        [JsonProperty("Current", NullValueHandling = NullValueHandling.Ignore)]
        public bool? Current { get; set; }

        /// <summary>
        /// The date when the pricing option expires and can no longer be used to pay for services, even if unused service sessions remain on the option; expressed as UTC.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("ExpirationDate", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? ExpirationDate { get; set; }

        /// <summary>
        /// The unique ID assigned to this pricing option, specific to when it was purchased by the client.
        /// </summary>
        [JsonProperty("Id", NullValueHandling = NullValueHandling.Ignore)]
        public long? Id { get; set; }

        /// <summary>
        /// The unique ID of this pricing option, not specific to any client's purchase of it.
        /// </summary>
        [JsonProperty("ProductId", NullValueHandling = NullValueHandling.Ignore)]
        public int? ProductId { get; set; }

        /// <summary>
        /// The name of this pricing option.
        /// </summary>
        [JsonProperty("Name", NullValueHandling = NullValueHandling.Ignore)]
        public string Name { get; set; }

        /// <summary>
        /// The date on which the client paid for this pricing option.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("PaymentDate", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? PaymentDate { get; set; }

        /// <summary>
        /// Gets or sets Program.
        /// </summary>
        [JsonProperty("Program", NullValueHandling = NullValueHandling.Ignore)]
        public Models.MindbodyPublicApiDtoModelsV6Program Program { get; set; }

        /// <summary>
        /// The number of service sessions remaining in the pricing option that can still be used.
        /// </summary>
        [JsonProperty("Remaining", NullValueHandling = NullValueHandling.Ignore)]
        public int? Remaining { get; set; }

        /// <summary>
        /// The ID of the subscriber site associated with this pricing option.
        /// </summary>
        [JsonProperty("SiteId", NullValueHandling = NullValueHandling.Ignore)]
        public int? SiteId { get; set; }

        /// <summary>
        /// The action taken.
        /// </summary>
        [JsonProperty("Action", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.Action1Enum? Action { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiDtoModelsV6ClientMembership : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiDtoModelsV6ClientMembership other &&
                ((this.RestrictedLocations == null && other.RestrictedLocations == null) || (this.RestrictedLocations?.Equals(other.RestrictedLocations) == true)) &&
                ((this.IconCode == null && other.IconCode == null) || (this.IconCode?.Equals(other.IconCode) == true)) &&
                ((this.MembershipId == null && other.MembershipId == null) || (this.MembershipId?.Equals(other.MembershipId) == true)) &&
                ((this.ActiveDate == null && other.ActiveDate == null) || (this.ActiveDate?.Equals(other.ActiveDate) == true)) &&
                ((this.Count == null && other.Count == null) || (this.Count?.Equals(other.Count) == true)) &&
                ((this.Current == null && other.Current == null) || (this.Current?.Equals(other.Current) == true)) &&
                ((this.ExpirationDate == null && other.ExpirationDate == null) || (this.ExpirationDate?.Equals(other.ExpirationDate) == true)) &&
                ((this.Id == null && other.Id == null) || (this.Id?.Equals(other.Id) == true)) &&
                ((this.ProductId == null && other.ProductId == null) || (this.ProductId?.Equals(other.ProductId) == true)) &&
                ((this.Name == null && other.Name == null) || (this.Name?.Equals(other.Name) == true)) &&
                ((this.PaymentDate == null && other.PaymentDate == null) || (this.PaymentDate?.Equals(other.PaymentDate) == true)) &&
                ((this.Program == null && other.Program == null) || (this.Program?.Equals(other.Program) == true)) &&
                ((this.Remaining == null && other.Remaining == null) || (this.Remaining?.Equals(other.Remaining) == true)) &&
                ((this.SiteId == null && other.SiteId == null) || (this.SiteId?.Equals(other.SiteId) == true)) &&
                ((this.Action == null && other.Action == null) || (this.Action?.Equals(other.Action) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.RestrictedLocations = {(this.RestrictedLocations == null ? "null" : $"[{string.Join(", ", this.RestrictedLocations)} ]")}");
            toStringOutput.Add($"this.IconCode = {(this.IconCode == null ? "null" : this.IconCode == string.Empty ? "" : this.IconCode)}");
            toStringOutput.Add($"this.MembershipId = {(this.MembershipId == null ? "null" : this.MembershipId.ToString())}");
            toStringOutput.Add($"this.ActiveDate = {(this.ActiveDate == null ? "null" : this.ActiveDate.ToString())}");
            toStringOutput.Add($"this.Count = {(this.Count == null ? "null" : this.Count.ToString())}");
            toStringOutput.Add($"this.Current = {(this.Current == null ? "null" : this.Current.ToString())}");
            toStringOutput.Add($"this.ExpirationDate = {(this.ExpirationDate == null ? "null" : this.ExpirationDate.ToString())}");
            toStringOutput.Add($"this.Id = {(this.Id == null ? "null" : this.Id.ToString())}");
            toStringOutput.Add($"this.ProductId = {(this.ProductId == null ? "null" : this.ProductId.ToString())}");
            toStringOutput.Add($"this.Name = {(this.Name == null ? "null" : this.Name == string.Empty ? "" : this.Name)}");
            toStringOutput.Add($"this.PaymentDate = {(this.PaymentDate == null ? "null" : this.PaymentDate.ToString())}");
            toStringOutput.Add($"this.Program = {(this.Program == null ? "null" : this.Program.ToString())}");
            toStringOutput.Add($"this.Remaining = {(this.Remaining == null ? "null" : this.Remaining.ToString())}");
            toStringOutput.Add($"this.SiteId = {(this.SiteId == null ? "null" : this.SiteId.ToString())}");
            toStringOutput.Add($"this.Action = {(this.Action == null ? "null" : this.Action.ToString())}");
        }
    }
}