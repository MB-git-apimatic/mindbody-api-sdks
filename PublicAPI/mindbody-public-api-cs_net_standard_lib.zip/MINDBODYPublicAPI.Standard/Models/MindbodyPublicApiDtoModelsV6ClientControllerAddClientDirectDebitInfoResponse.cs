// <copyright file="MindbodyPublicApiDtoModelsV6ClientControllerAddClientDirectDebitInfoResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiDtoModelsV6ClientControllerAddClientDirectDebitInfoResponse.
    /// </summary>
    public class MindbodyPublicApiDtoModelsV6ClientControllerAddClientDirectDebitInfoResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClientControllerAddClientDirectDebitInfoResponse"/> class.
        /// </summary>
        public MindbodyPublicApiDtoModelsV6ClientControllerAddClientDirectDebitInfoResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClientControllerAddClientDirectDebitInfoResponse"/> class.
        /// </summary>
        /// <param name="clientId">ClientId.</param>
        /// <param name="nameOnAccount">NameOnAccount.</param>
        /// <param name="routingNumber">RoutingNumber.</param>
        /// <param name="accountNumber">AccountNumber.</param>
        /// <param name="accountType">AccountType.</param>
        public MindbodyPublicApiDtoModelsV6ClientControllerAddClientDirectDebitInfoResponse(
            string clientId = null,
            string nameOnAccount = null,
            string routingNumber = null,
            string accountNumber = null,
            string accountType = null)
        {
            this.ClientId = clientId;
            this.NameOnAccount = nameOnAccount;
            this.RoutingNumber = routingNumber;
            this.AccountNumber = accountNumber;
            this.AccountType = accountType;
        }

        /// <summary>
        /// The ID of the client being updated
        /// </summary>
        [JsonProperty("ClientId", NullValueHandling = NullValueHandling.Ignore)]
        public string ClientId { get; set; }

        /// <summary>
        /// The name on the bank account being added
        /// </summary>
        [JsonProperty("NameOnAccount", NullValueHandling = NullValueHandling.Ignore)]
        public string NameOnAccount { get; set; }

        /// <summary>
        /// The routing number of the bank account being added
        /// </summary>
        [JsonProperty("RoutingNumber", NullValueHandling = NullValueHandling.Ignore)]
        public string RoutingNumber { get; set; }

        /// <summary>
        /// The bank account number
        /// </summary>
        [JsonProperty("AccountNumber", NullValueHandling = NullValueHandling.Ignore)]
        public string AccountNumber { get; set; }

        /// <summary>
        /// The account type.
        /// Possible values:
        /// * Checking
        /// * Savings
        /// </summary>
        [JsonProperty("AccountType", NullValueHandling = NullValueHandling.Ignore)]
        public string AccountType { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiDtoModelsV6ClientControllerAddClientDirectDebitInfoResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiDtoModelsV6ClientControllerAddClientDirectDebitInfoResponse other &&
                ((this.ClientId == null && other.ClientId == null) || (this.ClientId?.Equals(other.ClientId) == true)) &&
                ((this.NameOnAccount == null && other.NameOnAccount == null) || (this.NameOnAccount?.Equals(other.NameOnAccount) == true)) &&
                ((this.RoutingNumber == null && other.RoutingNumber == null) || (this.RoutingNumber?.Equals(other.RoutingNumber) == true)) &&
                ((this.AccountNumber == null && other.AccountNumber == null) || (this.AccountNumber?.Equals(other.AccountNumber) == true)) &&
                ((this.AccountType == null && other.AccountType == null) || (this.AccountType?.Equals(other.AccountType) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ClientId = {(this.ClientId == null ? "null" : this.ClientId == string.Empty ? "" : this.ClientId)}");
            toStringOutput.Add($"this.NameOnAccount = {(this.NameOnAccount == null ? "null" : this.NameOnAccount == string.Empty ? "" : this.NameOnAccount)}");
            toStringOutput.Add($"this.RoutingNumber = {(this.RoutingNumber == null ? "null" : this.RoutingNumber == string.Empty ? "" : this.RoutingNumber)}");
            toStringOutput.Add($"this.AccountNumber = {(this.AccountNumber == null ? "null" : this.AccountNumber == string.Empty ? "" : this.AccountNumber)}");
            toStringOutput.Add($"this.AccountType = {(this.AccountType == null ? "null" : this.AccountType == string.Empty ? "" : this.AccountType)}");
        }
    }
}