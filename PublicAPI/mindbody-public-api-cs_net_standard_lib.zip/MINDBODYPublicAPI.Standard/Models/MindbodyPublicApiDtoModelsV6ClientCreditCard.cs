// <copyright file="MindbodyPublicApiDtoModelsV6ClientCreditCard.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiDtoModelsV6ClientCreditCard.
    /// </summary>
    public class MindbodyPublicApiDtoModelsV6ClientCreditCard
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClientCreditCard"/> class.
        /// </summary>
        public MindbodyPublicApiDtoModelsV6ClientCreditCard()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClientCreditCard"/> class.
        /// </summary>
        /// <param name="address">Address.</param>
        /// <param name="cardHolder">CardHolder.</param>
        /// <param name="cardNumber">CardNumber.</param>
        /// <param name="cardType">CardType.</param>
        /// <param name="city">City.</param>
        /// <param name="expMonth">ExpMonth.</param>
        /// <param name="expYear">ExpYear.</param>
        /// <param name="lastFour">LastFour.</param>
        /// <param name="postalCode">PostalCode.</param>
        /// <param name="state">State.</param>
        public MindbodyPublicApiDtoModelsV6ClientCreditCard(
            string address = null,
            string cardHolder = null,
            string cardNumber = null,
            string cardType = null,
            string city = null,
            string expMonth = null,
            string expYear = null,
            string lastFour = null,
            string postalCode = null,
            string state = null)
        {
            this.Address = address;
            this.CardHolder = cardHolder;
            this.CardNumber = cardNumber;
            this.CardType = cardType;
            this.City = city;
            this.ExpMonth = expMonth;
            this.ExpYear = expYear;
            this.LastFour = lastFour;
            this.PostalCode = postalCode;
            this.State = state;
        }

        /// <summary>
        /// The billing address for the credit card.
        /// </summary>
        [JsonProperty("Address", NullValueHandling = NullValueHandling.Ignore)]
        public string Address { get; set; }

        /// <summary>
        /// The name of the card holder.
        /// </summary>
        [JsonProperty("CardHolder", NullValueHandling = NullValueHandling.Ignore)]
        public string CardHolder { get; set; }

        /// <summary>
        /// The credit card number.
        /// </summary>
        [JsonProperty("CardNumber", NullValueHandling = NullValueHandling.Ignore)]
        public string CardNumber { get; set; }

        /// <summary>
        /// The type of credit card, for example Visa or MasterCard.
        /// </summary>
        [JsonProperty("CardType", NullValueHandling = NullValueHandling.Ignore)]
        public string CardType { get; set; }

        /// <summary>
        /// The city in which the billing address is located.
        /// </summary>
        [JsonProperty("City", NullValueHandling = NullValueHandling.Ignore)]
        public string City { get; set; }

        /// <summary>
        /// The month in which the credit card expires.
        /// </summary>
        [JsonProperty("ExpMonth", NullValueHandling = NullValueHandling.Ignore)]
        public string ExpMonth { get; set; }

        /// <summary>
        /// The year in which the credit card expires.
        /// </summary>
        [JsonProperty("ExpYear", NullValueHandling = NullValueHandling.Ignore)]
        public string ExpYear { get; set; }

        /// <summary>
        /// The last four digits of the credit card number.
        /// </summary>
        [JsonProperty("LastFour", NullValueHandling = NullValueHandling.Ignore)]
        public string LastFour { get; set; }

        /// <summary>
        /// The postal code where the billing address is located.
        /// </summary>
        [JsonProperty("PostalCode", NullValueHandling = NullValueHandling.Ignore)]
        public string PostalCode { get; set; }

        /// <summary>
        /// The state that the billing address is located in.
        /// </summary>
        [JsonProperty("State", NullValueHandling = NullValueHandling.Ignore)]
        public string State { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiDtoModelsV6ClientCreditCard : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiDtoModelsV6ClientCreditCard other &&
                ((this.Address == null && other.Address == null) || (this.Address?.Equals(other.Address) == true)) &&
                ((this.CardHolder == null && other.CardHolder == null) || (this.CardHolder?.Equals(other.CardHolder) == true)) &&
                ((this.CardNumber == null && other.CardNumber == null) || (this.CardNumber?.Equals(other.CardNumber) == true)) &&
                ((this.CardType == null && other.CardType == null) || (this.CardType?.Equals(other.CardType) == true)) &&
                ((this.City == null && other.City == null) || (this.City?.Equals(other.City) == true)) &&
                ((this.ExpMonth == null && other.ExpMonth == null) || (this.ExpMonth?.Equals(other.ExpMonth) == true)) &&
                ((this.ExpYear == null && other.ExpYear == null) || (this.ExpYear?.Equals(other.ExpYear) == true)) &&
                ((this.LastFour == null && other.LastFour == null) || (this.LastFour?.Equals(other.LastFour) == true)) &&
                ((this.PostalCode == null && other.PostalCode == null) || (this.PostalCode?.Equals(other.PostalCode) == true)) &&
                ((this.State == null && other.State == null) || (this.State?.Equals(other.State) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Address = {(this.Address == null ? "null" : this.Address == string.Empty ? "" : this.Address)}");
            toStringOutput.Add($"this.CardHolder = {(this.CardHolder == null ? "null" : this.CardHolder == string.Empty ? "" : this.CardHolder)}");
            toStringOutput.Add($"this.CardNumber = {(this.CardNumber == null ? "null" : this.CardNumber == string.Empty ? "" : this.CardNumber)}");
            toStringOutput.Add($"this.CardType = {(this.CardType == null ? "null" : this.CardType == string.Empty ? "" : this.CardType)}");
            toStringOutput.Add($"this.City = {(this.City == null ? "null" : this.City == string.Empty ? "" : this.City)}");
            toStringOutput.Add($"this.ExpMonth = {(this.ExpMonth == null ? "null" : this.ExpMonth == string.Empty ? "" : this.ExpMonth)}");
            toStringOutput.Add($"this.ExpYear = {(this.ExpYear == null ? "null" : this.ExpYear == string.Empty ? "" : this.ExpYear)}");
            toStringOutput.Add($"this.LastFour = {(this.LastFour == null ? "null" : this.LastFour == string.Empty ? "" : this.LastFour)}");
            toStringOutput.Add($"this.PostalCode = {(this.PostalCode == null ? "null" : this.PostalCode == string.Empty ? "" : this.PostalCode)}");
            toStringOutput.Add($"this.State = {(this.State == null ? "null" : this.State == string.Empty ? "" : this.State)}");
        }
    }
}