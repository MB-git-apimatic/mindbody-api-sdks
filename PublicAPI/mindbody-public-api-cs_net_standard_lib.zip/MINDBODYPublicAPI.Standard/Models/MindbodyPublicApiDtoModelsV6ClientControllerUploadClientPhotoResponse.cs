// <copyright file="MindbodyPublicApiDtoModelsV6ClientControllerUploadClientPhotoResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiDtoModelsV6ClientControllerUploadClientPhotoResponse.
    /// </summary>
    public class MindbodyPublicApiDtoModelsV6ClientControllerUploadClientPhotoResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClientControllerUploadClientPhotoResponse"/> class.
        /// </summary>
        public MindbodyPublicApiDtoModelsV6ClientControllerUploadClientPhotoResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClientControllerUploadClientPhotoResponse"/> class.
        /// </summary>
        /// <param name="clientId">ClientId.</param>
        /// <param name="photoUrl">PhotoUrl.</param>
        public MindbodyPublicApiDtoModelsV6ClientControllerUploadClientPhotoResponse(
            string clientId = null,
            string photoUrl = null)
        {
            this.ClientId = clientId;
            this.PhotoUrl = photoUrl;
        }

        /// <summary>
        /// The RSSID of the client for whom the photo was uploaded.
        /// </summary>
        [JsonProperty("ClientId", NullValueHandling = NullValueHandling.Ignore)]
        public string ClientId { get; set; }

        /// <summary>
        /// The URL of the uploaded photo.
        /// </summary>
        [JsonProperty("PhotoUrl", NullValueHandling = NullValueHandling.Ignore)]
        public string PhotoUrl { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiDtoModelsV6ClientControllerUploadClientPhotoResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiDtoModelsV6ClientControllerUploadClientPhotoResponse other &&
                ((this.ClientId == null && other.ClientId == null) || (this.ClientId?.Equals(other.ClientId) == true)) &&
                ((this.PhotoUrl == null && other.PhotoUrl == null) || (this.PhotoUrl?.Equals(other.PhotoUrl) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ClientId = {(this.ClientId == null ? "null" : this.ClientId == string.Empty ? "" : this.ClientId)}");
            toStringOutput.Add($"this.PhotoUrl = {(this.PhotoUrl == null ? "null" : this.PhotoUrl == string.Empty ? "" : this.PhotoUrl)}");
        }
    }
}