// <copyright file="MindbodyPublicApiDtoModelsV6ClassControllerClassClientDetail.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiDtoModelsV6ClassControllerClassClientDetail.
    /// </summary>
    public class MindbodyPublicApiDtoModelsV6ClassControllerClassClientDetail
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClassControllerClassClientDetail"/> class.
        /// </summary>
        public MindbodyPublicApiDtoModelsV6ClassControllerClassClientDetail()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClassControllerClassClientDetail"/> class.
        /// </summary>
        /// <param name="clientIds">ClientIds.</param>
        /// <param name="classId">ClassId.</param>
        public MindbodyPublicApiDtoModelsV6ClassControllerClassClientDetail(
            List<string> clientIds,
            int classId)
        {
            this.ClientIds = clientIds;
            this.ClassId = classId;
        }

        /// <summary>
        /// The RSSID of the clients to remove from the specified classes.
        /// </summary>
        [JsonProperty("ClientIds")]
        public List<string> ClientIds { get; set; }

        /// <summary>
        /// The ID of the classes that you want to remove the clients from.
        /// </summary>
        [JsonProperty("ClassId")]
        public int ClassId { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiDtoModelsV6ClassControllerClassClientDetail : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiDtoModelsV6ClassControllerClassClientDetail other &&
                ((this.ClientIds == null && other.ClientIds == null) || (this.ClientIds?.Equals(other.ClientIds) == true)) &&
                this.ClassId.Equals(other.ClassId);
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ClientIds = {(this.ClientIds == null ? "null" : $"[{string.Join(", ", this.ClientIds)} ]")}");
            toStringOutput.Add($"this.ClassId = {this.ClassId}");
        }
    }
}