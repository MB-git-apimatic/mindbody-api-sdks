// <copyright file="MindbodyPublicApiCommonModelsStaffSetting.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiCommonModelsStaffSetting.
    /// </summary>
    public class MindbodyPublicApiCommonModelsStaffSetting
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiCommonModelsStaffSetting"/> class.
        /// </summary>
        public MindbodyPublicApiCommonModelsStaffSetting()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiCommonModelsStaffSetting"/> class.
        /// </summary>
        /// <param name="useStaffNicknames">UseStaffNicknames.</param>
        /// <param name="showStaffLastNamesOnSchedules">ShowStaffLastNamesOnSchedules.</param>
        public MindbodyPublicApiCommonModelsStaffSetting(
            bool? useStaffNicknames = null,
            bool? showStaffLastNamesOnSchedules = null)
        {
            this.UseStaffNicknames = useStaffNicknames;
            this.ShowStaffLastNamesOnSchedules = showStaffLastNamesOnSchedules;
        }

        /// <summary>
        /// Gets or sets UseStaffNicknames.
        /// </summary>
        [JsonProperty("UseStaffNicknames", NullValueHandling = NullValueHandling.Ignore)]
        public bool? UseStaffNicknames { get; set; }

        /// <summary>
        /// Gets or sets ShowStaffLastNamesOnSchedules.
        /// </summary>
        [JsonProperty("ShowStaffLastNamesOnSchedules", NullValueHandling = NullValueHandling.Ignore)]
        public bool? ShowStaffLastNamesOnSchedules { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiCommonModelsStaffSetting : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiCommonModelsStaffSetting other &&
                ((this.UseStaffNicknames == null && other.UseStaffNicknames == null) || (this.UseStaffNicknames?.Equals(other.UseStaffNicknames) == true)) &&
                ((this.ShowStaffLastNamesOnSchedules == null && other.ShowStaffLastNamesOnSchedules == null) || (this.ShowStaffLastNamesOnSchedules?.Equals(other.ShowStaffLastNamesOnSchedules) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.UseStaffNicknames = {(this.UseStaffNicknames == null ? "null" : this.UseStaffNicknames.ToString())}");
            toStringOutput.Add($"this.ShowStaffLastNamesOnSchedules = {(this.ShowStaffLastNamesOnSchedules == null ? "null" : this.ShowStaffLastNamesOnSchedules.ToString())}");
        }
    }
}