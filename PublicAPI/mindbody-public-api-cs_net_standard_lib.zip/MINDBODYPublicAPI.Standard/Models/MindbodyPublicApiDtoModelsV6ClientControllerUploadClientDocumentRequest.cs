// <copyright file="MindbodyPublicApiDtoModelsV6ClientControllerUploadClientDocumentRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiDtoModelsV6ClientControllerUploadClientDocumentRequest.
    /// </summary>
    public class MindbodyPublicApiDtoModelsV6ClientControllerUploadClientDocumentRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClientControllerUploadClientDocumentRequest"/> class.
        /// </summary>
        public MindbodyPublicApiDtoModelsV6ClientControllerUploadClientDocumentRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClientControllerUploadClientDocumentRequest"/> class.
        /// </summary>
        /// <param name="clientId">ClientId.</param>
        /// <param name="file">File.</param>
        public MindbodyPublicApiDtoModelsV6ClientControllerUploadClientDocumentRequest(
            string clientId,
            Models.MindbodyPublicApiDtoModelsV6ClientDocument file)
        {
            this.ClientId = clientId;
            this.File = file;
        }

        /// <summary>
        /// The RSSID of the client for whom the document is to be uploaded.
        /// </summary>
        [JsonProperty("ClientId")]
        public string ClientId { get; set; }

        /// <summary>
        /// Gets or sets File.
        /// </summary>
        [JsonProperty("File")]
        public Models.MindbodyPublicApiDtoModelsV6ClientDocument File { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiDtoModelsV6ClientControllerUploadClientDocumentRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiDtoModelsV6ClientControllerUploadClientDocumentRequest other &&
                ((this.ClientId == null && other.ClientId == null) || (this.ClientId?.Equals(other.ClientId) == true)) &&
                ((this.File == null && other.File == null) || (this.File?.Equals(other.File) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ClientId = {(this.ClientId == null ? "null" : this.ClientId == string.Empty ? "" : this.ClientId)}");
            toStringOutput.Add($"this.File = {(this.File == null ? "null" : this.File.ToString())}");
        }
    }
}