// <copyright file="MindbodyPublicApiCommonModelsSessionType.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiCommonModelsSessionType.
    /// </summary>
    public class MindbodyPublicApiCommonModelsSessionType
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiCommonModelsSessionType"/> class.
        /// </summary>
        public MindbodyPublicApiCommonModelsSessionType()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiCommonModelsSessionType"/> class.
        /// </summary>
        /// <param name="type">Type.</param>
        /// <param name="defaultTimeLength">DefaultTimeLength.</param>
        /// <param name="staffTimeLength">StaffTimeLength.</param>
        /// <param name="programId">ProgramId.</param>
        /// <param name="numDeducted">NumDeducted.</param>
        /// <param name="id">Id.</param>
        /// <param name="name">Name.</param>
        /// <param name="active">Active.</param>
        /// <param name="capacity">Capacity.</param>
        /// <param name="resourceRequired">ResourceRequired.</param>
        /// <param name="category">Category.</param>
        /// <param name="subcategory">Subcategory.</param>
        /// <param name="onlineDescription">OnlineDescription.</param>
        public MindbodyPublicApiCommonModelsSessionType(
            Models.Type1Enum? type = null,
            int? defaultTimeLength = null,
            int? staffTimeLength = null,
            int? programId = null,
            int? numDeducted = null,
            int? id = null,
            string name = null,
            bool? active = null,
            int? capacity = null,
            bool? resourceRequired = null,
            Models.MindbodyPublicApiCommonModelsServiceTag category = null,
            Models.MindbodyPublicApiCommonModelsServiceTag subcategory = null,
            string onlineDescription = null)
        {
            this.Type = type;
            this.DefaultTimeLength = defaultTimeLength;
            this.StaffTimeLength = staffTimeLength;
            this.ProgramId = programId;
            this.NumDeducted = numDeducted;
            this.Id = id;
            this.Name = name;
            this.Active = active;
            this.Capacity = capacity;
            this.ResourceRequired = resourceRequired;
            this.Category = category;
            this.Subcategory = subcategory;
            this.OnlineDescription = onlineDescription;
        }

        /// <summary>
        /// Gets or sets Type.
        /// </summary>
        [JsonProperty("Type", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.Type1Enum? Type { get; set; }

        /// <summary>
        /// Gets or sets DefaultTimeLength.
        /// </summary>
        [JsonProperty("DefaultTimeLength", NullValueHandling = NullValueHandling.Ignore)]
        public int? DefaultTimeLength { get; set; }

        /// <summary>
        /// Gets or sets StaffTimeLength.
        /// </summary>
        [JsonProperty("StaffTimeLength", NullValueHandling = NullValueHandling.Ignore)]
        public int? StaffTimeLength { get; set; }

        /// <summary>
        /// Gets or sets ProgramId.
        /// </summary>
        [JsonProperty("ProgramId", NullValueHandling = NullValueHandling.Ignore)]
        public int? ProgramId { get; set; }

        /// <summary>
        /// Gets or sets NumDeducted.
        /// </summary>
        [JsonProperty("NumDeducted", NullValueHandling = NullValueHandling.Ignore)]
        public int? NumDeducted { get; set; }

        /// <summary>
        /// Gets or sets Id.
        /// </summary>
        [JsonProperty("Id", NullValueHandling = NullValueHandling.Ignore)]
        public int? Id { get; set; }

        /// <summary>
        /// Gets or sets Name.
        /// </summary>
        [JsonProperty("Name", NullValueHandling = NullValueHandling.Ignore)]
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets Active.
        /// </summary>
        [JsonProperty("Active", NullValueHandling = NullValueHandling.Ignore)]
        public bool? Active { get; set; }

        /// <summary>
        /// Gets or sets Capacity.
        /// </summary>
        [JsonProperty("Capacity", NullValueHandling = NullValueHandling.Ignore)]
        public int? Capacity { get; set; }

        /// <summary>
        /// Gets or sets ResourceRequired.
        /// </summary>
        [JsonProperty("ResourceRequired", NullValueHandling = NullValueHandling.Ignore)]
        public bool? ResourceRequired { get; set; }

        /// <summary>
        /// ServiceTag refers to Category and Subcategory fields for classes and appointments
        /// </summary>
        [JsonProperty("Category", NullValueHandling = NullValueHandling.Ignore)]
        public Models.MindbodyPublicApiCommonModelsServiceTag Category { get; set; }

        /// <summary>
        /// ServiceTag refers to Category and Subcategory fields for classes and appointments
        /// </summary>
        [JsonProperty("Subcategory", NullValueHandling = NullValueHandling.Ignore)]
        public Models.MindbodyPublicApiCommonModelsServiceTag Subcategory { get; set; }

        /// <summary>
        /// Gets or sets OnlineDescription.
        /// </summary>
        [JsonProperty("OnlineDescription", NullValueHandling = NullValueHandling.Ignore)]
        public string OnlineDescription { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiCommonModelsSessionType : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiCommonModelsSessionType other &&
                ((this.Type == null && other.Type == null) || (this.Type?.Equals(other.Type) == true)) &&
                ((this.DefaultTimeLength == null && other.DefaultTimeLength == null) || (this.DefaultTimeLength?.Equals(other.DefaultTimeLength) == true)) &&
                ((this.StaffTimeLength == null && other.StaffTimeLength == null) || (this.StaffTimeLength?.Equals(other.StaffTimeLength) == true)) &&
                ((this.ProgramId == null && other.ProgramId == null) || (this.ProgramId?.Equals(other.ProgramId) == true)) &&
                ((this.NumDeducted == null && other.NumDeducted == null) || (this.NumDeducted?.Equals(other.NumDeducted) == true)) &&
                ((this.Id == null && other.Id == null) || (this.Id?.Equals(other.Id) == true)) &&
                ((this.Name == null && other.Name == null) || (this.Name?.Equals(other.Name) == true)) &&
                ((this.Active == null && other.Active == null) || (this.Active?.Equals(other.Active) == true)) &&
                ((this.Capacity == null && other.Capacity == null) || (this.Capacity?.Equals(other.Capacity) == true)) &&
                ((this.ResourceRequired == null && other.ResourceRequired == null) || (this.ResourceRequired?.Equals(other.ResourceRequired) == true)) &&
                ((this.Category == null && other.Category == null) || (this.Category?.Equals(other.Category) == true)) &&
                ((this.Subcategory == null && other.Subcategory == null) || (this.Subcategory?.Equals(other.Subcategory) == true)) &&
                ((this.OnlineDescription == null && other.OnlineDescription == null) || (this.OnlineDescription?.Equals(other.OnlineDescription) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Type = {(this.Type == null ? "null" : this.Type.ToString())}");
            toStringOutput.Add($"this.DefaultTimeLength = {(this.DefaultTimeLength == null ? "null" : this.DefaultTimeLength.ToString())}");
            toStringOutput.Add($"this.StaffTimeLength = {(this.StaffTimeLength == null ? "null" : this.StaffTimeLength.ToString())}");
            toStringOutput.Add($"this.ProgramId = {(this.ProgramId == null ? "null" : this.ProgramId.ToString())}");
            toStringOutput.Add($"this.NumDeducted = {(this.NumDeducted == null ? "null" : this.NumDeducted.ToString())}");
            toStringOutput.Add($"this.Id = {(this.Id == null ? "null" : this.Id.ToString())}");
            toStringOutput.Add($"this.Name = {(this.Name == null ? "null" : this.Name == string.Empty ? "" : this.Name)}");
            toStringOutput.Add($"this.Active = {(this.Active == null ? "null" : this.Active.ToString())}");
            toStringOutput.Add($"this.Capacity = {(this.Capacity == null ? "null" : this.Capacity.ToString())}");
            toStringOutput.Add($"this.ResourceRequired = {(this.ResourceRequired == null ? "null" : this.ResourceRequired.ToString())}");
            toStringOutput.Add($"this.Category = {(this.Category == null ? "null" : this.Category.ToString())}");
            toStringOutput.Add($"this.Subcategory = {(this.Subcategory == null ? "null" : this.Subcategory.ToString())}");
            toStringOutput.Add($"this.OnlineDescription = {(this.OnlineDescription == null ? "null" : this.OnlineDescription == string.Empty ? "" : this.OnlineDescription)}");
        }
    }
}