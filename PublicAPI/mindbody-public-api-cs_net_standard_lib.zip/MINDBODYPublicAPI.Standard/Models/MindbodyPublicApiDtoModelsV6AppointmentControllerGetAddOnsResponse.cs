// <copyright file="MindbodyPublicApiDtoModelsV6AppointmentControllerGetAddOnsResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiDtoModelsV6AppointmentControllerGetAddOnsResponse.
    /// </summary>
    public class MindbodyPublicApiDtoModelsV6AppointmentControllerGetAddOnsResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6AppointmentControllerGetAddOnsResponse"/> class.
        /// </summary>
        public MindbodyPublicApiDtoModelsV6AppointmentControllerGetAddOnsResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6AppointmentControllerGetAddOnsResponse"/> class.
        /// </summary>
        /// <param name="paginationResponse">PaginationResponse.</param>
        /// <param name="addOns">AddOns.</param>
        public MindbodyPublicApiDtoModelsV6AppointmentControllerGetAddOnsResponse(
            Models.MindbodyPublicApiDtoModelsV6PaginationResponse paginationResponse = null,
            List<Models.MindbodyPublicApiDtoModelsV6AppointmentAddOn> addOns = null)
        {
            this.PaginationResponse = paginationResponse;
            this.AddOns = addOns;
        }

        /// <summary>
        /// Contains information about the pagination to use.
        /// </summary>
        [JsonProperty("PaginationResponse", NullValueHandling = NullValueHandling.Ignore)]
        public Models.MindbodyPublicApiDtoModelsV6PaginationResponse PaginationResponse { get; set; }

        /// <summary>
        /// Contains information about the availabilities for appointment booking.
        /// </summary>
        [JsonProperty("AddOns", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.MindbodyPublicApiDtoModelsV6AppointmentAddOn> AddOns { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiDtoModelsV6AppointmentControllerGetAddOnsResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiDtoModelsV6AppointmentControllerGetAddOnsResponse other &&
                ((this.PaginationResponse == null && other.PaginationResponse == null) || (this.PaginationResponse?.Equals(other.PaginationResponse) == true)) &&
                ((this.AddOns == null && other.AddOns == null) || (this.AddOns?.Equals(other.AddOns) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.PaginationResponse = {(this.PaginationResponse == null ? "null" : this.PaginationResponse.ToString())}");
            toStringOutput.Add($"this.AddOns = {(this.AddOns == null ? "null" : $"[{string.Join(", ", this.AddOns)} ]")}");
        }
    }
}