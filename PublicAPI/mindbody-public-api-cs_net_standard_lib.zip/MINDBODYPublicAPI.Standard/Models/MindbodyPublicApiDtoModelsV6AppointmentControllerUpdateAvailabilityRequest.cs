// <copyright file="MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAvailabilityRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAvailabilityRequest.
    /// </summary>
    public class MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAvailabilityRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAvailabilityRequest"/> class.
        /// </summary>
        public MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAvailabilityRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAvailabilityRequest"/> class.
        /// </summary>
        /// <param name="availabilityIds">AvailabilityIds.</param>
        /// <param name="publicDisplay">PublicDisplay.</param>
        /// <param name="daysOfWeek">DaysOfWeek.</param>
        /// <param name="programIds">ProgramIds.</param>
        /// <param name="startDateTime">StartDateTime.</param>
        /// <param name="endDateTime">EndDateTime.</param>
        /// <param name="locationId">LocationId.</param>
        /// <param name="unavailableDescription">UnavailableDescription.</param>
        /// <param name="test">Test.</param>
        public MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAvailabilityRequest(
            List<int> availabilityIds = null,
            Models.PublicDisplayEnum? publicDisplay = null,
            List<Models.DaysOfWeekEnum> daysOfWeek = null,
            List<int> programIds = null,
            DateTime? startDateTime = null,
            DateTime? endDateTime = null,
            int? locationId = null,
            string unavailableDescription = null,
            bool? test = null)
        {
            this.AvailabilityIds = availabilityIds;
            this.PublicDisplay = publicDisplay;
            this.DaysOfWeek = daysOfWeek;
            this.ProgramIds = programIds;
            this.StartDateTime = startDateTime;
            this.EndDateTime = endDateTime;
            this.LocationId = locationId;
            this.UnavailableDescription = unavailableDescription;
            this.Test = test;
        }

        /// <summary>
        /// Unique IDs for the availabilities or unavailabilities.
        /// </summary>
        [JsonProperty("AvailabilityIds", NullValueHandling = NullValueHandling.Ignore)]
        public List<int> AvailabilityIds { get; set; }

        /// <summary>
        /// Choice that decides whether the availablity should be publicly visible, masked or hidden.
        /// </summary>
        [JsonProperty("PublicDisplay", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.PublicDisplayEnum? PublicDisplay { get; set; }

        /// <summary>
        /// The days of week to update the availabilities or unavailabilities.<br />
        /// Default: **All**
        /// </summary>
        [JsonProperty("DaysOfWeek", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.DaysOfWeekEnum> DaysOfWeek { get; set; }

        /// <summary>
        /// The program Id to be set for the availabilities.
        /// Default: **All**
        /// </summary>
        [JsonProperty("ProgramIds", NullValueHandling = NullValueHandling.Ignore)]
        public List<int> ProgramIds { get; set; }

        /// <summary>
        /// The start date and time for the availabilities or unavailabilities.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("StartDateTime", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? StartDateTime { get; set; }

        /// <summary>
        /// The end date and time for the availabilities or unavailabilities.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("EndDateTime", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? EndDateTime { get; set; }

        /// <summary>
        /// The location Id to be updated for the provided availability Ids.
        /// </summary>
        [JsonProperty("LocationId", NullValueHandling = NullValueHandling.Ignore)]
        public int? LocationId { get; set; }

        /// <summary>
        /// The description for unavailability.
        /// </summary>
        [JsonProperty("UnavailableDescription", NullValueHandling = NullValueHandling.Ignore)]
        public string UnavailableDescription { get; set; }

        /// <summary>
        /// When `true`, the request ensures that its parameters are valid without affecting real data.
        /// When ``false`, the request performs as intended and may affect live client data.
        /// Default: **false**
        /// </summary>
        [JsonProperty("Test", NullValueHandling = NullValueHandling.Ignore)]
        public bool? Test { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAvailabilityRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAvailabilityRequest other &&
                ((this.AvailabilityIds == null && other.AvailabilityIds == null) || (this.AvailabilityIds?.Equals(other.AvailabilityIds) == true)) &&
                ((this.PublicDisplay == null && other.PublicDisplay == null) || (this.PublicDisplay?.Equals(other.PublicDisplay) == true)) &&
                ((this.DaysOfWeek == null && other.DaysOfWeek == null) || (this.DaysOfWeek?.Equals(other.DaysOfWeek) == true)) &&
                ((this.ProgramIds == null && other.ProgramIds == null) || (this.ProgramIds?.Equals(other.ProgramIds) == true)) &&
                ((this.StartDateTime == null && other.StartDateTime == null) || (this.StartDateTime?.Equals(other.StartDateTime) == true)) &&
                ((this.EndDateTime == null && other.EndDateTime == null) || (this.EndDateTime?.Equals(other.EndDateTime) == true)) &&
                ((this.LocationId == null && other.LocationId == null) || (this.LocationId?.Equals(other.LocationId) == true)) &&
                ((this.UnavailableDescription == null && other.UnavailableDescription == null) || (this.UnavailableDescription?.Equals(other.UnavailableDescription) == true)) &&
                ((this.Test == null && other.Test == null) || (this.Test?.Equals(other.Test) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.AvailabilityIds = {(this.AvailabilityIds == null ? "null" : $"[{string.Join(", ", this.AvailabilityIds)} ]")}");
            toStringOutput.Add($"this.PublicDisplay = {(this.PublicDisplay == null ? "null" : this.PublicDisplay.ToString())}");
            toStringOutput.Add($"this.DaysOfWeek = {(this.DaysOfWeek == null ? "null" : $"[{string.Join(", ", this.DaysOfWeek)} ]")}");
            toStringOutput.Add($"this.ProgramIds = {(this.ProgramIds == null ? "null" : $"[{string.Join(", ", this.ProgramIds)} ]")}");
            toStringOutput.Add($"this.StartDateTime = {(this.StartDateTime == null ? "null" : this.StartDateTime.ToString())}");
            toStringOutput.Add($"this.EndDateTime = {(this.EndDateTime == null ? "null" : this.EndDateTime.ToString())}");
            toStringOutput.Add($"this.LocationId = {(this.LocationId == null ? "null" : this.LocationId.ToString())}");
            toStringOutput.Add($"this.UnavailableDescription = {(this.UnavailableDescription == null ? "null" : this.UnavailableDescription == string.Empty ? "" : this.UnavailableDescription)}");
            toStringOutput.Add($"this.Test = {(this.Test == null ? "null" : this.Test.ToString())}");
        }
    }
}