// <copyright file="MindbodyPublicApiDtoModelsV6ClassControllerRemoveClientsFromClassesRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiDtoModelsV6ClassControllerRemoveClientsFromClassesRequest.
    /// </summary>
    public class MindbodyPublicApiDtoModelsV6ClassControllerRemoveClientsFromClassesRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClassControllerRemoveClientsFromClassesRequest"/> class.
        /// </summary>
        public MindbodyPublicApiDtoModelsV6ClassControllerRemoveClientsFromClassesRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClassControllerRemoveClientsFromClassesRequest"/> class.
        /// </summary>
        /// <param name="details">Details.</param>
        /// <param name="test">Test.</param>
        /// <param name="sendEmail">SendEmail.</param>
        /// <param name="lateCancel">LateCancel.</param>
        /// <param name="limit">Limit.</param>
        /// <param name="offset">Offset.</param>
        public MindbodyPublicApiDtoModelsV6ClassControllerRemoveClientsFromClassesRequest(
            List<Models.MindbodyPublicApiDtoModelsV6ClassControllerClassClientDetail> details = null,
            bool? test = null,
            bool? sendEmail = null,
            bool? lateCancel = null,
            int? limit = null,
            int? offset = null)
        {
            this.Details = details;
            this.Test = test;
            this.SendEmail = sendEmail;
            this.LateCancel = lateCancel;
            this.Limit = limit;
            this.Offset = offset;
        }

        /// <summary>
        /// This object includes
        /// `ClientIds`: List of the RSSID(string) of the clients to remove from the specified class.
        ///  `ClassId`: The ID(number) of the class that you want to remove the clients from.
        /// </summary>
        [JsonProperty("Details", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.MindbodyPublicApiDtoModelsV6ClassControllerClassClientDetail> Details { get; set; }

        /// <summary>
        /// When `true`, the request ensures that its parameters are valid without affecting real data.<br />
        /// When `false`, the request performs as intended and may affect live client data.<br />
        /// Default: **false**
        /// </summary>
        [JsonProperty("Test", NullValueHandling = NullValueHandling.Ignore)]
        public bool? Test { get; set; }

        /// <summary>
        /// When `true`, indicates that the client should be sent an email. Depending on the site and client settings, an email may or may not be sent.<br />
        /// Default: **false**
        /// **Note**: When the Authorization header is passed and the SendEmail is set to `true`, then an email will be sent.
        /// When the Authorization header is passed and the SendEmail is set to `false`, then an email will not be sent.
        /// When the Authorization header is not passed and the SendEmail is set to either `true` or `false`, then an email will not be sent.
        /// </summary>
        [JsonProperty("SendEmail", NullValueHandling = NullValueHandling.Ignore)]
        public bool? SendEmail { get; set; }

        /// <summary>
        /// When `true`, indicates that the client is to be late cancelled from the class.<br />
        /// When `false`, indicates that the client is to be early cancelled from the class.<br />
        /// Default: **false**
        /// </summary>
        [JsonProperty("LateCancel", NullValueHandling = NullValueHandling.Ignore)]
        public bool? LateCancel { get; set; }

        /// <summary>
        /// Number of results to include, defaults to 100
        /// </summary>
        [JsonProperty("Limit", NullValueHandling = NullValueHandling.Ignore)]
        public int? Limit { get; set; }

        /// <summary>
        /// Page offset, defaults to 0.
        /// </summary>
        [JsonProperty("Offset", NullValueHandling = NullValueHandling.Ignore)]
        public int? Offset { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiDtoModelsV6ClassControllerRemoveClientsFromClassesRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiDtoModelsV6ClassControllerRemoveClientsFromClassesRequest other &&
                ((this.Details == null && other.Details == null) || (this.Details?.Equals(other.Details) == true)) &&
                ((this.Test == null && other.Test == null) || (this.Test?.Equals(other.Test) == true)) &&
                ((this.SendEmail == null && other.SendEmail == null) || (this.SendEmail?.Equals(other.SendEmail) == true)) &&
                ((this.LateCancel == null && other.LateCancel == null) || (this.LateCancel?.Equals(other.LateCancel) == true)) &&
                ((this.Limit == null && other.Limit == null) || (this.Limit?.Equals(other.Limit) == true)) &&
                ((this.Offset == null && other.Offset == null) || (this.Offset?.Equals(other.Offset) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Details = {(this.Details == null ? "null" : $"[{string.Join(", ", this.Details)} ]")}");
            toStringOutput.Add($"this.Test = {(this.Test == null ? "null" : this.Test.ToString())}");
            toStringOutput.Add($"this.SendEmail = {(this.SendEmail == null ? "null" : this.SendEmail.ToString())}");
            toStringOutput.Add($"this.LateCancel = {(this.LateCancel == null ? "null" : this.LateCancel.ToString())}");
            toStringOutput.Add($"this.Limit = {(this.Limit == null ? "null" : this.Limit.ToString())}");
            toStringOutput.Add($"this.Offset = {(this.Offset == null ? "null" : this.Offset.ToString())}");
        }
    }
}