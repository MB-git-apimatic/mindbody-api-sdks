// <copyright file="MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientServiceResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientServiceResponse.
    /// </summary>
    public class MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientServiceResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientServiceResponse"/> class.
        /// </summary>
        public MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientServiceResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientServiceResponse"/> class.
        /// </summary>
        /// <param name="clientService">ClientService.</param>
        public MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientServiceResponse(
            Models.MindbodyPublicApiDtoModelsV6ClientService clientService = null)
        {
            this.ClientService = clientService;
        }

        /// <summary>
        /// A service that is on a client's account.
        /// </summary>
        [JsonProperty("ClientService", NullValueHandling = NullValueHandling.Ignore)]
        public Models.MindbodyPublicApiDtoModelsV6ClientService ClientService { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientServiceResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientServiceResponse other &&
                ((this.ClientService == null && other.ClientService == null) || (this.ClientService?.Equals(other.ClientService) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ClientService = {(this.ClientService == null ? "null" : this.ClientService.ToString())}");
        }
    }
}