// <copyright file="MindbodyPublicApiDtoModelsV6ClientControllerMergeClientsRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiDtoModelsV6ClientControllerMergeClientsRequest.
    /// </summary>
    public class MindbodyPublicApiDtoModelsV6ClientControllerMergeClientsRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClientControllerMergeClientsRequest"/> class.
        /// </summary>
        public MindbodyPublicApiDtoModelsV6ClientControllerMergeClientsRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClientControllerMergeClientsRequest"/> class.
        /// </summary>
        /// <param name="sourceClientId">SourceClientId.</param>
        /// <param name="targetClientId">TargetClientId.</param>
        public MindbodyPublicApiDtoModelsV6ClientControllerMergeClientsRequest(
            long? sourceClientId = null,
            long? targetClientId = null)
        {
            this.SourceClientId = sourceClientId;
            this.TargetClientId = targetClientId;
        }

        /// <summary>
        /// The client that will be merged into TargetClientId
        /// </summary>
        [JsonProperty("SourceClientId", NullValueHandling = NullValueHandling.Ignore)]
        public long? SourceClientId { get; set; }

        /// <summary>
        /// The client that will remain
        /// </summary>
        [JsonProperty("TargetClientId", NullValueHandling = NullValueHandling.Ignore)]
        public long? TargetClientId { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiDtoModelsV6ClientControllerMergeClientsRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiDtoModelsV6ClientControllerMergeClientsRequest other &&
                ((this.SourceClientId == null && other.SourceClientId == null) || (this.SourceClientId?.Equals(other.SourceClientId) == true)) &&
                ((this.TargetClientId == null && other.TargetClientId == null) || (this.TargetClientId?.Equals(other.TargetClientId) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.SourceClientId = {(this.SourceClientId == null ? "null" : this.SourceClientId.ToString())}");
            toStringOutput.Add($"this.TargetClientId = {(this.TargetClientId == null ? "null" : this.TargetClientId.ToString())}");
        }
    }
}