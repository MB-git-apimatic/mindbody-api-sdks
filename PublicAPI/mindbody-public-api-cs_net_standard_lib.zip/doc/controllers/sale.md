# Sale

```csharp
SaleController saleController = client.SaleController;
```

## Class Name

`SaleController`

## Methods

* [Sale Get Products](../../doc/controllers/sale.md#sale-get-products)
* [Sale Get Sales](../../doc/controllers/sale.md#sale-get-sales)
* [Sale Return Sale](../../doc/controllers/sale.md#sale-return-sale)
* [Sale Purchase Contract](../../doc/controllers/sale.md#sale-purchase-contract)
* [Sale Checkout Shopping Cart](../../doc/controllers/sale.md#sale-checkout-shopping-cart)
* [Sale Get Gift Cards](../../doc/controllers/sale.md#sale-get-gift-cards)
* [Sale Get Services](../../doc/controllers/sale.md#sale-get-services)
* [Sale Update Services](../../doc/controllers/sale.md#sale-update-services)
* [Sale Get Products Inventory](../../doc/controllers/sale.md#sale-get-products-inventory)
* [Sale Get Accepted Card Types](../../doc/controllers/sale.md#sale-get-accepted-card-types)
* [Sale Get Contracts](../../doc/controllers/sale.md#sale-get-contracts)
* [Sale Get Custom Payment Methods](../../doc/controllers/sale.md#sale-get-custom-payment-methods)
* [Sale Purchase Account Credit](../../doc/controllers/sale.md#sale-purchase-account-credit)
* [Sale Purchase Gift Card](../../doc/controllers/sale.md#sale-purchase-gift-card)
* [Sale Get Packages](../../doc/controllers/sale.md#sale-get-packages)
* [Sale Get Gift Card Balance](../../doc/controllers/sale.md#sale-get-gift-card-balance)
* [Sale Get Transactions](../../doc/controllers/sale.md#sale-get-transactions)
* [Sale Update Product Price](../../doc/controllers/sale.md#sale-update-product-price)
* [Sale Update Sale Date](../../doc/controllers/sale.md#sale-update-sale-date)
* [Sale Initialize Credit Card Entry](../../doc/controllers/sale.md#sale-initialize-credit-card-entry)


# Sale Get Products

Get retail products available for purchase at a site.

```csharp
SaleGetProductsAsync(
    string version,
    string siteId,
    string authorization = null,
    List<int> requestCategoryIds = null,
    int? requestLimit = null,
    int? requestLocationId = null,
    int? requestOffset = null,
    List<string> requestProductIds = null,
    string requestSearchText = null,
    bool? requestSellOnline = null,
    List<int> requestSubCategoryIds = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestCategoryIds` | `List<int>` | Query, Optional | A list of revenue category IDs to filter by. Use this ID when calling the GET Categories endpoint.<br><br>**Note:** The values for these are not currently retrievable through the API. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationId` | `int?` | Query, Optional | The location ID to use to determine the tax for the products that this request returns.<br /><br>Default: **online store** |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestProductIds` | `List<string>` | Query, Optional | The barcode number of the product to be filter by. |
| `requestSearchText` | `string` | Query, Optional | A search filter, used for searching by term. |
| `requestSellOnline` | `bool?` | Query, Optional | When `true`, only products that can be sold online are returned.<br /><br>When `false`, all products are returned.<br /><br>Default: **false** |
| `requestSubCategoryIds` | `List<int>` | Query, Optional | A list of subcategory IDs to filter by. Use this ID when calling the GET Categories endpoint.<br><br>**Note:** The values for these are not currently retrievable through the API. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerGetProductsResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-get-products-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";

try
{
    MindbodyPublicApiDtoModelsV6SaleControllerGetProductsResponse result = await saleController.SaleGetProductsAsync(version, siteId, null, null, null, null, null, null, null, null, null);
}
catch (ApiException e){};
```


# Sale Get Sales

Get sales completed at a site.

```csharp
SaleGetSalesAsync(
    string version,
    string siteId,
    string authorization = null,
    DateTime? requestEndSaleDateTime = null,
    int? requestLimit = null,
    int? requestOffset = null,
    int? requestPaymentMethodId = null,
    long? requestSaleId = null,
    DateTime? requestStartSaleDateTime = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestEndSaleDateTime` | `DateTime?` | Query, Optional | Filters results to sales that happened before this date and time. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestPaymentMethodId` | `int?` | Query, Optional | Filters results to sales paid for by the given payment method ID which indicates payment method(s) (i.e. cash, VISA, AMEX, Check, etc.). |
| `requestSaleId` | `long?` | Query, Optional | The sale ID associated with the particular item. It Filters results to the requested sale ID. |
| `requestStartSaleDateTime` | `DateTime?` | Query, Optional | Filters results to sales that happened after this date and time. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerGetSalesResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-get-sales-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";

try
{
    MindbodyPublicApiDtoModelsV6SaleControllerGetSalesResponse result = await saleController.SaleGetSalesAsync(version, siteId, null, null, null, null, null, null, null);
}
catch (ApiException e){};
```


# Sale Return Sale

Return a comped sale for a specified sale ID in business mode. The sale is returnable only if it is a sale of a service, product or gift card and it has not been used. Currently, only the comp payment method is supported.

```csharp
SaleReturnSaleAsync(
    string version,
    Models.MindbodyPublicApiDtoModelsV6SaleControllerReturnSaleRequest returnSaleRequest,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `returnSaleRequest` | [`Models.MindbodyPublicApiDtoModelsV6SaleControllerReturnSaleRequest`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-return-sale-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerReturnSaleResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-return-sale-response.md)

## Example Usage

```csharp
string version = "6";
var returnSaleRequest = new MindbodyPublicApiDtoModelsV6SaleControllerReturnSaleRequest();
string siteId = "-99";

try
{
    MindbodyPublicApiDtoModelsV6SaleControllerReturnSaleResponse result = await saleController.SaleReturnSaleAsync(version, returnSaleRequest, siteId, null);
}
catch (ApiException e){};
```


# Sale Purchase Contract

Allows a client to sign up for a contract or autopay using the information returned from the `GET Contracts` endpoint. The client can pay with a new credit card or with a stored credit card. The client must exist at the site specified before this call is made.

This endpoint allows a developer to specify whether a client pays now or pays on the `StartDate`.If you are building a client-facing experience, you should talk with the business owner to understand the owner’s policies before you give clients a choice of the two payment types.
This endpoint had been updated to support Strong Customer Authentication (SCA).

**Note**
Protect yourself from processor fees and credit card fraud. Remember to always protect your web forms that leverage POST CheckoutShoppingCart, POST PurchaseContract or POST PurchaseGiftCard with a CAPTCHA!

```csharp
SalePurchaseContractAsync(
    string version,
    Models.MindbodyPublicApiDtoModelsV6SaleControllerPurchaseContractRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`Models.MindbodyPublicApiDtoModelsV6SaleControllerPurchaseContractRequest`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-purchase-contract-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerPurchaseContractResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-purchase-contract-response.md)

## Example Usage

```csharp
string version = "6";
var request = new MindbodyPublicApiDtoModelsV6SaleControllerPurchaseContractRequest();
request.ClientId = "ClientId0";
request.ContractId = 168;
string siteId = "-99";

try
{
    MindbodyPublicApiDtoModelsV6SaleControllerPurchaseContractResponse result = await saleController.SalePurchaseContractAsync(version, request, siteId, null);
}
catch (ApiException e){};
```


# Sale Checkout Shopping Cart

This endpoint provides a wide range of functionality. For example, you can use it when a client purchases new pricing options, retail products, packages, and tips. You can also combine purchasing a new pricing option and many other functions, such as booking a client into a class, booking a new appointment for a client, enrolling a client into an enrollment or course, or reconciling an unpaid, already booked appointment or class. Use this call when a client purchases:

* a pricing option, after calling `GET Services` and choosing a specific pricing option’s ID
* a retail product, after calling `GET Products` and choosing a specific retail product’s ID
* a package, after calling `GET Packages` and choosing a specific package’s ID
* a tip to give to a staff member, after calling `GET Staff` and choosing a specific staff member ID, and the amount that the client wants to tip
  The documentation provides explanations of the request body and response, as well as the cart item metadata, payment item metadata, and purchased cart items.
  This endpoint had been updated to support Strong Customer Authentication (SCA).
  **Note :**
  Protect yourself from processor fees and credit card fraud.Remember to always protect your web forms that leverage POST CheckoutShoppingCart, POST PurchaseContract or POST PurchaseGiftCard with a CAPTCHA!

```csharp
SaleCheckoutShoppingCartAsync(
    string version,
    Models.MindbodyPublicApiDtoModelsV6SaleControllerCheckoutRequestCheckoutShoppingCartRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`Models.MindbodyPublicApiDtoModelsV6SaleControllerCheckoutRequestCheckoutShoppingCartRequest`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-checkout-request-checkout-shopping-cart-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

`Task<object>`

## Example Usage

```csharp
string version = "6";
var request = new MindbodyPublicApiDtoModelsV6SaleControllerCheckoutRequestCheckoutShoppingCartRequest();
request.ClientId = "ClientId0";
request.Items = new List<MindbodyPublicApiDtoModelsV6SaleControllerCheckoutRequestCheckoutItemWrapper>();

var requestItems0 = new MindbodyPublicApiDtoModelsV6SaleControllerCheckoutRequestCheckoutItemWrapper();
request.Items.Add(requestItems0);

var requestItems1 = new MindbodyPublicApiDtoModelsV6SaleControllerCheckoutRequestCheckoutItemWrapper();
request.Items.Add(requestItems1);

var requestItems2 = new MindbodyPublicApiDtoModelsV6SaleControllerCheckoutRequestCheckoutItemWrapper();
request.Items.Add(requestItems2);

request.Payments = new List<MindbodyPublicApiDtoModelsV6SaleControllerCheckoutRequestPaymentsCheckoutPaymentInfo>();

var requestPayments0 = new MindbodyPublicApiDtoModelsV6SaleControllerCheckoutRequestPaymentsCheckoutPaymentInfo();
request.Payments.Add(requestPayments0);

var requestPayments1 = new MindbodyPublicApiDtoModelsV6SaleControllerCheckoutRequestPaymentsCheckoutPaymentInfo();
request.Payments.Add(requestPayments1);

var requestPayments2 = new MindbodyPublicApiDtoModelsV6SaleControllerCheckoutRequestPaymentsCheckoutPaymentInfo();
request.Payments.Add(requestPayments2);

string siteId = "-99";

try
{
    object result = await saleController.SaleCheckoutShoppingCartAsync(version, request, siteId, null);
}
catch (ApiException e){};
```


# Sale Get Gift Cards

Returns information about gift cards that can be purchased.

```csharp
SaleGetGiftCardsAsync(
    string version,
    string siteId,
    string authorization = null,
    List<int> requestIds = null,
    bool? requestIncludeCustomLayouts = null,
    int? requestLimit = null,
    int? requestLocationId = null,
    int? requestOffset = null,
    bool? requestSoldOnline = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestIds` | `List<int>` | Query, Optional | Filters the results to the requested gift card IDs.<br /><br>Default: **all** gift cards. |
| `requestIncludeCustomLayouts` | `bool?` | Query, Optional | When `true`, includes custom gift card layouts.<br /><br>When `false`, includes only system layouts.<br>Default: **false** |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationId` | `int?` | Query, Optional | When included, returns gift cards that are sold at the provided location ID. |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestSoldOnline` | `bool?` | Query, Optional | When `true`, only returns gift cards that are sold online.<br /><br>Default: **false** |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerGetGiftCardResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-get-gift-card-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";

try
{
    MindbodyPublicApiDtoModelsV6SaleControllerGetGiftCardResponse result = await saleController.SaleGetGiftCardsAsync(version, siteId, null, null, null, null, null, null, null);
}
catch (ApiException e){};
```


# Sale Get Services

Get pricing options available for purchase at a site

```csharp
SaleGetServicesAsync(
    string version,
    string siteId,
    string authorization = null,
    int? requestClassId = null,
    int? requestClassScheduleId = null,
    bool? requestHideRelatedPrograms = null,
    bool? requestIncludeDiscontinued = null,
    bool? requestIncludeSaleInContractOnly = null,
    int? requestLimit = null,
    int? requestLocationId = null,
    int? requestOffset = null,
    List<int> requestProgramIds = null,
    bool? requestSellOnline = null,
    List<string> requestServiceIds = null,
    List<int> requestSessionTypeIds = null,
    long? requestStaffId = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestClassId` | `int?` | Query, Optional | Filters to the pricing options for the specified class ID. |
| `requestClassScheduleId` | `int?` | Query, Optional | Filters to the pricing options for the specified class schedule ID. |
| `requestHideRelatedPrograms` | `bool?` | Query, Optional | When `true`, indicates that pricing options of related programs are omitted from the response.<br /><br>Default: **false** |
| `requestIncludeDiscontinued` | `bool?` | Query, Optional | When `true`, indicates that the filtered pricing option list includes discontinued pricing options.<br /><br>Default: **false** |
| `requestIncludeSaleInContractOnly` | `bool?` | Query, Optional | When `true`, indicates that the filtered pricing option list includes sale in contract only pricing options.<br /><br>Default: **false** |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationId` | `int?` | Query, Optional | When specified, for each returned pricing option, `TaxRate` and `TaxIncluded` are calculated according to the specified location. Note that this does not filter results to only services provided at the given location, and for locations where Value-Added Tax (VAT) rules apply, the `TaxRate` is set to zero. |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestProgramIds` | `List<int>` | Query, Optional | Filters to pricing options with the specified program IDs. |
| `requestSellOnline` | `bool?` | Query, Optional | When `true`, filters to the pricing options that can be sold online.<br /><br>Default: **false** |
| `requestServiceIds` | `List<string>` | Query, Optional | Filters to the pricing options with the specified IDs. In this context, service and pricing option are used interchangeably. These are the `PurchasedItems[].Id` returned from GET Sales. |
| `requestSessionTypeIds` | `List<int>` | Query, Optional | Filters to the pricing options with the specified session types IDs. |
| `requestStaffId` | `long?` | Query, Optional | Sets `Price` and `OnlinePrice` to the particular pricing of a specific staff member, if allowed by the business. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerGetServicesResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-get-services-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";

try
{
    MindbodyPublicApiDtoModelsV6SaleControllerGetServicesResponse result = await saleController.SaleGetServicesAsync(version, siteId, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
}
catch (ApiException e){};
```


# Sale Update Services

Update unit price and online price of provided services.

```csharp
SaleUpdateServicesAsync(
    string version,
    string siteId,
    List<Models.MindbodyPublicApiDtoModelsV6SaleControllerUpdateServiceRequest> updateServicesRequest,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `updateServicesRequest` | [`List<Models.MindbodyPublicApiDtoModelsV6SaleControllerUpdateServiceRequest>`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-update-service-request.md) | Body, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerUpdateServiceResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-update-service-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
var updateServicesRequest = new List<MindbodyPublicApiDtoModelsV6SaleControllerUpdateServiceRequest>();

var updateServicesRequest0 = new MindbodyPublicApiDtoModelsV6SaleControllerUpdateServiceRequest();
updateServicesRequest.Add(updateServicesRequest0);


try
{
    MindbodyPublicApiDtoModelsV6SaleControllerUpdateServiceResponse result = await saleController.SaleUpdateServicesAsync(version, siteId, updateServicesRequest, null);
}
catch (ApiException e){};
```


# Sale Get Products Inventory

Get retail products inventory data available at a site.

```csharp
SaleGetProductsInventoryAsync(
    string version,
    string siteId,
    string authorization = null,
    List<string> requestBarcodeIds = null,
    int? requestLimit = null,
    List<int> requestLocationIds = null,
    int? requestOffset = null,
    List<string> requestProductIds = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestBarcodeIds` | `List<string>` | Query, Optional | When included, the response only contains details about the specified Barcode Ids. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationIds` | `List<int>` | Query, Optional | When included, the response only contains details about the specified location Ids. |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestProductIds` | `List<string>` | Query, Optional | When included, the response only contains details about the specified product Ids. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerGetProductsInventoryResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-get-products-inventory-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";

try
{
    MindbodyPublicApiDtoModelsV6SaleControllerGetProductsInventoryResponse result = await saleController.SaleGetProductsInventoryAsync(version, siteId, null, null, null, null, null, null);
}
catch (ApiException e){};
```


# Sale Get Accepted Card Types

Gets a list of card types that the site accepts. You can also use `GET Sites` to return the Site object, which contains individual accepted card types for requested sites.

This endpoint has no query parameters.The response returns a list of strings. Possible values are:

* Visa
* MasterCard
* Discover
* AMEX

```csharp
SaleGetAcceptedCardTypesAsync(
    string version,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

`Task<List<string>>`

## Example Usage

```csharp
string version = "6";
string siteId = "-99";

try
{
    List<string> result = await saleController.SaleGetAcceptedCardTypesAsync(version, siteId, null);
}
catch (ApiException e){};
```


# Sale Get Contracts

Returns the contracts and autopay options that are available on a location-by-location basis. Depending on the configurations established by the site, this endpoint returns options that can be used to sign up clients for recurring payments for services offered by the business.

```csharp
SaleGetContractsAsync(
    string version,
    int requestLocationId,
    string siteId,
    string authorization = null,
    long? requestConsumerId = null,
    List<int> requestContractIds = null,
    int? requestLimit = null,
    int? requestOffset = null,
    string requestPromoCode = null,
    bool? requestSoldOnline = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestLocationId` | `int` | Query, Required | The ID of the location that has the requested contracts and AutoPay options. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestConsumerId` | `long?` | Query, Optional | The ID of the client. |
| `requestContractIds` | `List<int>` | Query, Optional | When included, the response only contains details about the specified contract IDs. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestPromoCode` | `string` | Query, Optional | PromoCode to apply |
| `requestSoldOnline` | `bool?` | Query, Optional | When `true`, the response only contains details about contracts and AutoPay options that can be sold online.<br>When `false`, all contracts are returned.<br>Default: **false** |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerGetContractsResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-get-contracts-response.md)

## Example Usage

```csharp
string version = "6";
int requestLocationId = 90;
string siteId = "-99";

try
{
    MindbodyPublicApiDtoModelsV6SaleControllerGetContractsResponse result = await saleController.SaleGetContractsAsync(version, requestLocationId, siteId, null, null, null, null, null, null, null);
}
catch (ApiException e){};
```


# Sale Get Custom Payment Methods

Get payment methods that can be used to pay for sales at a site.

```csharp
SaleGetCustomPaymentMethodsAsync(
    string version,
    string siteId,
    string authorization = null,
    int? requestLimit = null,
    int? requestOffset = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerGetCustomPaymentMethodsResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-get-custom-payment-methods-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";

try
{
    MindbodyPublicApiDtoModelsV6SaleControllerGetCustomPaymentMethodsResponse result = await saleController.SaleGetCustomPaymentMethodsAsync(version, siteId, null, null, null);
}
catch (ApiException e){};
```


# Sale Purchase Account Credit

Allows a client to purchase account credit from a business.

```csharp
SalePurchaseAccountCreditAsync(
    string version,
    Models.MindbodyPublicApiDtoModelsV6SaleControllerPurchaseAccountCreditRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`Models.MindbodyPublicApiDtoModelsV6SaleControllerPurchaseAccountCreditRequest`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-purchase-account-credit-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerPurchaseAccountCreditResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-purchase-account-credit-response.md)

## Example Usage

```csharp
string version = "6";
var request = new MindbodyPublicApiDtoModelsV6SaleControllerPurchaseAccountCreditRequest();
request.ClientId = "ClientId0";
string siteId = "-99";

try
{
    MindbodyPublicApiDtoModelsV6SaleControllerPurchaseAccountCreditResponse result = await saleController.SalePurchaseAccountCreditAsync(version, request, siteId, null);
}
catch (ApiException e){};
```


# Sale Purchase Gift Card

Allows a client to purchase a gift card from a business in a variety of designs. The card can be emailed to the recipient on a specific day, and a card title and a personal message can be added.

**Note**
Protect yourself from processor fees and credit card fraud.Remember to always protect your web forms that leverage POST CheckoutShoppingCart, POST PurchaseContract or POST PurchaseGiftCard with a CAPTCHA!

```csharp
SalePurchaseGiftCardAsync(
    string version,
    Models.MindbodyPublicApiDtoModelsV6SaleControllerPurchaseGiftCardRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`Models.MindbodyPublicApiDtoModelsV6SaleControllerPurchaseGiftCardRequest`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-purchase-gift-card-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerPurchaseGiftCardResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-purchase-gift-card-response.md)

## Example Usage

```csharp
string version = "6";
var request = new MindbodyPublicApiDtoModelsV6SaleControllerPurchaseGiftCardRequest();
request.LocationId = 238;
request.PurchaserClientId = "PurchaserClientId6";
request.GiftCardId = 222;
string siteId = "-99";

try
{
    MindbodyPublicApiDtoModelsV6SaleControllerPurchaseGiftCardResponse result = await saleController.SalePurchaseGiftCardAsync(version, request, siteId, null);
}
catch (ApiException e){};
```


# Sale Get Packages

A package is typically used to combine multiple services and/or products into a single offering. Staff members can check out multiple appointments while selling the package, and can discount the items included. For example, a spa might bundle a massage, a pedicure, a manicure, a facial, and a few selected beauty products into a package.

```csharp
SaleGetPackagesAsync(
    string version,
    string siteId,
    string authorization = null,
    int? requestLimit = null,
    int? requestLocationId = null,
    int? requestOffset = null,
    List<int> requestPackageIds = null,
    bool? requestSellOnline = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationId` | `int?` | Query, Optional | The location ID to use to determine the tax for the products that this request returns.<br /><br>Default: **online store** |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestPackageIds` | `List<int>` | Query, Optional | A list of the packages IDs to filter by. |
| `requestSellOnline` | `bool?` | Query, Optional | When `true`, only returns products that can be sold online.<br /><br>When `false`, all products are returned.<br /><br>Default: **false** |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerGetPackagesResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-get-packages-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";

try
{
    MindbodyPublicApiDtoModelsV6SaleControllerGetPackagesResponse result = await saleController.SaleGetPackagesAsync(version, siteId, null, null, null, null, null, null);
}
catch (ApiException e){};
```


# Sale Get Gift Card Balance

Returns a gift card’s remaining balance.

```csharp
SaleGetGiftCardBalanceAsync(
    string version,
    string siteId,
    string authorization = null,
    string barcodeId = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `barcodeId` | `string` | Query, Optional | The barcode ID of the gift card for which you want the balance. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerGetGiftCardBalanceResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-get-gift-card-balance-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";

try
{
    MindbodyPublicApiDtoModelsV6SaleControllerGetGiftCardBalanceResponse result = await saleController.SaleGetGiftCardBalanceAsync(version, siteId, null, null);
}
catch (ApiException e){};
```


# Sale Get Transactions

This endpoint returns a list of transaction details of processed sales.

```csharp
SaleGetTransactionsAsync(
    string version,
    string siteId,
    string authorization = null,
    long? requestClientId = null,
    int? requestLimit = null,
    int? requestLocationId = null,
    int? requestOffset = null,
    long? requestSaleId = null,
    string requestStatus = null,
    DateTime? requestTransactionEndDateTime = null,
    int? requestTransactionId = null,
    DateTime? requestTransactionStartDateTime = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestClientId` | `long?` | Query, Optional | Filters results to the requested client ID. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationId` | `int?` | Query, Optional | Filters the transaction results with the ID number associated with the location of the sale. |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestSaleId` | `long?` | Query, Optional | Filters the transaction results with the ID number associated with the sale. |
| `requestStatus` | `string` | Query, Optional | Filters the transaction results by the estimated transaction status. |
| `requestTransactionEndDateTime` | `DateTime?` | Query, Optional | Filters the transaction results that happpened before this date and time.<br>Default: **today’s date** |
| `requestTransactionId` | `int?` | Query, Optional | Filters the transaction results with the ID number generated when the sale is processed. |
| `requestTransactionStartDateTime` | `DateTime?` | Query, Optional | Filters the transaction results that happpened after this date and time.<br>Default: **today’s date** |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerGetTransactionsResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-get-transactions-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";

try
{
    MindbodyPublicApiDtoModelsV6SaleControllerGetTransactionsResponse result = await saleController.SaleGetTransactionsAsync(version, siteId, null, null, null, null, null, null, null, null, null, null);
}
catch (ApiException e){};
```


# Sale Update Product Price

This endpoint updates the retail price and an online price for a product. Passing at least one of them is mandatory.

```csharp
SaleUpdateProductPriceAsync(
    string version,
    Models.MindbodyPublicApiDtoModelsV6SaleControllerUpdateProductPriceRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`Models.MindbodyPublicApiDtoModelsV6SaleControllerUpdateProductPriceRequest`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-update-product-price-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerUpdateProductPriceResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-update-product-price-response.md)

## Example Usage

```csharp
string version = "6";
var request = new MindbodyPublicApiDtoModelsV6SaleControllerUpdateProductPriceRequest();
string siteId = "-99";

try
{
    MindbodyPublicApiDtoModelsV6SaleControllerUpdateProductPriceResponse result = await saleController.SaleUpdateProductPriceAsync(version, request, siteId, null);
}
catch (ApiException e){};
```


# Sale Update Sale Date

This endpoint updates the SaleDate and returns the details of the sale.

```csharp
SaleUpdateSaleDateAsync(
    string version,
    Models.MindbodyPublicApiDtoModelsV6SaleControllerUpdateSaleDateRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`Models.MindbodyPublicApiDtoModelsV6SaleControllerUpdateSaleDateRequest`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-update-sale-date-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerUpdateSaleDateResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-update-sale-date-response.md)

## Example Usage

```csharp
string version = "6";
var request = new MindbodyPublicApiDtoModelsV6SaleControllerUpdateSaleDateRequest();
string siteId = "-99";

try
{
    MindbodyPublicApiDtoModelsV6SaleControllerUpdateSaleDateResponse result = await saleController.SaleUpdateSaleDateAsync(version, request, siteId, null);
}
catch (ApiException e){};
```


# Sale Initialize Credit Card Entry

This endpoint returns a Callback URL which is used to load Card Element UI with the help of which user will be able to enter the card details and initiate a transaction .
The documentation provides explanations of the request body and response.

**Note**:
Note
Referer is a DomainURL which will be automatically reflected if the Card UI is loaded via your application.
If you are using this endpoint via postman then you need to specify your domain URL under Referer.

```csharp
SaleInitializeCreditCardEntryAsync(
    string version,
    Models.MindbodyPublicApiDtoModelsV6SaleControllerInitializeCreditCardEntryRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`Models.MindbodyPublicApiDtoModelsV6SaleControllerInitializeCreditCardEntryRequest`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-initialize-credit-card-entry-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerInitializeCreditCardEntryResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-initialize-credit-card-entry-response.md)

## Example Usage

```csharp
string version = "6";
var request = new MindbodyPublicApiDtoModelsV6SaleControllerInitializeCreditCardEntryRequest();
string siteId = "-99";

try
{
    MindbodyPublicApiDtoModelsV6SaleControllerInitializeCreditCardEntryResponse result = await saleController.SaleInitializeCreditCardEntryAsync(version, request, siteId, null);
}
catch (ApiException e){};
```

