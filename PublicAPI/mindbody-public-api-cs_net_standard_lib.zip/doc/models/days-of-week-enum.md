
# Days of Week Enum

## Enumeration

`DaysOfWeekEnum`

## Fields

| Name |
|  --- |
| `Sunday` |
| `Monday` |
| `Tuesday` |
| `Wednesday` |
| `Thursday` |
| `Friday` |
| `Saturday` |

