
# Mindbody Public Api Dto Models V6 Sale Payment

## Structure

`MindbodyPublicApiDtoModelsV6SalePayment`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `long?` | Optional | A unique identifier for this payment. |
| `Amount` | `double?` | Optional | The amount of this payment. |
| `Method` | `int?` | Optional | The method for this payment. |
| `Type` | `string` | Optional | The type of payment. |
| `Notes` | `string` | Optional | Notes about this payment. |
| `TransactionId` | `int?` | Optional | The payment transaction ID |

## Example (as JSON)

```json
{
  "Id": null,
  "Amount": null,
  "Method": null,
  "Type": null,
  "Notes": null,
  "TransactionId": null
}
```

