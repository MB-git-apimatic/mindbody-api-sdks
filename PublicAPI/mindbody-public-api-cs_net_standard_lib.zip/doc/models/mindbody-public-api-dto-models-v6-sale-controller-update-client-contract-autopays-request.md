
# Mindbody Public Api Dto Models V6 Sale Controller Update Client Contract Autopays Request

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerUpdateClientContractAutopaysRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ClientContractId` | `int?` | Optional | Client Contract Id |
| `AutopayStartDate` | `DateTime?` | Optional | Autopay start date |
| `AutopayEndDate` | `DateTime?` | Optional | (optional) - Indefinite if not provided |
| `ProductId` | `int?` | Optional | Product Id to update (optional if contract has only one product) |
| `ReplaceWithProductId` | `int?` | Optional | (optional) - Replaces the product with this product |
| `Amount` | `double?` | Optional | Overrides autopay amount or amount that would come from ProductId |

## Example (as JSON)

```json
{
  "ClientContractId": null,
  "AutopayStartDate": null,
  "AutopayEndDate": null,
  "ProductId": null,
  "ReplaceWithProductId": null,
  "Amount": null
}
```

