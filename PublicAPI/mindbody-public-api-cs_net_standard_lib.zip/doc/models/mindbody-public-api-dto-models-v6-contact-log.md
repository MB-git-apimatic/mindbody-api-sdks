
# Mindbody Public Api Dto Models V6 Contact Log

A contact log.

## Structure

`MindbodyPublicApiDtoModelsV6ContactLog`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `long?` | Optional | The contact log’s ID. |
| `Text` | `string` | Optional | The contact log’s body text. |
| `CreatedDateTime` | `DateTime?` | Optional | The local date and time when the contact log was created. |
| `FollowupByDate` | `DateTime?` | Optional | The date by which the assigned staff member should close or follow up on this contact log. |
| `ContactMethod` | `string` | Optional | The method by which the client wants to be contacted. |
| `ContactName` | `string` | Optional | The name of the client to contact. |
| `Client` | [`Models.MindbodyPublicApiDtoModelsV6Client`](../../doc/models/mindbody-public-api-dto-models-v6-client.md) | Optional | The Client. |
| `CreatedBy` | [`Models.MindbodyPublicApiDtoModelsV6Staff`](../../doc/models/mindbody-public-api-dto-models-v6-staff.md) | Optional | The Staff |
| `AssignedTo` | [`Models.MindbodyPublicApiDtoModelsV6Staff`](../../doc/models/mindbody-public-api-dto-models-v6-staff.md) | Optional | The Staff |
| `Comments` | [`List<Models.MindbodyPublicApiDtoModelsV6ContactLogComment>`](../../doc/models/mindbody-public-api-dto-models-v6-contact-log-comment.md) | Optional | The contact log’s comments. |
| `Types` | [`List<Models.MindbodyPublicApiDtoModelsV6ContactLogType>`](../../doc/models/mindbody-public-api-dto-models-v6-contact-log-type.md) | Optional | Contains information about contact log types. |

## Example (as JSON)

```json
{
  "Id": null,
  "Text": null,
  "CreatedDateTime": null,
  "FollowupByDate": null,
  "ContactMethod": null,
  "ContactName": null,
  "Client": null,
  "CreatedBy": null,
  "AssignedTo": null,
  "Comments": null,
  "Types": null
}
```

