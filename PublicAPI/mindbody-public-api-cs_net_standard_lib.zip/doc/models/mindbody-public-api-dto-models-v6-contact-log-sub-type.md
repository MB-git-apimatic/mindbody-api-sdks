
# Mindbody Public Api Dto Models V6 Contact Log Sub Type

A contact log subtype.

## Structure

`MindbodyPublicApiDtoModelsV6ContactLogSubType`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | The unique ID of the subtype |
| `Name` | `string` | Optional | The name of the subcontactlog Type. |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null
}
```

