
# Mindbody Public Api Data Models Written Class Schedules Info

## Structure

`MindbodyPublicApiDataModelsWrittenClassSchedulesInfo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ClassId` | `int?` | Optional | The ClassScheduleId. |
| `ClassInstanceIds` | `List<int>` | Optional | The individual ClassIds of the enrollment schedule. |

## Example (as JSON)

```json
{
  "ClassId": null,
  "ClassInstanceIds": null
}
```

