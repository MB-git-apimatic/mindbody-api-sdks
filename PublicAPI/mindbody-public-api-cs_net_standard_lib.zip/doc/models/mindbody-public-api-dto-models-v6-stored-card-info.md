
# Mindbody Public Api Dto Models V6 Stored Card Info

## Structure

`MindbodyPublicApiDtoModelsV6StoredCardInfo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `LastFour` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "LastFour": null
}
```

