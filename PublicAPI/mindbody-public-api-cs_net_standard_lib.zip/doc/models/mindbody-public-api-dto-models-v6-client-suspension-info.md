
# Mindbody Public Api Dto Models V6 Client Suspension Info

A Client DTO with Suspension Informatoin

## Structure

`MindbodyPublicApiDtoModelsV6ClientSuspensionInfo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `BookingSuspended` | `bool?` | Optional | When 'true', indicates that the client is suspended from booking |
| `SuspensionStartDate` | `string` | Optional | Indicates the Date that BookingSuspension starts 'YYYY-MM-DD' |
| `SuspensionEndDate` | `string` | Optional | Indicates the Date that BookingSuspension ends 'YYYY-MM-DD' |

## Example (as JSON)

```json
{
  "BookingSuspended": null,
  "SuspensionStartDate": null,
  "SuspensionEndDate": null
}
```

