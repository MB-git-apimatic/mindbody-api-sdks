
# Mindbody Public Api Dto Models V6 Membership

## Structure

`MindbodyPublicApiDtoModelsV6Membership`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `MembershipId` | `int?` | Optional | The membership id. |
| `MembershipName` | `string` | Optional | The membership name. |
| `Priority` | `int?` | Optional | The priority/sort order. |
| `MemberRetailDiscount` | `double?` | Optional | The membership discount for retail as a percentage. |
| `MemberServiceDiscount` | `double?` | Optional | The membership discount for services as a percentage. |
| `AllowClientsToScheduleUnpaid` | `bool?` | Optional | Allow clients in this membership to schedule unpaid. |
| `OnlineBookingRestrictedToMembersOnly` | [`List<Models.MindbodyPublicApiDtoModelsV6ProgramMembership>`](../../doc/models/mindbody-public-api-dto-models-v6-program-membership.md) | Optional | List of programs that are restricted to clients in this membership only. |
| `DayOfMonthSchedulingOpensForNextMonth` | `int?` | Optional | Day of month scheduling opens for next month.  Unrestricted is a null value. |
| `RestrictSelfSignInToMembersOnly` | `bool?` | Optional | Restrict self sign in to members only. |
| `AllowMembersToBookAppointmentsWithoutPaying` | `bool?` | Optional | Allow members to book appointments without paying. |
| `AllowMembersToPurchaseNonMembersServices` | `bool?` | Optional | Allow members to purchase non-members services. |
| `AllowMembersToPurchaseNonMembersProducts` | `bool?` | Optional | Allow members to purchase non-members products. |
| `IsActive` | `bool?` | Optional | Indicates if the membership is active. |

## Example (as JSON)

```json
{
  "MembershipId": null,
  "MembershipName": null,
  "Priority": null,
  "MemberRetailDiscount": null,
  "MemberServiceDiscount": null,
  "AllowClientsToScheduleUnpaid": null,
  "OnlineBookingRestrictedToMembersOnly": null,
  "DayOfMonthSchedulingOpensForNextMonth": null,
  "RestrictSelfSignInToMembersOnly": null,
  "AllowMembersToBookAppointmentsWithoutPaying": null,
  "AllowMembersToPurchaseNonMembersServices": null,
  "AllowMembersToPurchaseNonMembersProducts": null,
  "IsActive": null
}
```

