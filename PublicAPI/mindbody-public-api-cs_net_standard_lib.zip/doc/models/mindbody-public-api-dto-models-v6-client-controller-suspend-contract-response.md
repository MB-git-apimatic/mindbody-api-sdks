
# Mindbody Public Api Dto Models V6 Client Controller Suspend Contract Response

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerSuspendContractResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Contract` | [`Models.MindbodyPublicApiDtoModelsV6ClientContract`](../../doc/models/mindbody-public-api-dto-models-v6-client-contract.md) | Optional | A client contract |

## Example (as JSON)

```json
{
  "Contract": null
}
```

