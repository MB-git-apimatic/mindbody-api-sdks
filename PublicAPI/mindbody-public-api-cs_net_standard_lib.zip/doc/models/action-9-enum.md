
# Action 9 Enum

Indicates if rewards were earned or redeemed.

## Enumeration

`Action9Enum`

## Fields

| Name |
|  --- |
| `Earned` |
| `Redeemed` |
| `Returned` |
| `Removed` |
| `LateCanceled` |

