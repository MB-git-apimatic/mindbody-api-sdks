
# Mindbody Public Api Dto Models V6 Amenity

Definition of a location amenity

## Structure

`MindbodyPublicApiDtoModelsV6Amenity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | The ID number of the amenity. |
| `Name` | `string` | Optional | The name of the amenity, for example, food or lockers. |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null
}
```

