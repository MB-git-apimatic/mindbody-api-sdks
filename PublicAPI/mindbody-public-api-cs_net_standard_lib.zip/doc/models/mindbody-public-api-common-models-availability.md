
# Mindbody Public Api Common Models Availability

The availability of a specific staff

## Structure

`MindbodyPublicApiCommonModelsAvailability`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | Id of the availability |
| `Staff` | [`Models.MindbodyPublicApiCommonModelsStaff`](../../doc/models/mindbody-public-api-common-models-staff.md) | Optional | - |
| `SessionType` | [`Models.MindbodyPublicApiCommonModelsSessionType`](../../doc/models/mindbody-public-api-common-models-session-type.md) | Optional | - |
| `Programs` | [`List<Models.MindbodyPublicApiCommonModelsProgram>`](../../doc/models/mindbody-public-api-common-models-program.md) | Optional | Availabilities program list. |
| `StartDateTime` | `DateTime?` | Optional | Availabilities start date and time. |
| `EndDateTime` | `DateTime?` | Optional | Availabilities end date and time. |
| `BookableEndDateTime` | `DateTime?` | Optional | Availabilities bookable end date and time. |
| `Location` | [`Models.MindbodyPublicApiCommonModelsLocation`](../../doc/models/mindbody-public-api-common-models-location.md) | Optional | - |
| `PrepTime` | `int?` | Optional | Appointment prep time |
| `FinishTime` | `int?` | Optional | Appointment finish time |

## Example (as JSON)

```json
{
  "Id": null,
  "Staff": null,
  "SessionType": null,
  "Programs": null,
  "StartDateTime": null,
  "EndDateTime": null,
  "BookableEndDateTime": null,
  "Location": null,
  "PrepTime": null,
  "FinishTime": null
}
```

