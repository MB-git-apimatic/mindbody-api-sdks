
# Mindbody Public Api Dto Models V6 Api Error

## Structure

`MindbodyPublicApiDtoModelsV6ApiError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Message` | `string` | Optional | - |
| `Code` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "Message": null,
  "Code": null
}
```

