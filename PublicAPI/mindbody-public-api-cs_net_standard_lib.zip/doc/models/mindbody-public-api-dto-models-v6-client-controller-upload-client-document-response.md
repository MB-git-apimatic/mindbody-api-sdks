
# Mindbody Public Api Dto Models V6 Client Controller Upload Client Document Response

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerUploadClientDocumentResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `FileSize` | `long?` | Optional | The size of the uploaded file. |
| `FileName` | `string` | Optional | The name of the uploaded file. |

## Example (as JSON)

```json
{
  "FileSize": null,
  "FileName": null
}
```

