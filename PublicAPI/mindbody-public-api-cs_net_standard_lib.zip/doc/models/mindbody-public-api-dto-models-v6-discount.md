
# Mindbody Public Api Dto Models V6 Discount

Discount for a promo code

## Structure

`MindbodyPublicApiDtoModelsV6Discount`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Type` | `string` | Optional | Type of discount percentage/amount |
| `Amount` | `double?` | Optional | Amount of discount |

## Example (as JSON)

```json
{
  "Type": null,
  "Amount": null
}
```

