
# Mindbody Public Api Dto Models V6 Sale Controller Payment Processing Failure

Contains information about any payment processing failure.  Specifically for when an SCA challenge is

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerPaymentProcessingFailure`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Type` | `string` | Optional | The type of the failure |
| `Message` | `string` | Optional | Descriptive message for the failure |
| `AuthenticationRedirectUrl` | `string` | Optional | For SCA aware flows, this is the url provided by the bank where the consumer can authorize the transaction |

## Example (as JSON)

```json
{
  "Type": null,
  "Message": null,
  "AuthenticationRedirectUrl": null
}
```

