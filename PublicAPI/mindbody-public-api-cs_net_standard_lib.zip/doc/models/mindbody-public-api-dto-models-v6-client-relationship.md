
# Mindbody Public Api Dto Models V6 Client Relationship

A relation between two clients.

## Structure

`MindbodyPublicApiDtoModelsV6ClientRelationship`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `RelatedClientId` | `string` | Optional | The RSSID of the related client. |
| `Relationship` | [`Models.MindbodyPublicApiDtoModelsV6Relationship`](../../doc/models/mindbody-public-api-dto-models-v6-relationship.md) | Optional | Jim is a RelationshipName1 of John. John is a RelationshipName2 of Jim. |
| `RelationshipName` | `string` | Optional | The name of the relationship of the related client. |
| `Delete` | `bool?` | Optional | When true, this relationship is removed from the associated clients. |

## Example (as JSON)

```json
{
  "RelatedClientId": null,
  "Relationship": null,
  "RelationshipName": null,
  "Delete": null
}
```

