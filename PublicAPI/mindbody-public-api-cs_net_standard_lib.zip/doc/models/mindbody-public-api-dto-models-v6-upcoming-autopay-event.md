
# Mindbody Public Api Dto Models V6 Upcoming Autopay Event

## Structure

`MindbodyPublicApiDtoModelsV6UpcomingAutopayEvent`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ClientContractId` | `int?` | Optional | The ID of the contract. |
| `ChargeAmount` | `double?` | Optional | The amount charged. |
| `PaymentMethod` | [`Models.PaymentMethodEnum?`](../../doc/models/payment-method-enum.md) | Optional | The payment method. |
| `ScheduleDate` | `DateTime?` | Optional | The date and time of the next payment. |

## Example (as JSON)

```json
{
  "ClientContractId": null,
  "ChargeAmount": null,
  "PaymentMethod": null,
  "ScheduleDate": null
}
```

