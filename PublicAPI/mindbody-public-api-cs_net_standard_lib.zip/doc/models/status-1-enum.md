
# Status 1 Enum

The status of this appointment.

## Enumeration

`Status1Enum`

## Fields

| Name |
|  --- |
| `Booked` |
| `Completed` |
| `Confirmed` |
| `Arrived` |
| `NoShow` |
| `Cancelled` |
| `LateCancelled` |

