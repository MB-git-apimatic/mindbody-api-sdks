
# Mindbody Public Api Dto Models V6 Appointment Add On

## Structure

`MindbodyPublicApiDtoModelsV6AppointmentAddOn`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | - |
| `Name` | `string` | Optional | - |
| `NumDeducted` | `int?` | Optional | - |
| `CategoryId` | `int?` | Optional | - |
| `Category` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null,
  "NumDeducted": null,
  "CategoryId": null,
  "Category": null
}
```

