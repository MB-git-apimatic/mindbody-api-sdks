
# Mindbody Public Api Dto Models V6 Sale Controller Get Products Inventory Response

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerGetProductsInventoryResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | Contains information about the pagination to use. |
| `ProductsInventory` | [`List<Models.MindbodyPublicApiDtoModelsV6ProductsInventory>`](../../doc/models/mindbody-public-api-dto-models-v6-products-inventory.md) | Optional | Contains information about the products inventory. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "ProductsInventory": null
}
```

