
# Mindbody Public Api Dto Models V6 Class Description

Represents a class definition. The class meets at the start time, goes until the end time.

## Structure

`MindbodyPublicApiDtoModelsV6ClassDescription`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Active` | `bool?` | Optional | When `true`, indicates that the business can assign this class description to new class schedules.<br /><br>When `false`, indicates that the business cannot assign this class description to new class schedules. |
| `Description` | `string` | Optional | The long version of the class description. |
| `Id` | `int?` | Optional | The class description's ID. |
| `ImageURL` | `string` | Optional | The class description's image URL, if any. If it does not exist, nothing is returned. |
| `LastUpdated` | `DateTime?` | Optional | The date this class description was last modified. |
| `Level` | [`Models.MindbodyPublicApiDtoModelsV6Level`](../../doc/models/mindbody-public-api-dto-models-v6-level.md) | Optional | A session level. |
| `Name` | `string` | Optional | The name of this class description. |
| `Notes` | `string` | Optional | Any notes about the class description. |
| `Prereq` | `string` | Optional | Any prerequisites for the class. |
| `Program` | [`Models.MindbodyPublicApiDtoModelsV6Program`](../../doc/models/mindbody-public-api-dto-models-v6-program.md) | Optional | - |
| `SessionType` | [`Models.MindbodyPublicApiDtoModelsV6SessionType`](../../doc/models/mindbody-public-api-dto-models-v6-session-type.md) | Optional | - |
| `Category` | `string` | Optional | The category of this class description. |
| `CategoryId` | `int?` | Optional | The category ID of this class description. |
| `Subcategory` | `string` | Optional | The subcategory of this class description. |
| `SubcategoryId` | `int?` | Optional | The subcategory ID of this class description. |

## Example (as JSON)

```json
{
  "Active": null,
  "Description": null,
  "Id": null,
  "ImageURL": null,
  "LastUpdated": null,
  "Level": null,
  "Name": null,
  "Notes": null,
  "Prereq": null,
  "Program": null,
  "SessionType": null,
  "Category": null,
  "CategoryId": null,
  "Subcategory": null,
  "SubcategoryId": null
}
```

