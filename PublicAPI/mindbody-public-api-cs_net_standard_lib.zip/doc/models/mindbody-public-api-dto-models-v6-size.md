
# Mindbody Public Api Dto Models V6 Size

## Structure

`MindbodyPublicApiDtoModelsV6Size`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | The ID of the product size. |
| `Name` | `string` | Optional | The name of the product size. |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null
}
```

