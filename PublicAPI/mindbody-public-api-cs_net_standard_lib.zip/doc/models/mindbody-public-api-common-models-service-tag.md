
# Mindbody Public Api Common Models Service Tag

ServiceTag refers to Category and Subcategory fields for classes and appointments

## Structure

`MindbodyPublicApiCommonModelsServiceTag`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | - |
| `Name` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null
}
```

