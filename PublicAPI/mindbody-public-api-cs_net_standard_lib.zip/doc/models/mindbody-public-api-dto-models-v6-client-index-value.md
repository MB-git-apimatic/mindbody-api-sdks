
# Mindbody Public Api Dto Models V6 Client Index Value

A client index value.

## Structure

`MindbodyPublicApiDtoModelsV6ClientIndexValue`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Active` | `bool?` | Optional | When `true`, indicates that the index value can be assigned to its parent index.<br /><br>When `false`, indicates that the index value has been deactivated and cannot be assigned to its parent index. |
| `Id` | `int?` | Optional | The index value’s ID. |
| `Name` | `string` | Optional | The name of the client index value. |

## Example (as JSON)

```json
{
  "Active": null,
  "Id": null,
  "Name": null
}
```

