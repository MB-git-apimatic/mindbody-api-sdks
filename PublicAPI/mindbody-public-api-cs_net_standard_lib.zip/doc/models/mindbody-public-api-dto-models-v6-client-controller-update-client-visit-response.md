
# Mindbody Public Api Dto Models V6 Client Controller Update Client Visit Response

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientVisitResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Visit` | [`Models.MindbodyPublicApiDtoModelsV6Visit`](../../doc/models/mindbody-public-api-dto-models-v6-visit.md) | Optional | Represents a specific visit to a class |

## Example (as JSON)

```json
{
  "Visit": null
}
```

