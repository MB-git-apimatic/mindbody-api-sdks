
# Mindbody Public Api Dto Models V6 Client Controller Get Contact Logs Response

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerGetContactLogsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | Contains information about the pagination to use. |
| `ContactLogs` | [`List<Models.MindbodyPublicApiDtoModelsV6ContactLog>`](../../doc/models/mindbody-public-api-dto-models-v6-contact-log.md) | Optional | - |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "ContactLogs": null
}
```

