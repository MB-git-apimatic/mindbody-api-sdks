
# Status Enum

The status of this appointment.

## Enumeration

`StatusEnum`

## Fields

| Name |
|  --- |
| `None` |
| `Requested` |
| `Booked` |
| `Completed` |
| `Confirmed` |
| `Arrived` |
| `NoShow` |
| `Cancelled` |
| `LateCancelled` |

