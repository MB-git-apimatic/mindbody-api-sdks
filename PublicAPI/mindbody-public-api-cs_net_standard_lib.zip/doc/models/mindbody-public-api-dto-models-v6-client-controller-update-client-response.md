
# Mindbody Public Api Dto Models V6 Client Controller Update Client Response

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Client` | [`Models.MindbodyPublicApiDtoModelsV6ClientWithSuspensionInfo`](../../doc/models/mindbody-public-api-dto-models-v6-client-with-suspension-info.md) | Optional | A Client DTO with Suspension Informatoin |

## Example (as JSON)

```json
{
  "Client": null
}
```

